package dev.mellow.docs;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** OpenDocument text (.odt, what LibreOffice saves). Pure Java. */
final class Odt {
    private Odt() {}

    static final class SP {
        String parent;
        Boolean b, i, u, s;
        int color;
        float size;
        boolean mono;
        int align = -1;
        float indent = -1;
        String display = "";
        int fill, stroke, anchor = -1;
        boolean noFill, noStroke;

        SP merged(SP o) {      // o overrides this
            SP r = new SP();
            r.b = o.b != null ? o.b : b;
            r.i = o.i != null ? o.i : i;
            r.u = o.u != null ? o.u : u;
            r.s = o.s != null ? o.s : s;
            r.color = o.color != 0 ? o.color : color;
            r.size = o.size > 0 ? o.size : size;
            r.mono = o.mono || mono;
            r.align = o.align >= 0 ? o.align : align;
            r.indent = o.indent >= 0 ? o.indent : indent;
            r.fill = o.fill != 0 ? o.fill : fill;
            r.stroke = o.stroke != 0 ? o.stroke : stroke;
            r.noFill = o.noFill || (noFill && o.fill == 0);
            r.noStroke = o.noStroke || (noStroke && o.stroke == 0);
            r.anchor = o.anchor >= 0 ? o.anchor : anchor;
            return r;
        }
    }

    static final class Ctx {
        Pkg pkg;
        Doc doc = new Doc();
        Map<String, SP> styles = new HashMap<>();
        Map<String, boolean[]> listNumbered = new HashMap<>();
        int count;
    }

    static Doc parse(File f) throws IOException {
        try (Pkg p = new Pkg(f)) {
            byte[] content = p.bytes("content.xml");
            if (content == null) throw new IOException("This is not an OpenDocument file");
            Ctx c = new Ctx();
            c.pkg = p;
            byte[] st = p.bytes("styles.xml");
            if (st != null) readStyles(c, new Xml(st));
            readStyles(c, new Xml(content));
            Xml x = new Xml(content);
            while (x.next() != Xml.EOF) {
                if (x.is("body")) { blocks(c, x, c.doc.blocks, -1); break; }
            }
            for (Doc.Block b : c.doc.blocks) {
                if (b instanceof Doc.Para) {
                    Doc.Para pa = (Doc.Para) b;
                    if ((pa.title || pa.heading == 1) && !pa.isBlank()) { c.doc.title = pa.text().trim(); break; }
                }
            }
            return c.doc;
        }
    }

    // ---- styles ---------------------------------------------------------------------------------
    static float length(String v, float pxToPt) {
        if (v == null) return -1;
        v = v.trim();
        try {
            if (v.endsWith("cm")) return Float.parseFloat(v.substring(0, v.length() - 2)) * 28.3465f;
            if (v.endsWith("mm")) return Float.parseFloat(v.substring(0, v.length() - 2)) * 2.83465f;
            if (v.endsWith("in")) return Float.parseFloat(v.substring(0, v.length() - 2)) * 72f;
            if (v.endsWith("pt")) return Float.parseFloat(v.substring(0, v.length() - 2));
            if (v.endsWith("px")) return Float.parseFloat(v.substring(0, v.length() - 2)) * pxToPt;
        } catch (NumberFormatException ignored) { }
        return -1;
    }

    static void readStyles(Ctx c, Xml x) {
        while (x.next() != Xml.EOF) {
            if (x.is("style") && x.attr("name") != null && !x.prefix.equals("draw")) {
                SP sp = new SP();
                String name = x.attr("name");
                sp.parent = x.attr("parent-style-name");
                sp.display = x.attr("display-name", name);
                int d = x.depth;
                while (x.next() != Xml.EOF) {
                    if (x.type == Xml.END && x.depth == d) break;
                    if (x.is("text-properties")) {
                        String w = x.attr("font-weight");
                        if (w != null) sp.b = w.equals("bold") || w.equals("700") || w.equals("800") || w.equals("900");
                        String it = x.attr("font-style");
                        if (it != null) sp.i = it.equals("italic") || it.equals("oblique");
                        String u = x.attr("text-underline-style");
                        if (u != null) sp.u = !u.equals("none");
                        String s = x.attr("text-line-through-style");
                        if (s != null) sp.s = !s.equals("none");
                        String col = x.attr("color");
                        if (col != null && col.startsWith("#") && col.length() == 7) {
                            try { sp.color = 0xFF000000 | Integer.parseInt(col.substring(1), 16); } catch (NumberFormatException ignored) { }
                        }
                        float sz = length(x.attr("font-size"), 0.75f);
                        if (sz > 0) sp.size = sz;
                        String fn = x.attr("font-name", x.attr("font-family", "")).toLowerCase(Locale.ROOT);
                        if (fn.contains("courier") || fn.contains("mono") || fn.contains("consolas")) sp.mono = true;
                    } else if (x.is("graphic-properties") || x.is("drawing-page-properties")) {
                        String fk = x.attr("fill");
                        String fc = x.attr("fill-color");
                        if ("none".equals(fk)) sp.noFill = true;
                        else if (fc != null && fc.startsWith("#") && fc.length() == 7) { try { sp.fill = 0xFF000000 | Integer.parseInt(fc.substring(1), 16); } catch (NumberFormatException ignored) { } }
                        String sk = x.attr("stroke");
                        String sc = x.attr("stroke-color");
                        if ("none".equals(sk)) sp.noStroke = true;
                        else if (sc != null && sc.startsWith("#") && sc.length() == 7) { try { sp.stroke = 0xFF000000 | Integer.parseInt(sc.substring(1), 16); } catch (NumberFormatException ignored) { } }
                        String va = x.attr("textarea-vertical-align");
                        if (va != null) sp.anchor = va.equals("middle") ? 1 : va.equals("bottom") ? 2 : 0;
                    } else if (x.is("paragraph-properties")) {
                        String a = x.attr("text-align");
                        if (a != null) sp.align = a.equals("center") ? 1 : (a.equals("end") || a.equals("right")) ? 2 : a.equals("justify") ? 3 : 0;
                        float m = length(x.attr("margin-left"), 0.75f);
                        if (m >= 0) sp.indent = m;
                    }
                }
                c.styles.put(name, sp);
            } else if (x.is("list-style") && x.attr("name") != null) {
                String name = x.attr("name");
                boolean[] lv = new boolean[10];
                int d = x.depth;
                while (x.next() != Xml.EOF) {
                    if (x.type == Xml.END && x.depth == d) break;
                    if (x.is("list-level-style-number")) {
                        int l = x.attrInt("level", 1) - 1;
                        if (l >= 0 && l < 10) lv[l] = true;
                    }
                }
                c.listNumbered.put(name, lv);
            }
        }
    }

    static SP resolve(Ctx c, String name) {
        SP out = new SP();
        List<SP> chain = new ArrayList<>();
        String n = name;
        for (int i = 0; i < 8 && n != null; i++) {
            SP s = c.styles.get(n);
            if (s == null) break;
            chain.add(0, s);
            n = s.parent;
        }
        for (SP s : chain) out = out.merged(s);
        if (name != null) {
            String l = name.toLowerCase(Locale.ROOT);
            if (l.contains("strong")) out.b = true;
            if (l.contains("emphasis")) out.i = true;
            if (l.contains("source") || l.contains("preformatted") || l.contains("code")) out.mono = true;
        }
        return out;
    }

    // ---- blocks ---------------------------------------------------------------------------------
    static void blocks(Ctx c, Xml x, List<Doc.Block> out, int listLevel) {
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type != Xml.START) continue;
            if (c.count > 80000) { c.doc.truncated = true; x.skip(); continue; }
            switch (x.name) {
                case "p": case "h": para(c, x, out, listLevel, ""); break;
                case "list": list(c, x, out, 0); break;
                case "table": table(c, x, out); break;
                case "tracked-changes": case "sequence-decls": case "variable-decls": case "user-field-decls": x.skip(); break;
                default: break;   // sections, index bodies... look inside
            }
        }
    }

    /** x is on a p / h / list element: parses just that element. */
    static void blocksFromHere(Ctx c, Xml x, List<Doc.Block> out) {
        if (x.name.equals("list")) list(c, x, out, 0);
        else para(c, x, out, -1, "");
    }

    private static void list(Ctx c, Xml x, List<Doc.Block> out, int level) {
        String style = x.attr("style-name");
        boolean[] lv = style == null ? null : c.listNumbered.get(style);
        boolean numbered = lv != null && level < lv.length && lv[level];
        int d = x.depth;
        int n = 0;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.is("list-item") || x.is("list-header")) {
                n++;
                String label = numbered ? n + "." : (level % 3 == 0 ? "•" : level % 3 == 1 ? "◦" : "▪");
                int di = x.depth;
                boolean firstPara = true;
                while (x.next() != Xml.EOF) {
                    if (x.type == Xml.END && x.depth == di) break;
                    if (x.type != Xml.START) continue;
                    if (x.name.equals("p") || x.name.equals("h")) {
                        para(c, x, out, level, firstPara ? label : "");
                        firstPara = false;
                    } else if (x.name.equals("list")) {
                        list(c, x, out, level + 1);
                    } else if (x.name.equals("table")) {
                        table(c, x, out);
                    }
                }
            }
        }
    }

    private static void table(Ctx c, Xml x, List<Doc.Block> out) {
        Doc.Table t = new Doc.Table();
        int d = x.depth;
        boolean header = false;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.is("table-header-rows")) header = true;
            if (x.type == Xml.END && x.name.equals("table-header-rows")) header = false;
            if (x.is("table-row")) {
                int rep = Math.min(50, x.attrInt("number-rows-repeated", 1));
                List<Doc.Cell> row = new ArrayList<>();
                int dr = x.depth;
                while (x.next() != Xml.EOF) {
                    if (x.type == Xml.END && x.depth == dr) break;
                    if (x.is("table-cell")) {
                        Doc.Cell cell = new Doc.Cell();
                        cell.span = Math.max(1, x.attrInt("number-columns-spanned", 1));
                        cell.header = header;
                        blocks(c, x, cell.blocks, -1);
                        row.add(cell);
                    } else if (x.is("covered-table-cell")) {
                        x.skip();
                    }
                }
                for (int i = 0; i < rep; i++) t.rows.add(row);
                c.count++;
            } else if (x.is("table") ) {
                table(c, x, t.rows.isEmpty() ? out : out);
            }
        }
        out.add(t);
    }

    private static void para(Ctx c, Xml x, List<Doc.Block> out, int listLevel, String bullet) {
        Doc.Para p = new Doc.Para();
        boolean isH = x.name.equals("h");
        String styleName = x.attr("style-name");
        SP sp = resolve(c, styleName);
        if (isH) p.heading = Math.max(1, Math.min(6, x.attrInt("outline-level", 1)));
        String disp = (styleName == null ? "" : styleName).toLowerCase(Locale.ROOT);
        if (disp.equals("title")) p.title = true;
        else if (disp.equals("subtitle")) p.heading = 2;
        if (sp.align > 0) p.align = sp.align;
        if (sp.indent > 0) p.indentPt = sp.indent;
        if (sp.mono) p.code = true;
        if (listLevel >= 0) { p.level = listLevel; p.bullet = bullet; }
        List<Doc.Block> pics = new ArrayList<>();
        inline(c, x, p, sp, null, pics);
        c.count++;
        out.add(p);
        out.addAll(pics);
    }

    private static void addText(Doc.Para p, SP cur, String link, String t) {
        if (t.isEmpty()) return;
        Doc.Run r = new Doc.Run(t);
        r.b = cur.b != null && cur.b;
        r.i = cur.i != null && cur.i;
        r.u = cur.u != null && cur.u;
        r.s = cur.s != null && cur.s;
        r.color = cur.color;
        r.size = cur.size;
        r.mono = cur.mono;
        r.link = link;
        p.runs.add(r);
    }

    private static void inline(Ctx c, Xml x, Doc.Para p, SP cur, String link, List<Doc.Block> pics) {
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type == Xml.TEXT) { addText(p, cur, link, x.text); continue; }
            if (x.type != Xml.START) continue;
            switch (x.name) {
                case "span": inline(c, x, p, cur.merged(resolve(c, x.attr("style-name"))), link, pics); break;
                case "a": inline(c, x, p, cur, x.attr("href"), pics); break;
                case "s": { int n = Math.max(1, Math.min(200, x.attrInt("c", 1))); StringBuilder sb = new StringBuilder(); for (int i = 0; i < n; i++) sb.append(' '); addText(p, cur, link, sb.toString()); break; }
                case "tab": addText(p, cur, link, "\t"); break;
                case "line-break": addText(p, cur, link, "\n"); break;
                case "frame": frame(c, x, pics); break;
                case "note": case "annotation": case "bookmark": case "tracked-changes": x.skip(); break;
                default: inline(c, x, p, cur, link, pics); break;
            }
        }
    }

    private static void frame(Ctx c, Xml x, List<Doc.Block> pics) {
        float w = length(x.attr("width"), 0.75f), h = length(x.attr("height"), 0.75f);
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.is("image")) {
                String href = x.attr("href");
                if (href != null && !href.startsWith("http") && c.pkg.has(href)) {
                    Doc.Pic pic = new Doc.Pic();
                    pic.zip = c.pkg.file;
                    pic.path = href;
                    pic.wEmu = w > 0 ? (long) (w * 12700) : 0;
                    pic.hEmu = h > 0 ? (long) (h * 12700) : 0;
                    pics.add(pic);
                }
            }
        }
    }
}
