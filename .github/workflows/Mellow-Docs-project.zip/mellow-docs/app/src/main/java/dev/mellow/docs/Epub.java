package dev.mellow.docs;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** E-books (.epub). Pure Java. */
final class Epub {
    private Epub() {}

    static Doc parse(File f) throws IOException {
        try (Pkg p = new Pkg(f)) {
            Xml c = p.xml("META-INF/container.xml");
            if (c == null) throw new IOException("This is not an EPUB file");
            String opf = null;
            while (c.next() != Xml.EOF) if (c.is("rootfile")) { opf = c.attr("full-path"); break; }
            if (opf == null) throw new IOException("EPUB has no package file");
            Xml x = p.xml(opf);
            if (x == null) throw new IOException("EPUB package file is missing");
            Map<String, String> hrefs = new HashMap<>();
            Map<String, String> types = new HashMap<>();
            List<String> spine = new ArrayList<>();
            Doc doc = new Doc();
            while (x.next() != Xml.EOF) {
                if (x.is("item")) {
                    hrefs.put(x.attr("id", ""), x.attr("href", ""));
                    types.put(x.attr("id", ""), x.attr("media-type", ""));
                } else if (x.is("itemref")) {
                    spine.add(x.attr("idref", ""));
                } else if (x.is("title") && x.prefix.equals("dc") && doc.title.isEmpty()) {
                    doc.title = x.textOf().trim();
                }
            }
            boolean firstChapter = true;
            for (String id : spine) {
                String href = hrefs.get(id);
                String type = types.get(id);
                if (href == null || (type != null && !type.contains("html") && !type.contains("xml"))) continue;
                String path = Pkg.resolve(opf, java.net.URLDecoder.decode(href.replace("+", "%2B"), java.nio.charset.StandardCharsets.UTF_8));
                byte[] b = p.bytes(path);
                if (b == null) continue;
                if (!firstChapter) doc.blocks.add(new Doc.Rule(true));
                firstChapter = false;
                Html.convert(new Xml(b), doc, f, path);
                if (doc.blocks.size() > 80000) { doc.truncated = true; break; }
            }
            return doc;
        }
    }
}
