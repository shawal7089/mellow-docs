package dev.mellow.docs;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Plain text, Markdown, RTF and HTML files. Pure Java. */
final class TextDoc {
    private TextDoc() {}

    private static final int MAX_BYTES = 6 * 1024 * 1024;

    static String readText(File f, boolean[] truncated) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream((int) Math.min(f.length() + 16, MAX_BYTES + 16));
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) {
                if (out.size() + n > MAX_BYTES) {
                    out.write(buf, 0, MAX_BYTES - out.size());
                    if (truncated != null) truncated[0] = true;
                    break;
                }
                out.write(buf, 0, n);
            }
        }
        return Xml.decode(out.toByteArray());
    }

    static Doc parse(File f) throws IOException {
        String name = f.getName().toLowerCase(Locale.ROOT);
        String ext = FileOps.ext(name);
        boolean[] tr = new boolean[1];
        Doc doc;
        if (ext.equals("html") || ext.equals("htm") || ext.equals("xhtml")) {
            doc = new Doc();
            Html.convert(new Xml(readText(f, tr)), doc, null, "");
        } else if (ext.equals("rtf")) {
            doc = rtf(readText(f, tr));
        } else if (ext.equals("md") || ext.equals("markdown")) {
            doc = markdown(readText(f, tr));
        } else {
            doc = plain(readText(f, tr));
        }
        doc.truncated |= tr[0];
        if (doc.title.isEmpty()) {
            for (Doc.Block b : doc.blocks) {
                if (b instanceof Doc.Para && ((Doc.Para) b).heading > 0 && !((Doc.Para) b).isBlank()) { doc.title = ((Doc.Para) b).text().trim(); break; }
            }
        }
        return doc;
    }

    // ---- plain ------------------------------------------------------------------------------------
    static Doc plain(String text) {
        Doc d = new Doc();
        text = text.replace("\r\n", "\n").replace('\r', '\n');
        String[] lines = text.split("\n", -1);
        final int chunk = 60;
        for (int i = 0; i < lines.length; i += chunk) {
            StringBuilder sb = new StringBuilder();
            for (int k = i; k < Math.min(lines.length, i + chunk); k++) {
                if (k > i) sb.append('\n');
                sb.append(lines[k]);
            }
            Doc.Para p = new Doc.Para();
            p.code = true;
            Doc.Run r = new Doc.Run(sb.toString());
            r.mono = true;
            p.runs.add(r);
            d.blocks.add(p);
        }
        return d;
    }

    // ---- markdown ---------------------------------------------------------------------------------
    static Doc markdown(String text) {
        Doc d = new Doc();
        text = text.replace("\r\n", "\n").replace('\r', '\n');
        String[] lines = text.split("\n", -1);
        StringBuilder para = new StringBuilder();
        boolean fence = false;
        StringBuilder code = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            String t = line.trim();
            if (t.startsWith("```") || t.startsWith("~~~")) {
                if (fence) {
                    Doc.Para p = new Doc.Para();
                    p.code = true;
                    Doc.Run r = new Doc.Run(code.toString());
                    r.mono = true;
                    p.runs.add(r);
                    d.blocks.add(p);
                    code.setLength(0);
                    fence = false;
                } else {
                    flushPara(d, para, 0, null, null);
                    fence = true;
                }
                continue;
            }
            if (fence) { if (code.length() > 0) code.append('\n'); code.append(line); continue; }
            if (t.isEmpty()) { flushPara(d, para, 0, null, null); continue; }
            if (t.matches("^(-{3,}|\\*{3,}|_{3,})$")) { flushPara(d, para, 0, null, null); d.blocks.add(new Doc.Rule(false)); continue; }
            if (t.startsWith("#")) {
                int h = 0;
                while (h < t.length() && t.charAt(h) == '#') h++;
                if (h <= 6 && h < t.length() && t.charAt(h) == ' ') {
                    flushPara(d, para, 0, null, null);
                    String body = t.substring(h + 1).replaceAll("\\s+#+\\s*$", "");
                    Doc.Para p = new Doc.Para();
                    p.heading = h;
                    inline(p, body);
                    d.blocks.add(p);
                    continue;
                }
            }
            if (t.startsWith("|") && i + 1 < lines.length && lines[i + 1].trim().matches("^\\|?[\\s:|-]+\\|?$") && lines[i + 1].contains("-")) {
                flushPara(d, para, 0, null, null);
                Doc.Table tb = new Doc.Table();
                tb.rows.add(mdRow(t, true));
                i += 2;
                while (i < lines.length && lines[i].trim().startsWith("|")) { tb.rows.add(mdRow(lines[i].trim(), false)); i++; }
                i--;
                d.blocks.add(tb);
                continue;
            }
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\s*)([-*+]|\\d+[.)])\\s+(.*)$").matcher(line);
            if (m.matches()) {
                flushPara(d, para, 0, null, null);
                int lvl = Math.min(4, m.group(1).replace("\t", "    ").length() / 2);
                String mk = m.group(2);
                String bullet = Character.isDigit(mk.charAt(0)) ? mk : (lvl % 2 == 0 ? "•" : "◦");
                Doc.Para p = new Doc.Para();
                p.level = lvl;
                p.bullet = bullet;
                String body = m.group(3);
                if (body.startsWith("[ ] ")) body = "☐ " + body.substring(4);
                else if (body.startsWith("[x] ") || body.startsWith("[X] ")) body = "☑ " + body.substring(4);
                inline(p, body);
                d.blocks.add(p);
                continue;
            }
            if (t.startsWith(">")) {
                flushPara(d, para, 0, null, null);
                Doc.Para p = new Doc.Para();
                p.quote = true;
                p.indentPt = 18;
                inline(p, t.replaceFirst("^>+\\s?", ""));
                d.blocks.add(p);
                continue;
            }
            if (para.length() > 0) para.append(' ');
            para.append(t);
        }
        flushPara(d, para, 0, null, null);
        if (fence && code.length() > 0) {
            Doc.Para p = new Doc.Para();
            p.code = true;
            Doc.Run r = new Doc.Run(code.toString());
            r.mono = true;
            p.runs.add(r);
            d.blocks.add(p);
        }
        return d;
    }

    private static List<Doc.Cell> mdRow(String line, boolean header) {
        String t = line;
        if (t.startsWith("|")) t = t.substring(1);
        if (t.endsWith("|")) t = t.substring(0, t.length() - 1);
        List<Doc.Cell> row = new ArrayList<>();
        for (String c : t.split("\\|", -1)) {
            Doc.Cell cell = new Doc.Cell();
            cell.header = header;
            Doc.Para p = new Doc.Para();
            inline(p, c.trim());
            cell.blocks.add(p);
            row.add(cell);
        }
        return row;
    }

    private static void flushPara(Doc d, StringBuilder sb, int heading, String b, String u) {
        if (sb.length() == 0) return;
        Doc.Para p = new Doc.Para();
        inline(p, sb.toString());
        d.blocks.add(p);
        sb.setLength(0);
    }

    /** **bold**, *italic*, `code`, [text](url), ~~strike~~. */
    static void inline(Doc.Para p, String s) {
        StringBuilder cur = new StringBuilder();
        boolean b = false, it = false, st = false;
        String link = null;
        int i = 0;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) { cur.append(s.charAt(i + 1)); i += 2; continue; }
            if (c == '`') {
                int e = s.indexOf('`', i + 1);
                if (e > i) {
                    emit(p, cur, b, it, st, false, link);
                    Doc.Run r = new Doc.Run(s.substring(i + 1, e));
                    r.mono = true;
                    r.link = link;
                    p.runs.add(r);
                    i = e + 1;
                    continue;
                }
            }
            if ((c == '*' || c == '_') && i + 1 < s.length() && s.charAt(i + 1) == c) {
                emit(p, cur, b, it, st, false, link);
                b = !b;
                i += 2;
                continue;
            }
            if (c == '~' && i + 1 < s.length() && s.charAt(i + 1) == '~') {
                emit(p, cur, b, it, st, false, link);
                st = !st;
                i += 2;
                continue;
            }
            if (c == '*' || (c == '_' && (i == 0 || !Character.isLetterOrDigit(s.charAt(i - 1))))) {
                emit(p, cur, b, it, st, false, link);
                it = !it;
                i++;
                continue;
            }
            if (c == '!' && i + 1 < s.length() && s.charAt(i + 1) == '[') {
                int e = s.indexOf("](", i);
                int e2 = e < 0 ? -1 : s.indexOf(')', e);
                if (e > 0 && e2 > 0) { cur.append(s, i + 2, e); i = e2 + 1; continue; }
            }
            if (c == '[') {
                int e = s.indexOf("](", i);
                int e2 = e < 0 ? -1 : s.indexOf(')', e);
                if (e > 0 && e2 > 0) {
                    emit(p, cur, b, it, st, false, link);
                    String label = s.substring(i + 1, e);
                    Doc.Run r = new Doc.Run(label);
                    r.b = b; r.i = it; r.s = st;
                    r.link = s.substring(e + 2, e2).trim();
                    p.runs.add(r);
                    i = e2 + 1;
                    continue;
                }
            }
            cur.append(c);
            i++;
        }
        emit(p, cur, b, it, st, false, link);
    }

    private static void emit(Doc.Para p, StringBuilder cur, boolean b, boolean i, boolean s, boolean mono, String link) {
        if (cur.length() == 0) return;
        Doc.Run r = new Doc.Run(cur.toString());
        r.b = b; r.i = i; r.s = s; r.mono = mono; r.link = link;
        p.runs.add(r);
        cur.setLength(0);
    }

    // ---- rtf --------------------------------------------------------------------------------------
    static Doc rtf(String s) {
        Doc d = new Doc();
        StringBuilder cur = new StringBuilder();
        Doc.Para p = new Doc.Para();
        int depth = 0, skipDepth = -1;
        boolean bold = false, ital = false;
        int uc = 1;
        java.util.ArrayDeque<boolean[]> stack = new java.util.ArrayDeque<>();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '{') {
                stack.push(new boolean[]{bold, ital});
                depth++;
                if (skipDepth < 0 && i + 2 < s.length() && s.charAt(i + 1) == '\\' && s.charAt(i + 2) == '*') skipDepth = depth;
                continue;
            }
            if (c == '}') {
                if (depth == skipDepth) skipDepth = -1;
                depth--;
                if (!stack.isEmpty()) {
                    flushRtf(d, p, cur, bold, ital);
                    boolean[] st = stack.pop();
                    bold = st[0];
                    ital = st[1];
                }
                continue;
            }
            if (c == '\\') {
                if (i + 1 >= s.length()) break;
                char n = s.charAt(i + 1);
                if (n == '\\' || n == '{' || n == '}') { if (skipDepth < 0) cur.append(n); i++; continue; }
                if (n == '\'') {
                    if (i + 3 < s.length() && skipDepth < 0) {
                        try { cur.append(new String(new byte[]{(byte) Integer.parseInt(s.substring(i + 2, i + 4), 16)}, "windows-1252")); } catch (Exception ignored) { }
                    }
                    i += 3;
                    continue;
                }
                int j = i + 1;
                while (j < s.length() && Character.isLetter(s.charAt(j))) j++;
                String word = s.substring(i + 1, j);
                int k = j;
                if (k < s.length() && (s.charAt(k) == '-' || Character.isDigit(s.charAt(k)))) {
                    k++;
                    while (k < s.length() && Character.isDigit(s.charAt(k))) k++;
                }
                String param = s.substring(j, k);
                if (k < s.length() && s.charAt(k) == ' ') k++;
                i = k - 1;
                if (word.isEmpty()) continue;
                if (skipDepth >= 0) continue;
                switch (word) {
                    case "fonttbl": case "colortbl": case "stylesheet": case "info": case "pict": case "header": case "footer": case "generator":
                        skipDepth = depth;
                        break;
                    case "par": case "sect": case "page":
                        flushRtf(d, p, cur, bold, ital);
                        if (!p.runs.isEmpty()) d.blocks.add(p);
                        p = new Doc.Para();
                        break;
                    case "line": cur.append('\n'); break;
                    case "tab": cur.append('\t'); break;
                    case "emdash": cur.append('—'); break;
                    case "endash": cur.append('–'); break;
                    case "bullet": cur.append('•'); break;
                    case "lquote": cur.append('‘'); break;
                    case "rquote": cur.append('’'); break;
                    case "ldblquote": cur.append('“'); break;
                    case "rdblquote": cur.append('”'); break;
                    case "uc": try { uc = Integer.parseInt(param); } catch (NumberFormatException ignored) { } break;
                    case "u":
                        try {
                            int cp = Integer.parseInt(param);
                            if (cp < 0) cp += 65536;
                            cur.append((char) cp);
                        } catch (NumberFormatException ignored) { }
                        for (int skipN = 0; skipN < uc; skipN++) {
                            if (i + 1 < s.length() && s.charAt(i + 1) == '\\' && i + 4 < s.length() && s.charAt(i + 2) == '\'') i += 4;
                            else i += 1;
                        }
                        break;
                    case "plain": flushRtf(d, p, cur, bold, ital); bold = false; ital = false; break;
                    case "b": { flushRtf(d, p, cur, bold, ital); bold = !param.equals("0"); break; }
                    case "i": { flushRtf(d, p, cur, bold, ital); ital = !param.equals("0"); break; }
                    default: break;
                }
                continue;
            }
            if (skipDepth >= 0 || c == '\r' || c == '\n') continue;
            cur.append(c);
        }
        flushRtf(d, p, cur, bold, ital);
        if (!p.runs.isEmpty()) d.blocks.add(p);
        return d;
    }

    private static void flushRtf(Doc d, Doc.Para p, StringBuilder cur, boolean b, boolean i) {
        if (cur.length() > 0) {
            Doc.Run r = new Doc.Run(cur.toString());
            r.b = b; r.i = i;
            p.runs.add(r);
            cur.setLength(0);
        }
    }
}
