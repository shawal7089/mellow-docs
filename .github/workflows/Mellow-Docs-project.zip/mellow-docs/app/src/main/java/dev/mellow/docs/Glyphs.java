package dev.mellow.docs;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/** Thin line icons drawn in code (26x26 design grid), so the app needs no image files. */
final class Glyphs {
    private Glyphs() {}

    private static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final RectF R = new RectF();

    static void draw(Canvas c, String kind, float cx, float cy, float size, int color) {
        c.save();
        c.translate(cx - size / 2f, cy - size / 2f);
        float s = size / 26f;
        c.scale(s, s);
        P.setShader(null);
        P.setStyle(Paint.Style.STROKE);
        P.setStrokeWidth(1.9f);
        P.setStrokeCap(Paint.Cap.ROUND);
        P.setStrokeJoin(Paint.Join.ROUND);
        P.setColor(color);
        switch (kind) {
            case "up": poly(c, 6, 14, 13, 7, 20, 14); poly(c, 13, 7, 13, 20); break;
            case "back": poly(c, 15, 6, 8.5f, 13, 15, 20); break;
            case "search": c.drawCircle(11.5f, 11.5f, 5.5f, P); poly(c, 15.5f, 15.5f, 20, 20); break;
            case "grid":
                for (float gx : new float[]{6, 14}) for (float gy : new float[]{6, 14}) { R.set(gx, gy, gx + 6, gy + 6); c.drawRoundRect(R, 1.6f, 1.6f, P); }
                break;
            case "list":
                for (float gy : new float[]{8, 13, 18}) { poly(c, 6, gy, 7, gy); poly(c, 10, gy, 20, gy); }
                break;
            case "more": dot(c, 13, 6.5f, 1.7f); dot(c, 13, 13, 1.7f); dot(c, 13, 19.5f, 1.7f); break;
            case "copy":
                R.set(9, 9, 20, 21); c.drawRoundRect(R, 2.5f, 2.5f, P);
                poly(c, 6.5f, 17, 6.5f, 6, 15, 6);
                break;
            case "cut":
                c.drawCircle(8, 18, 2.4f, P); c.drawCircle(18, 18, 2.4f, P);
                poly(c, 9.5f, 16, 17, 6); poly(c, 16.5f, 16, 9, 6);
                break;
            case "trash":
                poly(c, 7.5f, 8, 18.5f, 8);
                R.set(9, 10, 17, 20); c.drawRoundRect(R, 1.5f, 1.5f, P);
                poly(c, 11, 8, 11, 6.5f, 15, 6.5f, 15, 8);
                break;
            case "hide": case "show": {
                Path e = new Path();
                e.moveTo(4, 13); e.quadTo(13, 3.5f, 22, 13); e.quadTo(13, 22.5f, 4, 13);
                c.drawPath(e, P);
                c.drawCircle(13, 13, 2.8f, P);
                if (kind.equals("hide")) poly(c, 5.5f, 21, 20.5f, 5);
                break;
            }
            case "close": poly(c, 7, 7, 19, 19); poly(c, 19, 7, 7, 19); break;
            case "check": poly(c, 6.5f, 13.5f, 11, 18, 19.5f, 8); break;
            case "plus": poly(c, 13, 6, 13, 20); poly(c, 6, 13, 20, 13); break;
            case "newfolder":
                R.set(5, 8, 21, 19); c.drawRoundRect(R, 2.5f, 2.5f, P);
                poly(c, 13, 11.5f, 13, 16.5f); poly(c, 10.5f, 14, 15.5f, 14);
                break;
            case "share":
                c.drawCircle(7, 13, 2.2f, P); c.drawCircle(19, 7, 2.2f, P); c.drawCircle(19, 19, 2.2f, P);
                poly(c, 9, 12, 17, 8); poly(c, 9, 14, 17, 18);
                break;
            case "restore": {
                Path e = new Path();
                e.moveTo(6, 11); e.lineTo(15, 11); e.quadTo(20, 11, 20, 16); e.quadTo(20, 21, 15, 21); e.lineTo(10, 21);
                c.drawPath(e, P);
                poly(c, 9, 7.5f, 5.5f, 11, 9, 14.5f);
                break;
            }
            case "palette":
                c.drawCircle(13, 13, 8, P);
                dot(c, 9.5f, 11, 1.2f); dot(c, 13.5f, 8.5f, 1.2f); dot(c, 16.5f, 12, 1.2f);
                break;
            case "sort": poly(c, 6, 8, 20, 8); poly(c, 6, 13, 15, 13); poly(c, 6, 18, 10, 18); break;
            case "moon": {
                Path e = new Path();
                e.moveTo(16, 6); e.quadTo(8, 7, 8.5f, 14.5f); e.quadTo(10, 21, 18, 19.5f); e.quadTo(11.5f, 15, 16, 6);
                c.drawPath(e, P);
                break;
            }
            case "text":
                poly(c, 5, 19, 9.5f, 7, 14, 19); poly(c, 6.7f, 15, 12.3f, 15); poly(c, 16, 19, 18.5f, 12.5f, 21, 19); poly(c, 16.9f, 17, 20.1f, 17);
                break;
            case "play": poly(c, 9, 6.5f, 9, 19.5f, 19.5f, 13, 9, 6.5f); break;
            case "info": c.drawCircle(13, 13, 8, P); poly(c, 13, 12, 13, 17.5f); dot(c, 13, 8.8f, 1.2f); break;
            case "open": R.set(6, 9, 20, 20); c.drawRoundRect(R, 2.5f, 2.5f, P); poly(c, 6, 9, 6, 7, 11, 7, 13, 9); break;
            case "down": poly(c, 6, 12, 13, 19, 20, 12); poly(c, 13, 19, 13, 6); break;
            case "file": R.set(7, 5, 19, 21); c.drawRoundRect(R, 2.5f, 2.5f, P); poly(c, 10, 11, 16, 11); poly(c, 10, 15, 16, 15); break;
            default: break;
        }
        c.restore();
    }

    private static void poly(Canvas c, float... xy) {
        Path p = new Path();
        p.moveTo(xy[0], xy[1]);
        for (int i = 2; i + 1 < xy.length; i += 2) p.lineTo(xy[i], xy[i + 1]);
        c.drawPath(p, P);
    }

    private static void dot(Canvas c, float x, float y, float r) {
        P.setStyle(Paint.Style.FILL);
        c.drawCircle(x, y, r, P);
        P.setStyle(Paint.Style.STROKE);
    }
}
