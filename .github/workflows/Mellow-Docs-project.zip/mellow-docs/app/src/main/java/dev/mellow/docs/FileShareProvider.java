package dev.mellow.docs;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Lets other apps open or receive a file from Mellow without any extra libraries.
 * Not exported: other apps can only read a file Mellow explicitly hands them (one-time URI grant).
 */
public class FileShareProvider extends ContentProvider {
    static final String AUTH = "dev.mellow.docs.share";

    static Uri uriFor(File f) {
        String tok = Base64.encodeToString(f.getAbsolutePath().getBytes(StandardCharsets.UTF_8),
                Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
        return new Uri.Builder().scheme("content").authority(AUTH)
                .appendPath("f").appendPath(tok).appendPath(f.getName()).build();
    }

    static String mimeOf(String name) {
        String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(FileOps.ext(name));
        return m != null ? m : "application/octet-stream";
    }

    private File fileFor(Uri uri) {
        List<String> seg = uri.getPathSegments();
        if (seg.size() < 3 || !"f".equals(seg.get(0))) return null;
        try {
            byte[] b = Base64.decode(seg.get(1), Base64.URL_SAFE);
            File f = new File(new String(b, StandardCharsets.UTF_8));
            String canon = f.getCanonicalPath();
            if (!canon.startsWith("/storage/") && !canon.startsWith("/sdcard/")) return null;
            return f.isFile() ? f : null;
        } catch (Exception e) {
            return null;
        }
    }

    @Override public boolean onCreate() { return true; }

    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File f = fileFor(uri);
        if (f == null || !"r".equals(mode)) throw new FileNotFoundException(uri.toString());
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        File f = fileFor(uri);
        if (f == null) return null;
        String[] cols = projection != null ? projection : new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
        MatrixCursor c = new MatrixCursor(cols);
        Object[] row = new Object[cols.length];
        for (int i = 0; i < cols.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(cols[i])) row[i] = f.getName();
            else if (OpenableColumns.SIZE.equals(cols[i])) row[i] = f.length();
        }
        c.addRow(row);
        return c;
    }

    @Override public String getType(Uri uri) {
        File f = fileFor(uri);
        return mimeOf(f != null ? f.getName() : String.valueOf(uri.getLastPathSegment()));
    }

    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri uri, String selection, String[] args) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] args) { throw new UnsupportedOperationException(); }
}
