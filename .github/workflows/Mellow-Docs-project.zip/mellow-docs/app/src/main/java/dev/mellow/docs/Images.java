package dev.mellow.docs;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;

import java.io.File;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Decodes pictures stored inside documents (zip entries) in the background and keeps a small cache. */
final class Images {
    private Images() {}

    private static final Handler UI = new Handler(Looper.getMainLooper());
    private static final ExecutorService POOL = Executors.newFixedThreadPool(2);
    private static final Set<String> BAD = new HashSet<>();
    private static final Set<String> BUSY = new HashSet<>();
    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(
            (int) Math.min(64L * 1024 * 1024, Runtime.getRuntime().maxMemory() / 6)) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };

    static void clear() { CACHE.evictAll(); BAD.clear(); }

    /** Returns the bitmap if ready, otherwise null (and calls ready once it has been decoded). */
    static Bitmap get(final File zip, final String path, final int maxW, final Runnable ready) {
        if (zip == null || path == null) return null;
        final String key = zip.getPath() + "|" + path + "|" + (maxW / 256);
        Bitmap b = CACHE.get(key);
        if (b != null) return b;
        synchronized (BAD) {
            if (BAD.contains(key) || !BUSY.add(key)) return null;
        }
        POOL.execute(() -> {
            Bitmap out = null;
            try (Pkg p = new Pkg(zip)) {
                byte[] data = p.bytes(path);
                if (data != null) {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(data, 0, data.length, o);
                    int sample = 1;
                    while (o.outWidth / (sample * 2) >= maxW && o.outWidth > 0) sample *= 2;
                    o = new BitmapFactory.Options();
                    o.inSampleSize = sample;
                    out = BitmapFactory.decodeByteArray(data, 0, data.length, o);
                }
            } catch (Throwable ignored) {
            }
            final Bitmap res = out;
            synchronized (BAD) {
                BUSY.remove(key);
                if (res == null) BAD.add(key);
            }
            if (res != null) CACHE.put(key, res);
            UI.post(ready);
        });
        return null;
    }
}
