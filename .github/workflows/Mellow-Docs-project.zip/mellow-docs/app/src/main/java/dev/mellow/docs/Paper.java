package dev.mellow.docs;

/** Reading colours (page background, text) for day and night. */
final class Paper {
    private Paper() {}
    static boolean night;
    static int bg, fg, muted, link, rule, codeBg, cellLine, hi;

    static void set(boolean n) {
        night = n;
        if (n) {
            bg = 0xFF15161b; fg = 0xFFd9dae2; muted = 0xFF8c8e9c; link = 0xFF9db4ff;
            rule = 0x33FFFFFF; codeBg = 0x22FFFFFF; cellLine = 0x40FFFFFF; hi = 0x66e6c27a;
        } else {
            bg = 0xFFfaf8f4; fg = 0xFF25262d; muted = 0xFF7b7d88; link = 0xFF3a5bc7;
            rule = 0x26000000; codeBg = 0x12000000; cellLine = 0x33000000; hi = 0x88f3d27a;
        }
    }

    /** Make a document colour readable on the current page colour. */
    static int fix(int c) {
        if (c == 0) return fg;
        int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        float l = (0.299f * r + 0.587f * g + 0.114f * b) / 255f;
        if (night && l < 0.35f) return Palette.mix(c, 0xFFFFFFFF, 0.75f);
        if (!night && l > 0.85f) return Palette.mix(c, 0xFF000000, 0.75f);
        return 0xFF000000 | c;
    }
}
