package dev.mellow.docs;

import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

/** Remembers the last documents opened (from this app's library). */
final class Recents {
    private Recents() {}

    static List<String> get(SharedPreferences p) {
        List<String> out = new ArrayList<>();
        String s = p.getString("recents", "");
        if (!s.isEmpty()) for (String x : s.split("\n")) if (!x.isEmpty()) out.add(x);
        return out;
    }

    static void add(SharedPreferences p, String path, boolean real) {
        if (!real) return;
        List<String> l = get(p);
        l.remove(path);
        l.add(0, path);
        while (l.size() > 40) l.remove(l.size() - 1);
        StringBuilder sb = new StringBuilder();
        for (String s : l) sb.append(s).append('\n');
        p.edit().putString("recents", sb.toString()).apply();
    }

    static void remove(SharedPreferences p, String path) {
        List<String> l = get(p);
        if (!l.remove(path)) return;
        StringBuilder sb = new StringBuilder();
        for (String s : l) sb.append(s).append('\n');
        p.edit().putString("recents", sb.toString()).apply();
    }
}
