package dev.mellow.docs;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsetsController;
import android.view.inputmethod.EditorInfo;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Opens one document: PDF, Word-like, slides, spreadsheet or plain text. */
public class ReaderActivity extends Activity {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private volatile boolean dead;

    private FrameLayout root, content, present;
    private LinearLayout column, searchBar, tabsRow;
    private TextView titleView, subView, pageChip, cellBar, status;
    private IconButton nightBtn, textBtn, findBtn, playBtn;
    private EditText findBox;

    private File file;              // local copy / original
    private Uri origUri;            // set when opened from another app
    private String name = "";
    private int kind;
    private boolean night;
    private String posKey;

    private PdfView pdf;
    private DocView docView;
    private ListView slideList;
    private Slides deck;
    private SheetView sheetView;
    private Sheets sheets;
    private SlideView presentView;
    private int presentIndex;
    private String detail = "";

    @Override protected void onCreate(Bundle b) {
        prefs = getSharedPreferences("mellowdocs", MODE_PRIVATE);
        Look.load(this, prefs);
        setTheme(Ui.t.dark ? R.style.AppDark : R.style.AppLight);
        super.onCreate(b);
        night = prefs.getBoolean("night", Ui.t.dark);
        Paper.set(night);
        buildUi();
        resolveIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        recreate();
    }

    @Override protected void onPause() {
        super.onPause();
        savePos();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        dead = true;
        worker.shutdownNow();
        if (pdf != null) pdf.close();
        Images.clear();
    }

    @Override public void onBackPressed() {
        if (present != null && present.getVisibility() == View.VISIBLE) { endPresent(); return; }
        if (searchBar.getVisibility() == View.VISIBLE) { closeFind(); return; }
        super.onBackPressed();
    }

    // ---- ui -----------------------------------------------------------------------------------------
    private TextView label(String s, float sp, int color, boolean bold) { return Look.label(this, s, sp, color, bold); }

    private IconButton btn(String kind, View.OnClickListener l) {
        IconButton b = new IconButton(this, kind);
        b.setOnClickListener(l);
        return b;
    }

    private void buildUi() {
        final Palette.Theme t = Ui.t;
        root = new FrameLayout(this);
        root.setBackground(new Ui.GradientBg());
        column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        root.addView(column, new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(Ui.panel(26));
        bar.setPadding(Ui.dp(4), Ui.dp(2), Ui.dp(4), Ui.dp(2));
        bar.addView(btn("back", v -> finish()));
        LinearLayout tcol = new LinearLayout(this);
        tcol.setOrientation(LinearLayout.VERTICAL);
        tcol.setPadding(Ui.dp(4), 0, Ui.dp(4), 0);
        titleView = label("", 16, t.text, true);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        subView = label("", 11.5f, t.muted, false);
        subView.setSingleLine(true);
        tcol.addView(titleView);
        tcol.addView(subView);
        bar.addView(tcol, new LinearLayout.LayoutParams(0, WRAP, 1f));
        playBtn = btn("play", v -> startPresent(Math.max(0, slideList == null ? 0 : slideList.getFirstVisiblePosition())));
        findBtn = btn("search", v -> openFind());
        textBtn = btn("text", v -> textSizeMenu(v));
        nightBtn = btn("moon", v -> toggleNight());
        nightBtn.setOn(night);
        for (View v : new View[]{playBtn, findBtn, textBtn, nightBtn}) { v.setVisibility(View.GONE); bar.addView(v); }
        bar.addView(btn("more", v -> moreMenu(v)));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(MATCH, WRAP);
        bl.setMargins(Ui.dp(8), Ui.dp(6), Ui.dp(8), Ui.dp(6));
        column.addView(bar, bl);

        searchBar = new LinearLayout(this);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setVisibility(View.GONE);
        findBox = new EditText(this);
        findBox.setSingleLine(true);
        findBox.setHint("Find in document");
        findBox.setHintTextColor(t.muted);
        findBox.setTextColor(t.text);
        findBox.setTextSize(15);
        findBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        findBox.setBackground(Ui.solid(t.field(), 16, t.panelBorder()));
        findBox.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(8));
        findBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b2, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b2, int c) { }
            @Override public void afterTextChanged(Editable s) {
                if (docView != null) { docView.setQuery(s.toString()); }
            }
        });
        findBox.setOnEditorActionListener((v, id, e) -> { findStep(1); return true; });
        searchBar.addView(findBox, new LinearLayout.LayoutParams(0, WRAP, 1f));
        TextView prev = label("↑", 22, t.text, true);
        TextView next = label("↓", 22, t.text, true);
        prev.setPadding(Ui.dp(14), Ui.dp(4), Ui.dp(8), Ui.dp(4));
        next.setPadding(Ui.dp(8), Ui.dp(4), Ui.dp(14), Ui.dp(4));
        prev.setOnClickListener(v -> findStep(-1));
        next.setOnClickListener(v -> findStep(1));
        searchBar.addView(prev);
        searchBar.addView(next);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(MATCH, WRAP);
        sl.setMargins(Ui.dp(10), 0, Ui.dp(10), Ui.dp(6));
        column.addView(searchBar, sl);

        content = new FrameLayout(this);
        column.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        pageChip = label("", 13.5f, t.text, true);
        pageChip.setBackground(Ui.panel(18));
        pageChip.setPadding(Ui.dp(14), Ui.dp(7), Ui.dp(14), Ui.dp(7));
        pageChip.setVisibility(View.GONE);
        pageChip.setOnClickListener(v -> jumpDialog());
        FrameLayout.LayoutParams pc = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        pc.bottomMargin = Ui.dp(18);
        root.addView(pageChip, pc);

        status = label("Opening…", 15, t.muted, false);
        status.setGravity(Gravity.CENTER);
        status.setPadding(Ui.dp(28), 0, Ui.dp(28), 0);
        content.addView(status, new FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER));

        setContentView(root);
        getWindow().setStatusBarColor(t.bg1);
        getWindow().setNavigationBarColor(t.bg2);
        WindowInsetsController wc = getWindow().getInsetsController();
        if (wc != null) {
            int light = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
            wc.setSystemBarsAppearance(t.dark ? 0 : light, light);
        }
    }

    // ---- locating the file --------------------------------------------------------------------------
    private void resolveIntent(final Intent in) {
        String p = in.getStringExtra("path");
        Uri data = in.getData();
        if (p == null && data == null && in.getClipData() != null && in.getClipData().getItemCount() > 0) data = in.getClipData().getItemAt(0).getUri();
        if (p == null && data == null && Intent.ACTION_SEND.equals(in.getAction())) data = android.os.Build.VERSION.SDK_INT >= 33 ? in.getParcelableExtra(Intent.EXTRA_STREAM, Uri.class) : (Uri) in.getParcelableExtra(Intent.EXTRA_STREAM);
        if (p != null) { begin(new File(p), null); return; }
        if (data == null) { fail("There is nothing to open."); return; }
        if ("file".equals(data.getScheme()) && data.getPath() != null) { begin(new File(data.getPath()), null); return; }
        final Uri u = data;
        origUri = u;
        worker.execute(() -> {
            try {
                File f = copyToCache(u);
                ui.post(() -> { if (!dead) begin(f, u); });
            } catch (final Throwable e) {
                ui.post(() -> { if (!dead) fail("Couldn’t read this file" + (e.getMessage() == null ? "." : ": " + e.getMessage())); });
            }
        });
    }

    private File copyToCache(Uri u) throws IOException {
        String nm = null;
        try (Cursor c = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) nm = c.getString(0);
        } catch (Throwable ignored) { }
        if (nm == null || nm.isEmpty()) nm = u.getLastPathSegment() == null ? "document" : u.getLastPathSegment();
        nm = nm.replace('/', '_');
        if (Kind.of(nm) == Kind.NONE) {
            String ext = extFromMime(getContentResolver().getType(u));
            if (ext != null) nm = nm + "." + ext;
        }
        File dir = new File(getCacheDir(), "open");
        if (!dir.isDirectory()) dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File o : old) if (System.currentTimeMillis() - o.lastModified() > 6L * 3600 * 1000) o.delete();
        File out = new File(dir, Integer.toHexString(u.toString().hashCode()) + "_" + nm);
        try (InputStream in = getContentResolver().openInputStream(u); OutputStream os = new FileOutputStream(out)) {
            if (in == null) throw new IOException("the app that shared it did not give access");
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        }
        return out;
    }

    private static String extFromMime(String m) {
        if (m == null) return null;
        m = m.toLowerCase(Locale.ROOT);
        if (m.contains("pdf")) return "pdf";
        if (m.contains("wordprocessingml")) return "docx";
        if (m.contains("presentationml")) return "pptx";
        if (m.contains("spreadsheetml")) return "xlsx";
        if (m.contains("opendocument.text")) return "odt";
        if (m.contains("opendocument.presentation")) return "odp";
        if (m.contains("opendocument.spreadsheet")) return "ods";
        if (m.contains("epub")) return "epub";
        if (m.contains("csv")) return "csv";
        if (m.contains("markdown")) return "md";
        if (m.contains("rtf")) return "rtf";
        if (m.contains("html")) return "html";
        if (m.contains("msword")) return "doc";
        if (m.contains("powerpoint")) return "ppt";
        if (m.contains("ms-excel")) return "xls";
        if (m.startsWith("text/")) return "txt";
        return null;
    }

    // ---- loading ------------------------------------------------------------------------------------
    private void begin(final File f, Uri from) {
        file = f;
        name = f.getName();
        if (from != null) { int u = name.indexOf('_'); if (u > 0 && u <= 8) name = name.substring(u + 1); }
        kind = Kind.of(name);
        posKey = "pos:" + (from != null ? name : f.getPath());
        titleView.setText(name);
        subView.setText(FileOps.humanSize(f.length()));
        Recents.add(prefs, f.getPath(), from == null);
        if (kind == Kind.NONE) { kind = Kind.TEXT; }
        if (kind == Kind.LEGACY) {
            fail("Old binary Office files (." + FileOps.ext(name) + ") aren’t supported. Save the file as .docx / .pptx / .xlsx or PDF, or open it with another app.");
            return;
        }
        final int k = kind;
        status.setText("Opening…");
        if (k == Kind.PDF) {
            try {
                showPdf(new PdfView(this, f));
            } catch (Throwable e) {
                fail(e instanceof SecurityException || String.valueOf(e.getMessage()).toLowerCase(Locale.ROOT).contains("password")
                        ? "This PDF is password protected." : "Couldn’t open this PDF" + (e.getMessage() == null ? "." : ": " + e.getMessage()));
            }
            return;
        }
        worker.execute(() -> {
            Object res = null;
            String err = null;
            try {
                switch (k) {
                    case Kind.DOC: res = loadDoc(f, name); break;
                    case Kind.SLIDES: res = FileOps.ext(name).startsWith("od") || FileOps.ext(name).equals("otp") ? Odp.parse(f) : Pptx.parse(f); break;
                    case Kind.SHEET: res = loadSheet(f, name); break;
                    default: res = TextDoc.parse(f); break;
                }
            } catch (Throwable e) {
                err = "Couldn’t open this file" + (e.getMessage() == null ? "." : ": " + e.getMessage());
            }
            final Object r = res;
            final String er = err;
            ui.post(() -> {
                if (dead) return;
                if (er != null || r == null) { fail(er == null ? "Couldn’t open this file." : er); return; }
                if (r instanceof Doc) showDoc((Doc) r);
                else if (r instanceof Slides) showSlides((Slides) r);
                else if (r instanceof Sheets) showSheets((Sheets) r);
            });
        });
    }

    private static Doc loadDoc(File f, String name) throws IOException {
        String e = FileOps.ext(name);
        switch (e) {
            case "docx": case "docm": case "dotx": case "dotm": return Docx.parse(f);
            case "odt": case "ott": return Odt.parse(f);
            case "epub": return Epub.parse(f);
            default: return TextDoc.parse(f);
        }
    }

    private static Sheets loadSheet(File f, String name) throws IOException {
        String e = FileOps.ext(name);
        if (e.equals("ods") || e.equals("ots")) return Sheets.ods(f);
        if (e.equals("csv") || e.equals("tsv")) return Sheets.csv(f);
        return Sheets.xlsx(f);
    }

    private void fail(String msg) {
        content.removeAllViews();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(Ui.dp(32), Ui.dp(32), Ui.dp(32), Ui.dp(32));
        TextView m = label(msg, 15.5f, Ui.t.text, false);
        m.setGravity(Gravity.CENTER);
        box.addView(m);
        if (file != null) {
            TextView b = label("Open with another app", 15, Color.WHITE, true);
            b.setBackground(Ui.accent(22, 235));
            b.setPadding(Ui.dp(24), Ui.dp(11), Ui.dp(24), Ui.dp(11));
            b.setOnClickListener(v -> openWith());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.topMargin = Ui.dp(22);
            box.addView(b, lp);
        }
        content.addView(box, new FrameLayout.LayoutParams(MATCH, MATCH));
    }

    // ---- PDF ----------------------------------------------------------------------------------------
    private void showPdf(PdfView v) {
        pdf = v;
        content.removeAllViews();
        content.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
        v.setNight(night);
        v.setListener(new PdfView.Listener() {
            @Override public void onPage(int p, int n) { pageChip.setText((p + 1) + " / " + n); pageChip.setVisibility(View.VISIBLE); }
            @Override public void onTap() { }
        });
        nightBtn.setVisibility(View.VISIBLE);
        detail = v.pageCount() + " pages";
        subView.setText(detail + " · " + FileOps.humanSize(file.length()));
        int saved = prefs.getInt(posKey, 0);
        if (saved > 0) v.goTo(saved);
        pageChip.setText((Math.max(0, saved) + 1) + " / " + v.pageCount());
        pageChip.setVisibility(View.VISIBLE);
    }

    // ---- Word-like ----------------------------------------------------------------------------------
    private void showDoc(Doc d) {
        content.removeAllViews();
        docView = new DocView(this);
        docView.setBackgroundColor(Paper.bg);
        String e = FileOps.ext(name);
        boolean mono = kind == Kind.TEXT && !e.equals("md") && !e.equals("markdown");
        docView.setScale(prefs.getFloat("docScale", 1f));
        docView.setDoc(d, mono);
        content.addView(docView, new FrameLayout.LayoutParams(MATCH, MATCH));
        nightBtn.setVisibility(View.VISIBLE);
        textBtn.setVisibility(View.VISIBLE);
        findBtn.setVisibility(View.VISIBLE);
        if (!d.title.isEmpty() && kind != Kind.TEXT) titleView.setText(d.title);
        subView.setText(FileOps.humanSize(file.length()));
        detail = d.blocks.size() + " blocks";
        if (d.truncated) Toast.makeText(this, "This file is large – showing the first part.", Toast.LENGTH_LONG).show();
        int saved = prefs.getInt(posKey, 0);
        if (saved > 0) docView.jump(saved);
        if (d.blocks.isEmpty()) {
            TextView t = label("This document has no readable text.", 15, Ui.t.muted, false);
            t.setGravity(Gravity.CENTER);
            content.addView(t, new FrameLayout.LayoutParams(MATCH, MATCH));
        }
    }

    private void textSizeMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 1, 0, "Smaller text");
        m.getMenu().add(0, 2, 1, "Larger text");
        m.getMenu().add(0, 3, 2, "Reset size");
        m.setOnMenuItemClickListener(it -> {
            if (docView == null) return true;
            float s = docView.scale();
            if (it.getItemId() == 1) s -= 0.12f; else if (it.getItemId() == 2) s += 0.12f; else s = 1f;
            docView.setScale(s);
            prefs.edit().putFloat("docScale", docView.scale()).apply();
            return true;
        });
        m.show();
    }

    private void openFind() {
        if (docView == null) return;
        searchBar.setVisibility(View.VISIBLE);
        findBox.requestFocus();
        android.view.inputmethod.InputMethodManager im = (android.view.inputmethod.InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.showSoftInput(findBox, 0);
    }

    private void closeFind() {
        searchBar.setVisibility(View.GONE);
        findBox.setText("");
        if (docView != null) docView.setQuery("");
        android.view.inputmethod.InputMethodManager im = (android.view.inputmethod.InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(findBox.getWindowToken(), 0);
    }

    private void findStep(int dir) {
        if (docView == null) return;
        if (!docView.find(dir)) Toast.makeText(this, "No matches", Toast.LENGTH_SHORT).show();
    }

    // ---- slides -------------------------------------------------------------------------------------
    private void showSlides(final Slides s) {
        deck = s;
        content.removeAllViews();
        slideList = new ListView(this);
        slideList.setDivider(null);
        slideList.setDividerHeight(0);
        slideList.setSelector(new ColorDrawable(0));
        slideList.setCacheColorHint(0);
        slideList.setClipToPadding(false);
        slideList.setPadding(0, 0, 0, Ui.dp(24));
        slideList.setVerticalScrollBarEnabled(false);
        slideList.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return deck.slides.size(); }
            @Override public Object getItem(int i) { return deck.slides.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(final int i, View v, ViewGroup p) {
                LinearLayout row;
                SlideView sv;
                TextView cap;
                if (v == null) {
                    row = new LinearLayout(ReaderActivity.this);
                    row.setOrientation(LinearLayout.VERTICAL);
                    row.setPadding(Ui.dp(14), Ui.dp(8), Ui.dp(14), Ui.dp(4));
                    sv = new SlideView(ReaderActivity.this, false);
                    GradientDrawable g = new GradientDrawable();
                    g.setStroke(Math.max(1, Ui.dp(1)), Ui.t.panelBorder());
                    g.setCornerRadius(Ui.dp(6));
                    sv.setPadding(0, 0, 0, 0);
                    row.addView(sv, new LinearLayout.LayoutParams(MATCH, WRAP));
                    cap = label("", 12, Ui.t.muted, false);
                    cap.setPadding(Ui.dp(4), Ui.dp(4), 0, Ui.dp(4));
                    cap.setSingleLine(true);
                    row.addView(cap);
                    row.setTag(new Object[]{sv, cap});
                } else row = (LinearLayout) v;
                Object[] tag = (Object[]) row.getTag();
                sv = (SlideView) tag[0];
                cap = (TextView) tag[1];
                sv.setSlide(deck, deck.slides.get(i));
                String title = deck.slides.get(i).title;
                cap.setText((i + 1) + (title == null || title.isEmpty() ? "" : "  ·  " + title));
                row.setOnClickListener(x -> startPresent(i));
                return row;
            }
        });
        content.addView(slideList, new FrameLayout.LayoutParams(MATCH, MATCH));
        playBtn.setVisibility(View.VISIBLE);
        subView.setText(deck.slides.size() + " slides · " + FileOps.humanSize(file.length()));
        detail = deck.slides.size() + " slides";
        if (deck.truncated) Toast.makeText(this, "Showing the first 400 slides.", Toast.LENGTH_LONG).show();
        int saved = prefs.getInt(posKey, 0);
        if (saved > 0) slideList.setSelection(saved);
        if (deck.slides.isEmpty()) status.setText("This presentation has no slides.");
    }

    private void startPresent(int index) {
        if (deck == null || deck.slides.isEmpty()) return;
        presentIndex = Math.max(0, Math.min(deck.slides.size() - 1, index));
        if (present == null) {
            present = new FrameLayout(this) {
                @Override public boolean onTouchEvent(MotionEvent e) { return true; }
            };
            present.setBackgroundColor(0xFF000000);
            presentView = new SlideView(this, true);
            present.addView(presentView, new FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER));
            final android.view.GestureDetector gd = new android.view.GestureDetector(this, new android.view.GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onDown(MotionEvent e) { return true; }
                @Override public boolean onSingleTapUp(MotionEvent e) {
                    if (e.getX() < present.getWidth() / 3f) stepPresent(-1); else stepPresent(1);
                    return true;
                }
                @Override public boolean onFling(MotionEvent a, MotionEvent b, float vx, float vy) {
                    if (Math.abs(vx) > Math.abs(vy)) { stepPresent(vx < 0 ? 1 : -1); return true; }
                    if (vy > 1500) { endPresent(); return true; }
                    return false;
                }
            });
            present.setOnTouchListener((v, e) -> gd.onTouchEvent(e));
            root.addView(present, new FrameLayout.LayoutParams(MATCH, MATCH));
        }
        present.setVisibility(View.VISIBLE);
        pageChip.setVisibility(View.GONE);
        showPresent();
        WindowInsetsController wc = getWindow().getInsetsController();
        if (wc != null) {
            wc.hide(android.view.WindowInsets.Type.systemBars());
            wc.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        }
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void showPresent() {
        presentView.setSlide(deck, deck.slides.get(presentIndex));
    }

    private void stepPresent(int d) {
        int n = presentIndex + d;
        if (n < 0) return;
        if (n >= deck.slides.size()) { endPresent(); return; }
        presentIndex = n;
        showPresent();
    }

    private void endPresent() {
        present.setVisibility(View.GONE);
        WindowInsetsController wc = getWindow().getInsetsController();
        if (wc != null) wc.show(android.view.WindowInsets.Type.systemBars());
        getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (slideList != null) slideList.setSelection(presentIndex);
    }

    // ---- spreadsheets -------------------------------------------------------------------------------
    private void showSheets(final Sheets s) {
        sheets = s;
        content.removeAllViews();
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        cellBar = label("Tap a cell to see its full text · long-press to copy", 13, Ui.t.muted, false);
        cellBar.setBackground(Ui.panel(14));
        cellBar.setPadding(Ui.dp(12), Ui.dp(7), Ui.dp(12), Ui.dp(7));
        cellBar.setMaxLines(3);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(MATCH, WRAP);
        cp.setMargins(Ui.dp(10), 0, Ui.dp(10), Ui.dp(6));
        col.addView(cellBar, cp);
        sheetView = new SheetView(this);
        sheetView.setListener(new SheetView.Listener() {
            @Override public void onCell(String ref, String text) {
                cellBar.setTextColor(Ui.t.text);
                cellBar.setText(ref + "   " + text);
            }
            @Override public void onLongCell(String text) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("cell", text));
                Toast.makeText(ReaderActivity.this, "Copied", Toast.LENGTH_SHORT).show();
            }
        });
        col.addView(sheetView, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        if (s.sheets.size() > 1) {
            HorizontalScrollView hs = new HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            tabsRow = new LinearLayout(this);
            tabsRow.setPadding(Ui.dp(8), Ui.dp(6), Ui.dp(8), Ui.dp(6));
            hs.addView(tabsRow, new FrameLayout.LayoutParams(WRAP, WRAP));
            col.addView(hs, new LinearLayout.LayoutParams(MATCH, WRAP));
        }
        content.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));
        nightBtn.setVisibility(View.VISIBLE);
        selectSheet(Math.min(prefs.getInt(posKey, 0), Math.max(0, s.sheets.size() - 1)));
        int cells = 0;
        for (Sheets.Sheet sh : s.sheets) cells += sh.rows.size();
        detail = s.sheets.size() + (s.sheets.size() == 1 ? " sheet" : " sheets");
        subView.setText(detail + " · " + FileOps.humanSize(file.length()));
        if (s.truncated) Toast.makeText(this, "This file is large – showing the first part.", Toast.LENGTH_LONG).show();
    }

    private int sheetIndex;

    private void selectSheet(int i) {
        if (sheets == null || sheets.sheets.isEmpty()) return;
        sheetIndex = i;
        sheetView.setSheet(sheets.sheets.get(i));
        if (cellBar != null) { cellBar.setTextColor(Ui.t.muted); cellBar.setText(sheets.sheets.get(i).name.isEmpty() ? "Tap a cell to see its full text" : sheets.sheets.get(i).name + " · " + sheets.sheets.get(i).rows.size() + " rows"); }
        if (tabsRow != null) {
            tabsRow.removeAllViews();
            for (int k = 0; k < sheets.sheets.size(); k++) {
                final int kk = k;
                TextView tv = label(sheets.sheets.get(k).name.isEmpty() ? "Sheet " + (k + 1) : sheets.sheets.get(k).name, 13.5f,
                        k == i ? Color.WHITE : Ui.t.text, k == i);
                tv.setSingleLine(true);
                tv.setPadding(Ui.dp(14), Ui.dp(7), Ui.dp(14), Ui.dp(7));
                tv.setBackground(k == i ? Ui.accent(16, 235) : Ui.panel(16));
                tv.setOnClickListener(v -> selectSheet(kk));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
                lp.rightMargin = Ui.dp(6);
                tabsRow.addView(tv, lp);
            }
        }
    }

    // ---- misc actions -------------------------------------------------------------------------------
    private void toggleNight() {
        night = !night;
        prefs.edit().putBoolean("night", night).apply();
        Paper.set(night);
        nightBtn.setOn(night);
        if (pdf != null) pdf.setNight(night);
        if (docView != null) docView.refreshColours();
        if (sheetView != null) sheetView.invalidate();
    }

    private void jumpDialog() {
        if (pdf == null) return;
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setHint("Page 1–" + pdf.pageCount());
        et.setPadding(Ui.dp(24), Ui.dp(16), Ui.dp(24), Ui.dp(8));
        new AlertDialog.Builder(this).setTitle("Go to page").setView(et)
                .setPositiveButton("Go", (d, w) -> {
                    try { pdf.goTo(Integer.parseInt(et.getText().toString().trim()) - 1); } catch (NumberFormatException ignored) { }
                }).setNegativeButton("Cancel", null).show();
    }

    private void moreMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 1, 0, "Share");
        m.getMenu().add(0, 2, 1, "Open with…");
        m.getMenu().add(0, 3, 2, "Details");
        m.getMenu().add(0, 4, 3, "Appearance");
        m.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1: share(); break;
                case 2: openWith(); break;
                case 3: details(); break;
                default: Look.appearanceDialog(this, prefs);
            }
            return true;
        });
        m.show();
    }

    private Uri shareUri() { return origUri != null ? origUri : FileShareProvider.uriFor(file); }

    private String mime() {
        String m = FileShareProvider.mimeOf(name);
        return m;
    }

    private void share() {
        if (file == null) return;
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(mime());
        i.putExtra(Intent.EXTRA_STREAM, shareUri());
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivity(Intent.createChooser(i, "Share")); } catch (ActivityNotFoundException ignored) { }
    }

    private void openWith() {
        if (file == null) return;
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(shareUri(), mime());
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        // don't offer ourselves
        try { startActivity(Intent.createChooser(i, "Open with")); }
        catch (ActivityNotFoundException e) { Toast.makeText(this, "No other app can open this.", Toast.LENGTH_SHORT).show(); }
    }

    private void details() {
        if (file == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("Name: ").append(name).append('\n');
        sb.append("Size: ").append(FileOps.humanSize(file.length())).append('\n');
        sb.append("Modified: ").append(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(new Date(file.lastModified()))).append('\n');
        if (!detail.isEmpty()) sb.append("Contents: ").append(detail).append('\n');
        if (origUri == null) sb.append("Location: ").append(file.getParent());
        new AlertDialog.Builder(this).setTitle("Details").setMessage(sb.toString()).setPositiveButton("Close", null).show();
    }

    private void savePos() {
        if (posKey == null) return;
        int p = -1;
        if (pdf != null) p = pdf.page();
        else if (docView != null) p = docView.position();
        else if (slideList != null) p = slideList.getFirstVisiblePosition();
        else if (sheets != null) p = sheetIndex;
        if (p >= 0) prefs.edit().putInt(posKey, p).apply();
    }
}
