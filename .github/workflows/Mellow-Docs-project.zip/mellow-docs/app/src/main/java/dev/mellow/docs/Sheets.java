package dev.mellow.docs;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Spreadsheets (.xlsx, .ods, .csv) as plain grids of display text. Pure Java. */
final class Sheets {
    final List<Sheet> sheets = new ArrayList<>();
    boolean truncated;

    static final class Sheet {
        String name = "";
        final List<String[]> rows = new ArrayList<>();
        int cols;
        float[] colChars = new float[0];      // width of each column in characters

        void finish(float[] explicit) {
            int c = 0;
            for (String[] r : rows) c = Math.max(c, r.length);
            cols = c;
            colChars = new float[c];
            for (int i = 0; i < c; i++) {
                float w = 0;
                int lim = Math.min(rows.size(), 400);
                for (int r = 0; r < lim; r++) {
                    String[] row = rows.get(r);
                    if (i < row.length && row[i] != null) {
                        String t = row[i];
                        int nl = t.indexOf('\n');
                        if (nl >= 0) t = t.substring(0, nl);
                        w = Math.max(w, t.length());
                    }
                }
                colChars[i] = Math.max(5f, Math.min(42f, w + 1.5f));
                if (explicit != null && i < explicit.length && explicit[i] > 0) colChars[i] = Math.max(4f, Math.min(60f, explicit[i]));
            }
        }
    }

    private static final int MAX_ROWS = 100000, MAX_COLS = 256;

    // ---- xlsx ---------------------------------------------------------------------------------------
    static Sheets xlsx(File f) throws IOException {
        try (Pkg p = new Pkg(f)) {
            Xml wb = p.xml("xl/workbook.xml");
            if (wb == null) throw new IOException("This is not an Excel (.xlsx) file");
            List<String> names = new ArrayList<>(), rids = new ArrayList<>();
            while (wb.next() != Xml.EOF) {
                if (wb.is("sheet")) { names.add(wb.attr("name", "Sheet")); rids.add(wb.attr("r:id", "")); }
            }
            Map<String, Pkg.Rel> rels = p.rels("xl/workbook.xml");
            List<String> shared = sharedStrings(p, rels);
            Map<Integer, String> fmtCodes = new HashMap<>();
            List<Integer> xfFmt = styles(p, fmtCodes);
            Sheets out = new Sheets();
            for (int i = 0; i < names.size(); i++) {
                Pkg.Rel r = rels.get(rids.get(i));
                if (r == null || r.target == null) continue;
                Xml x = p.xml(r.target);
                if (x == null) continue;
                Sheet sh = new Sheet();
                sh.name = names.get(i);
                out.truncated |= readSheet(x, sh, shared, xfFmt, fmtCodes);
                out.sheets.add(sh);
            }
            return out;
        }
    }

    private static List<String> sharedStrings(Pkg p, Map<String, Pkg.Rel> rels) {
        List<String> out = new ArrayList<>();
        String path = "xl/sharedStrings.xml";
        for (Pkg.Rel r : rels.values()) if (r.type.endsWith("/sharedStrings") && r.target != null) path = r.target;
        Xml x = p.xml(path);
        if (x == null) return out;
        while (x.next() != Xml.EOF) {
            if (x.is("si")) {
                StringBuilder sb = new StringBuilder();
                int d = x.depth;
                while (x.next() != Xml.EOF) {
                    if (x.type == Xml.END && x.depth == d) break;
                    if (x.is("rPh")) x.skip();
                    else if (x.is("t")) sb.append(x.textOf());
                }
                out.add(sb.toString());
            }
        }
        return out;
    }

    private static List<Integer> styles(Pkg p, Map<Integer, String> codes) {
        List<Integer> xf = new ArrayList<>();
        Xml x = p.xml("xl/styles.xml");
        if (x == null) return xf;
        boolean inCellXfs = false;
        while (x.next() != Xml.EOF) {
            if (x.is("numFmt")) codes.put(x.attrInt("numFmtId", -1), x.attr("formatCode", ""));
            else if (x.is("cellXfs")) inCellXfs = true;
            else if (x.type == Xml.END && x.name.equals("cellXfs")) inCellXfs = false;
            else if (inCellXfs && x.is("xf")) xf.add(x.attrInt("numFmtId", 0));
        }
        return xf;
    }

    private static boolean isDateFmt(int id, String code) {
        if ((id >= 14 && id <= 22) || (id >= 27 && id <= 36) || (id >= 45 && id <= 47) || (id >= 50 && id <= 58)) return true;
        if (code == null) return false;
        String c = code.toLowerCase(Locale.ROOT).replaceAll("\\[[^\\]]*\\]", "").replaceAll("\"[^\"]*\"", "");
        return c.contains("yy") || c.contains("dd") || c.contains("mmm") || (c.contains("h") && c.contains("mm")) || c.contains("m/d") || c.contains("d/m");
    }

    private static boolean readSheet(Xml x, Sheet sh, List<String> shared, List<Integer> xfFmt, Map<Integer, String> codes) {
        boolean trunc = false;
        float[] explicit = new float[MAX_COLS];
        int lastRow = 0;
        while (x.next() != Xml.EOF) {
            if (x.is("col")) {
                int mn = x.attrInt("min", 0), mx = x.attrInt("max", 0);
                float w = (float) x.attrDouble("width", 0);
                boolean hidden = "1".equals(x.attr("hidden"));
                for (int c = Math.max(1, mn); c <= Math.min(mx, MAX_COLS); c++) explicit[c - 1] = hidden ? 0.1f : w;
            } else if (x.is("row")) {
                int rn = x.attrInt("r", lastRow + 1);
                if (rn > MAX_ROWS) { trunc = true; break; }
                while (sh.rows.size() < rn - 1 && sh.rows.size() < MAX_ROWS) sh.rows.add(new String[0]);
                lastRow = rn;
                List<String> cells = new ArrayList<>();
                int d = x.depth;
                int col = 0;
                while (x.next() != Xml.EOF) {
                    if (x.type == Xml.END && x.depth == d) break;
                    if (!x.is("c")) continue;
                    String ref = x.attr("r");
                    int ci = ref != null ? colIndex(ref) : col;
                    col = ci + 1;
                    String t = x.attr("t", "n");
                    int sIdx = x.attrInt("s", 0);
                    String v = null, inline = null;
                    int dc = x.depth;
                    while (x.next() != Xml.EOF) {
                        if (x.type == Xml.END && x.depth == dc) break;
                        if (x.is("v")) v = x.textOf();
                        else if (x.is("is")) {
                            StringBuilder sb = new StringBuilder();
                            int di = x.depth;
                            while (x.next() != Xml.EOF) {
                                if (x.type == Xml.END && x.depth == di) break;
                                if (x.is("t")) sb.append(x.textOf());
                            }
                            inline = sb.toString();
                        }
                    }
                    if (ci >= MAX_COLS) continue;
                    String text = "";
                    switch (t) {
                        case "s": { try { text = shared.get(Integer.parseInt(v.trim())); } catch (Exception e) { text = ""; } break; }
                        case "inlineStr": text = inline == null ? "" : inline; break;
                        case "b": text = "1".equals(v) ? "TRUE" : "FALSE"; break;
                        case "str": case "e": text = v == null ? "" : v; break;
                        default: {
                            if (v == null || v.trim().isEmpty()) break;
                            int fid = sIdx < xfFmt.size() ? xfFmt.get(sIdx) : 0;
                            text = number(v.trim(), fid, codes.get(fid));
                            break;
                        }
                    }
                    while (cells.size() < ci) cells.add("");
                    if (cells.size() == ci) cells.add(text); else cells.set(ci, text);
                }
                sh.rows.add(cells.toArray(new String[0]));
            }
        }
        // drop trailing empty rows
        while (!sh.rows.isEmpty() && isEmpty(sh.rows.get(sh.rows.size() - 1))) sh.rows.remove(sh.rows.size() - 1);
        sh.finish(explicit);
        return trunc;
    }

    private static boolean isEmpty(String[] r) {
        for (String s : r) if (s != null && !s.isEmpty()) return false;
        return true;
    }

    static int colIndex(String ref) {
        int c = 0;
        for (int i = 0; i < ref.length(); i++) {
            char ch = ref.charAt(i);
            if (ch >= 'A' && ch <= 'Z') c = c * 26 + (ch - 'A' + 1);
            else if (ch >= 'a' && ch <= 'z') c = c * 26 + (ch - 'a' + 1);
            else break;
        }
        return Math.max(0, c - 1);
    }

    static String colName(int i) {
        StringBuilder sb = new StringBuilder();
        i++;
        while (i > 0) { i--; sb.insert(0, (char) ('A' + i % 26)); i /= 26; }
        return sb.toString();
    }

    static String number(String v, int fmtId, String code) {
        double d;
        try { d = Double.parseDouble(v); } catch (NumberFormatException e) { return v; }
        if (Double.isNaN(d) || Double.isInfinite(d)) return v;
        if (isDateFmt(fmtId, code)) {
            try {
                long days = (long) Math.floor(d);
                double frac = d - days;
                LocalDate date = LocalDate.of(1899, 12, 30).plusDays(days);
                int secs = (int) Math.round(frac * 86400);
                String c = code == null ? "" : code.toLowerCase(Locale.ROOT);
                boolean hasTime = frac > 0.00001 || (c.contains("h") && c.contains(":"));
                boolean hasDate = days > 0 || !hasTime;
                if (days <= 0 && hasTime) return String.format(Locale.ROOT, "%02d:%02d", secs / 3600, (secs % 3600) / 60);
                LocalDateTime dt = date.atStartOfDay().plusSeconds(secs);
                String ds = String.format(Locale.ROOT, "%04d-%02d-%02d", dt.getYear(), dt.getMonthValue(), dt.getDayOfMonth());
                return hasTime && frac > 0.00001 ? ds + String.format(Locale.ROOT, " %02d:%02d", dt.getHour(), dt.getMinute()) : ds;
            } catch (Exception e) { return v; }
        }
        String first = code == null ? "" : code.split(";")[0];
        boolean percent = first.contains("%");
        if (percent) d *= 100;
        int decimals = -1;
        boolean thousands = false;
        String prefix = "";
        if (!first.isEmpty() && !first.equalsIgnoreCase("general")) {
            int dot = first.indexOf('.');
            if (dot >= 0) {
                int n = 0;
                for (int i = dot + 1; i < first.length() && (first.charAt(i) == '0' || first.charAt(i) == '#'); i++) n++;
                decimals = n;
            } else if (first.contains("0") || first.contains("#")) {
                decimals = 0;
            }
            thousands = first.contains(",") && (first.indexOf(',') < Math.max(first.indexOf('0'), first.indexOf('#')) + 3);
            if (first.contains("$")) prefix = "$";
            else if (first.contains("€")) prefix = "€";
            else if (first.contains("£")) prefix = "£";
        }
        if (fmtId == 9) { decimals = 0; percent = true; d = Double.parseDouble(v) * 100; }
        if (fmtId == 10) { decimals = 2; percent = true; d = Double.parseDouble(v) * 100; }
        if (fmtId == 2) decimals = 2;
        if (fmtId == 3) { decimals = 0; thousands = true; }
        if (fmtId == 4) { decimals = 2; thousands = true; }
        String s;
        if (decimals >= 0) {
            s = new BigDecimal(d).setScale(decimals, java.math.RoundingMode.HALF_UP).toPlainString();
            if (thousands) s = group(s);
        } else {
            BigDecimal bd = new BigDecimal(d).round(new MathContext(12)).stripTrailingZeros();
            s = bd.toPlainString();
        }
        if (s.startsWith("-") && !prefix.isEmpty()) s = "-" + prefix + s.substring(1); else s = prefix + s;
        return percent ? s + "%" : s;
    }

    private static String group(String s) {
        boolean neg = s.startsWith("-");
        if (neg) s = s.substring(1);
        int dot = s.indexOf('.');
        String ip = dot >= 0 ? s.substring(0, dot) : s, fp = dot >= 0 ? s.substring(dot) : "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ip.length(); i++) {
            if (i > 0 && (ip.length() - i) % 3 == 0) sb.append(',');
            sb.append(ip.charAt(i));
        }
        return (neg ? "-" : "") + sb + fp;
    }

    // ---- ods ---------------------------------------------------------------------------------------
    static Sheets ods(File f) throws IOException {
        try (Pkg p = new Pkg(f)) {
            Xml x = p.xml("content.xml");
            if (x == null) throw new IOException("This is not an OpenDocument spreadsheet");
            Sheets out = new Sheets();
            while (x.next() != Xml.EOF) {
                if (x.is("table") && x.prefix.equals("table")) {
                    Sheet sh = new Sheet();
                    sh.name = x.attr("name", "Sheet");
                    out.truncated |= odsTable(x, sh);
                    out.sheets.add(sh);
                }
            }
            return out;
        }
    }

    private static boolean odsTable(Xml x, Sheet sh) {
        boolean trunc = false;
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (!x.is("table-row")) continue;
            int rep = x.attrInt("number-rows-repeated", 1);
            List<String> cells = new ArrayList<>();
            int dr = x.depth;
            while (x.next() != Xml.EOF) {
                if (x.type == Xml.END && x.depth == dr) break;
                if (x.is("table-cell") || x.is("covered-table-cell")) {
                    int crep = x.attrInt("number-columns-repeated", 1);
                    String vt = x.attr("value-type", "");
                    String val = x.attr("value");
                    String sval = x.attr("string-value");
                    String date = x.attr("date-value");
                    boolean covered = x.name.equals("covered-table-cell");
                    StringBuilder sb = new StringBuilder();
                    int dc = x.depth;
                    int paras = 0;
                    while (x.next() != Xml.EOF) {
                        if (x.type == Xml.END && x.depth == dc) break;
                        if (x.is("p")) {
                            if (paras++ > 0) sb.append('\n');
                            sb.append(odText(x));
                        }
                    }
                    String text = sb.toString();
                    if (text.isEmpty()) {
                        if (sval != null) text = sval;
                        else if (date != null) text = date.replace('T', ' ');
                        else if (val != null && !vt.equals("string")) text = number(val, 0, null);
                    }
                    if (covered) text = "";
                    if (text.isEmpty() && crep > 8) continue;
                    for (int i = 0; i < Math.min(crep, 64) && cells.size() < MAX_COLS; i++) cells.add(text);
                }
            }
            boolean blank = true;
            for (String c : cells) if (!c.isEmpty()) { blank = false; break; }
            int times = blank ? Math.min(rep, 3) : Math.min(rep, 200);
            for (int i = 0; i < times && sh.rows.size() < MAX_ROWS; i++) sh.rows.add(cells.toArray(new String[0]));
            if (sh.rows.size() >= MAX_ROWS) { trunc = true; break; }
        }
        while (!sh.rows.isEmpty() && isEmpty(sh.rows.get(sh.rows.size() - 1))) sh.rows.remove(sh.rows.size() - 1);
        sh.finish(null);
        return trunc;
    }

    /** Text of an ODF paragraph (x on text:p), leaving x on its END. */
    static String odText(Xml x) {
        StringBuilder sb = new StringBuilder();
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type == Xml.TEXT) sb.append(x.text);
            else if (x.is("s")) { int n = Math.max(1, Math.min(100, x.attrInt("c", 1))); for (int i = 0; i < n; i++) sb.append(' '); }
            else if (x.is("tab")) sb.append('\t');
            else if (x.is("line-break")) sb.append('\n');
        }
        return sb.toString();
    }

    // ---- csv ---------------------------------------------------------------------------------------
    static Sheets csv(File f) throws IOException {
        boolean[] tr = new boolean[1];
        String text = TextDoc.readText(f, tr);
        Sheets out = new Sheets();
        out.truncated = tr[0];
        Sheet sh = new Sheet();
        sh.name = f.getName();
        int firstNl = text.indexOf('\n');
        String head = firstNl < 0 ? text : text.substring(0, firstNl);
        char delim = ',';
        int best = count(head, ',');
        if (count(head, ';') > best) { delim = ';'; best = count(head, ';'); }
        if (count(head, '\t') > best) { delim = '\t'; best = count(head, '\t'); }
        if (count(head, '|') > best) { delim = '|'; }
        if (f.getName().toLowerCase(Locale.ROOT).endsWith(".tsv")) delim = '\t';
        List<String> row = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean q = false;
        int n = text.length();
        for (int i = 0; i < n; i++) {
            char c = text.charAt(i);
            if (q) {
                if (c == '"') {
                    if (i + 1 < n && text.charAt(i + 1) == '"') { cur.append('"'); i++; } else q = false;
                } else cur.append(c);
            } else if (c == '"' && cur.length() == 0) {
                q = true;
            } else if (c == delim) {
                row.add(cur.toString());
                cur.setLength(0);
            } else if (c == '\n' || c == '\r') {
                if (c == '\r' && i + 1 < n && text.charAt(i + 1) == '\n') i++;
                row.add(cur.toString());
                cur.setLength(0);
                sh.rows.add(row.toArray(new String[0]));
                row = new ArrayList<>();
                if (sh.rows.size() >= MAX_ROWS) { out.truncated = true; break; }
            } else cur.append(c);
        }
        if (cur.length() > 0 || !row.isEmpty()) { row.add(cur.toString()); sh.rows.add(row.toArray(new String[0])); }
        sh.finish(null);
        out.sheets.add(sh);
        return out;
    }

    private static int count(String s, char c) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == c) n++;
        return n;
    }
}
