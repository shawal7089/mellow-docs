package dev.mellow.docs;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.AlignmentSpan;
import android.text.style.BackgroundColorSpan;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.LeadingMarginSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.SubscriptSpan;
import android.text.style.SuperscriptSpan;
import android.text.style.TypefaceSpan;
import android.text.style.UnderlineSpan;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;
import java.util.Locale;

/** Reflowing document reader: a list of paragraphs, tables and pictures. */
final class DocView extends ListView {
    private Doc doc;
    private boolean mono;
    private float scale = 1f;
    private String query = "";
    private final Adapter adapter = new Adapter();
    private final LruCache<Integer, CharSequence> spans = new LruCache<>(300);

    DocView(Context c) {
        super(c);
        setDivider(null);
        setDividerHeight(0);
        setSelector(android.R.color.transparent);
        setVerticalScrollBarEnabled(true);
        setClipToPadding(false);
        setCacheColorHint(0);
        setAdapter(adapter);
    }

    void setDoc(Doc d, boolean monospace) {
        doc = d;
        mono = monospace;
        spans.evictAll();
        adapter.notifyDataSetChanged();
    }

    void setScale(float s) {
        scale = Math.max(0.7f, Math.min(2.4f, s));
        spans.evictAll();
        adapter.notifyDataSetChanged();
    }

    float scale() { return scale; }

    void refreshColours() {
        spans.evictAll();
        setBackgroundColor(Paper.bg);
        adapter.notifyDataSetChanged();
    }

    void setQuery(String q) {
        query = q == null ? "" : q.toLowerCase(Locale.ROOT);
        spans.evictAll();
        adapter.notifyDataSetChanged();
    }

    /** Finds the next (dir=1) or previous (dir=-1) block holding the query. Returns false when none. */
    boolean find(int dir) {
        if (doc == null || query.isEmpty()) return false;
        int n = doc.blocks.size();
        int start = getFirstVisiblePosition();
        if (dir > 0) start = start + (lastFound == start ? 1 : 0); else start = start - 1;
        for (int k = 0; k < n; k++) {
            int i = ((start + dir * k) % n + n) % n;
            if (blockText(doc.blocks.get(i)).toLowerCase(Locale.ROOT).contains(query)) {
                lastFound = i;
                setSelectionFromTop(i, Ui.dp(90));
                return true;
            }
        }
        return false;
    }

    private int lastFound = -1;

    int position() { return getFirstVisiblePosition(); }

    void jump(int pos) { setSelection(Math.max(0, Math.min(adapter.getCount() - 1, pos))); }

    private static String blockText(Doc.Block b) {
        if (b instanceof Doc.Para) return ((Doc.Para) b).text();
        if (b instanceof Doc.Table) {
            StringBuilder sb = new StringBuilder();
            for (List<Doc.Cell> r : ((Doc.Table) b).rows) for (Doc.Cell c : r) for (Doc.Block x : c.blocks) sb.append(blockText(x)).append(' ');
            return sb.toString();
        }
        return "";
    }

    // ---- building spans -----------------------------------------------------------------------------
    private float baseSp() { return (mono ? 13f : 16.5f) * scale; }

    private CharSequence spannable(final Doc.Para p, boolean forCell) {
        SpannableStringBuilder sb = new SpannableStringBuilder();
        if (p.level >= 0 && !p.bullet.isEmpty()) sb.append(p.bullet).append("  ");
        final int bulletLen = sb.length();
        for (Doc.Run r : p.runs) {
            if (r.text.isEmpty()) continue;
            int s = sb.length();
            sb.append(r.text);
            int e = sb.length();
            int flags = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE;
            boolean bold = r.b || p.heading > 0 || p.title;
            boolean ital = r.i || p.quote;
            if (bold && ital) sb.setSpan(new StyleSpan(Typeface.BOLD_ITALIC), s, e, flags);
            else if (bold) sb.setSpan(new StyleSpan(Typeface.BOLD), s, e, flags);
            else if (ital) sb.setSpan(new StyleSpan(Typeface.ITALIC), s, e, flags);
            if (r.u && r.link == null) sb.setSpan(new UnderlineSpan(), s, e, flags);
            if (r.s) sb.setSpan(new StrikethroughSpan(), s, e, flags);
            if (r.mono || p.code) sb.setSpan(new TypefaceSpan("monospace"), s, e, flags);
            if (r.sup) sb.setSpan(new SuperscriptSpan(), s, e, flags);
            if (r.sub) sb.setSpan(new SubscriptSpan(), s, e, flags);
            if (r.size > 0 && p.heading == 0 && !p.title) {
                float rel = Math.max(0.6f, Math.min(3f, r.size / 11f));
                if (Math.abs(rel - 1f) > 0.04f) sb.setSpan(new RelativeSizeSpan(rel), s, e, flags);
            }
            if (r.link != null) {
                final String url = r.link;
                final Context ctx = getContext();
                sb.setSpan(new ClickableSpan() {
                    @Override public void onClick(View v) { openLink(ctx, url); }
                    @Override public void updateDrawState(android.text.TextPaint ds) {
                        ds.setColor(Paper.link);
                        ds.setUnderlineText(true);
                    }
                }, s, e, flags);
            } else if (r.color != 0) {
                sb.setSpan(new ForegroundColorSpan(Paper.fix(r.color)), s, e, flags);
            }
        }
        if (!query.isEmpty()) {
            String low = sb.toString().toLowerCase(Locale.ROOT);
            int i = low.indexOf(query);
            while (i >= 0) {
                sb.setSpan(new BackgroundColorSpan(Paper.hi), i, i + query.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                i = low.indexOf(query, i + query.length());
            }
        }
        if (p.level >= 0 && bulletLen > 0) {
            sb.setSpan(new LeadingMarginSpan.Standard(0, Ui.dp(18)), 0, sb.length(), Spanned.SPAN_PARAGRAPH);
        }
        if (p.align == 1) sb.setSpan(new AlignmentSpan.Standard(Layout.Alignment.ALIGN_CENTER), 0, sb.length(), Spanned.SPAN_PARAGRAPH);
        else if (p.align == 2) sb.setSpan(new AlignmentSpan.Standard(Layout.Alignment.ALIGN_OPPOSITE), 0, sb.length(), Spanned.SPAN_PARAGRAPH);
        return sb;
    }

    static void openLink(Context c, String url) {
        try {
            if (url.startsWith("#")) return;
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (ActivityNotFoundException | SecurityException ignored) {
        }
    }

    private float headingMul(Doc.Para p) {
        if (p.title) return 1.9f;
        switch (p.heading) {
            case 1: return 1.6f;
            case 2: return 1.4f;
            case 3: return 1.22f;
            case 4: return 1.1f;
            case 5: case 6: return 1.0f;
            default: return 1f;
        }
    }

    private TextView paraView(Context c, Doc.Para p, int pos, boolean cell) {
        TextView tv = new TextView(c);
        bindPara(tv, p, pos, cell);
        return tv;
    }

    private void bindPara(TextView tv, Doc.Para p, int pos, boolean cell) {
        CharSequence cs = pos >= 0 ? spans.get(pos) : null;
        if (cs == null) {
            cs = spannable(p, cell);
            if (pos >= 0) spans.put(pos, cs);
        }
        tv.setText(cs);
        tv.setTextColor(Paper.fg);
        tv.setLinkTextColor(Paper.link);
        float mul = headingMul(p);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, cell ? 14f * scale : baseSp() * mul);
        tv.setTypeface(mono || p.code ? Typeface.MONOSPACE : Typeface.DEFAULT);
        tv.setLineSpacing(0, p.lineMult > 0 ? Math.max(1f, Math.min(1.8f, p.lineMult)) : (mono ? 1.1f : 1.22f));
        int left = Ui.dp(18), right = Ui.dp(18);
        if (cell) { left = right = Ui.dp(8); }
        else {
            left += Math.min(Ui.dp(120), Math.round(p.indentPt * Ui.density * 0.6f));
            if (p.level >= 0) left += Ui.dp(10) * Math.min(p.level, 5);
        }
        int topPad = cell ? Ui.dp(5) : Math.min(Ui.dp(30), Math.round(p.spaceBeforePt * Ui.density * 0.7f));
        int botPad = cell ? Ui.dp(5) : Math.max(Ui.dp(mono ? 0 : 6), Math.min(Ui.dp(24), Math.round(p.spaceAfterPt * Ui.density * 0.7f)));
        if (!cell && (p.heading > 0 || p.title)) { topPad = Math.max(topPad, Ui.dp(14)); botPad = Math.max(botPad, Ui.dp(6)); }
        if (!cell && p.isBlank()) { tv.setPadding(left, 0, right, 0); tv.setMinHeight(Ui.dp(mono ? 10 : 8)); }
        else { tv.setPadding(left, topPad, right, botPad); tv.setMinHeight(0); }
        if (p.code && !cell) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(Paper.codeBg);
            g.setCornerRadius(Ui.dp(8));
            tv.setBackground(g);
        } else if (p.quote && !cell) {
            tv.setBackground(new QuoteBar());
            tv.setPadding(left + Ui.dp(10), topPad, right, botPad);
        } else {
            tv.setBackground(null);
        }
        if (p.align == 3 && android.os.Build.VERSION.SDK_INT >= 26) tv.setJustificationMode(Layout.JUSTIFICATION_MODE_INTER_WORD);
        tv.setTextIsSelectable(true);
        tv.setMovementMethod(LinkMovementMethod.getInstance());
    }

    private static final class QuoteBar extends android.graphics.drawable.Drawable {
        private final android.graphics.Paint p = new android.graphics.Paint();
        @Override public void draw(android.graphics.Canvas c) {
            p.setColor(Paper.rule);
            android.graphics.Rect b = getBounds();
            c.drawRect(b.left + Ui.dp(18), b.top + Ui.dp(4), b.left + Ui.dp(21), b.bottom - Ui.dp(4), p);
        }
        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(android.graphics.ColorFilter f) { }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private View tableView(Context c, Doc.Table t) {
        int cols = 1;
        for (List<Doc.Cell> r : t.rows) { int n = 0; for (Doc.Cell x : r) n += Math.max(1, x.span); cols = Math.max(cols, n); }
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        int cellW = cols <= 3 ? 0 : Ui.dp(130);
        for (List<Doc.Cell> r : t.rows) {
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (Doc.Cell cell : r) {
                StringBuilder txt = new StringBuilder();
                LinearLayout col = new LinearLayout(c);
                col.setOrientation(LinearLayout.VERTICAL);
                for (Doc.Block b : cell.blocks) {
                    if (b instanceof Doc.Para) {
                        Doc.Para p = (Doc.Para) b;
                        if (p.isBlank() && cell.blocks.size() > 1) continue;
                        col.addView(paraView(c, p, -1, true));
                    }
                }
                GradientDrawable g = new GradientDrawable();
                g.setColor(cell.bg != 0 ? Paper.night ? Palette.alpha(cell.bg, 90) : cell.bg : cell.header ? Paper.codeBg : 0);
                g.setStroke(Math.max(1, Ui.dp(0.7f)), Paper.cellLine);
                col.setBackground(g);
                int span = Math.max(1, cell.span);
                LinearLayout.LayoutParams lp = cellW == 0
                        ? new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, span)
                        : new LinearLayout.LayoutParams(cellW * span, ViewGroup.LayoutParams.MATCH_PARENT);
                row.addView(col, lp);
            }
            box.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                cellW == 0 ? ViewGroup.LayoutParams.MATCH_PARENT : cellW * cols, ViewGroup.LayoutParams.WRAP_CONTENT);
        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setFillViewport(true);
        hs.setPadding(Ui.dp(12), Ui.dp(6), Ui.dp(12), Ui.dp(10));
        hs.addView(box, bp);
        return hs;
    }

    private final class Adapter extends BaseAdapter {
        @Override public int getCount() { return doc == null ? 0 : doc.blocks.size(); }
        @Override public Object getItem(int i) { return doc.blocks.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public int getViewTypeCount() { return 4; }
        @Override public int getItemViewType(int i) {
            Doc.Block b = doc.blocks.get(i);
            if (b instanceof Doc.Para) return 0;
            if (b instanceof Doc.Pic) return 1;
            if (b instanceof Doc.Rule) return 2;
            return 3;   // tables rebuild every time
        }
        @Override public boolean isEnabled(int i) { return false; }

        @Override public View getView(int i, View v, ViewGroup parent) {
            Context c = parent.getContext();
            Doc.Block b = doc.blocks.get(i);
            if (b instanceof Doc.Para) {
                TextView tv = v instanceof TextView ? (TextView) v : new TextView(c);
                bindPara(tv, (Doc.Para) b, i, false);
                return tv;
            }
            if (b instanceof Doc.Pic) return picView(c, (Doc.Pic) b, v);
            if (b instanceof Doc.Rule) {
                View r = v != null ? v : new View(c);
                boolean page = ((Doc.Rule) b).page;
                r.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(page ? 28 : 14)));
                r.setBackground(new RuleDraw(page));
                return r;
            }
            if (b instanceof Doc.Table) return tableView(c, (Doc.Table) b);
            TextView tv = new TextView(c);
            tv.setText(String.valueOf(((Doc.Raw) b).text));
            tv.setTextColor(Paper.fg);
            return tv;
        }
    }

    private static final class RuleDraw extends android.graphics.drawable.Drawable {
        private final android.graphics.Paint p = new android.graphics.Paint();
        private final boolean page;
        RuleDraw(boolean page) { this.page = page; }
        @Override public void draw(android.graphics.Canvas c) {
            p.setColor(Paper.rule);
            android.graphics.Rect b = getBounds();
            float y = b.exactCenterY();
            int m = Ui.dp(page ? 18 : 24);
            c.drawRect(b.left + m, y - Ui.dp(0.5f), b.right - m, y + Ui.dp(0.5f), p);
        }
        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(android.graphics.ColorFilter f) { }
        @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
    }

    private View picView(Context c, final Doc.Pic pic, View reuse) {
        final ImageView iv = reuse instanceof ImageView ? (ImageView) reuse : new ImageView(c);
        iv.setAdjustViewBounds(true);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setPadding(Ui.dp(18), Ui.dp(6), Ui.dp(18), Ui.dp(10));
        final String key = pic.zip + "|" + pic.path;
        iv.setTag(key);
        int w = Math.max(400, getWidth() > 0 ? getWidth() : Ui.dm.widthPixels);
        Bitmap b = Images.get(pic.zip, pic.path, w, () -> {
            if (key.equals(iv.getTag())) adapter.notifyDataSetChanged();
        });
        if (b != null) {
            iv.setImageBitmap(b);
            iv.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        } else {
            iv.setImageDrawable(null);
            iv.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(1)));
        }
        return iv;
    }
}
