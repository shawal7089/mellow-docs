package dev.mellow.docs;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** OpenDocument presentations (.odp, what LibreOffice Impress saves). Pure Java. */
final class Odp {
    private Odp() {}

    static Slides parse(File f) throws IOException {
        try (Pkg p = new Pkg(f)) {
            byte[] content = p.bytes("content.xml");
            if (content == null) throw new IOException("This is not an OpenDocument presentation");
            Odt.Ctx c = new Odt.Ctx();
            c.pkg = p;
            Slides out = new Slides();
            out.zip = f;
            byte[] st = p.bytes("styles.xml");
            if (st != null) {
                readSize(new Xml(st), out);
                Odt.readStyles(c, new Xml(st));
            }
            readSize(new Xml(content), out);
            Odt.readStyles(c, new Xml(content));
            Xml x = new Xml(content);
            while (x.next() != Xml.EOF) {
                if (x.is("page") && x.prefix.equals("draw")) {
                    if (out.slides.size() >= 400) { out.truncated = true; break; }
                    out.slides.add(page(c, x, out));
                }
            }
            return out;
        }
    }

    private static void readSize(Xml x, Slides out) {
        while (x.next() != Xml.EOF) {
            if (x.is("page-layout-properties")) {
                float w = Odt.length(x.attr("page-width"), 0.75f), h = Odt.length(x.attr("page-height"), 0.75f);
                if (w > 0 && h > 0) { out.w = (long) (w * 12700); out.h = (long) (h * 12700); return; }
            }
        }
    }

    private static Slides.Slide page(Odt.Ctx c, Xml x, Slides out) {
        Slides.Slide s = new Slides.Slide();
        Odt.SP ps = Odt.resolve(c, x.attr("style-name"));
        if (ps.fill != 0) s.bg = ps.fill;
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type != Xml.START) continue;
            switch (x.name) {
                case "frame": case "custom-shape": case "rect": case "ellipse": case "circle": case "line": case "connector":
                    shape(c, x, s, out);
                    break;
                case "notes": x.skip(); break;
                default: break;   // groups: their children carry absolute positions
            }
        }
        for (Slides.Shape sh : s.shapes) {
            if (sh.hasText()) { s.title = sh.paras.get(0).text().trim(); if (!s.title.isEmpty()) break; }
        }
        return s;
    }

    private static void shape(Odt.Ctx c, Xml x, Slides.Slide slide, Slides out) {
        String name = x.name;
        Slides.Shape s = new Slides.Shape();
        float px = Odt.length(x.attr("x"), 0.75f), py = Odt.length(x.attr("y"), 0.75f);
        float pw = Odt.length(x.attr("width"), 0.75f), ph = Odt.length(x.attr("height"), 0.75f);
        if (name.equals("line") || name.equals("connector")) {
            float x1 = Odt.length(x.attr("x1"), 0.75f), y1 = Odt.length(x.attr("y1"), 0.75f);
            float x2 = Odt.length(x.attr("x2"), 0.75f), y2 = Odt.length(x.attr("y2"), 0.75f);
            px = Math.min(x1, x2); py = Math.min(y1, y2); pw = Math.abs(x2 - x1); ph = Math.abs(y2 - y1);
            s.kind = Slides.Shape.LINE;
            s.flipV = (y2 < y1) != (x2 < x1);
        }
        if (pw < 0 || ph < 0 || px < 0 && py < 0) { x.skip(); return; }
        s.x = (long) (px * 12700); s.y = (long) (py * 12700); s.w = (long) (pw * 12700); s.h = (long) (ph * 12700);
        Odt.SP gs = Odt.resolve(c, x.attr("style-name"));
        Odt.SP presentation = Odt.resolve(c, x.attr("style-name", x.attr("presentation:style-name")));
        String pstyle = x.attr("presentation:style-name");
        Odt.SP ps = pstyle == null ? gs : gs.merged(Odt.resolve(c, pstyle));
        if (!ps.noFill && ps.fill != 0) s.fill = ps.fill;
        if (!ps.noStroke && ps.stroke != 0) { s.line = ps.stroke; s.lineW = 1f; }
        if (s.kind == Slides.Shape.LINE && s.line == 0) s.line = 0xFF000000;
        if (name.equals("ellipse") || name.equals("circle")) s.geom = 2;
        s.anchor = ps.anchor < 0 ? 0 : ps.anchor;
        List<Doc.Block> blocks = new ArrayList<>();
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type != Xml.START) continue;
            switch (x.name) {
                case "text-box": Odt.blocks(c, x, blocks, -1); break;
                case "p": case "h": case "list": {
                    // custom shapes / rects hold their text directly
                    List<Doc.Block> one = new ArrayList<>();
                    Odt.blocksFromHere(c, x, one);
                    blocks.addAll(one);
                    break;
                }
                case "image": {
                    String href = x.attr("href");
                    if (href != null && c.pkg.has(href)) { s.kind = Slides.Shape.PIC; s.image = href; }
                    break;
                }
                case "plugin": case "object": case "object-ole": s.kind = Slides.Shape.NOTE; s.label = "Embedded object"; break;
                default: break;
            }
        }
        float baseSize = ps.size > 0 ? ps.size : 18f;
        for (Doc.Block b : blocks) {
            if (!(b instanceof Doc.Para)) continue;
            Doc.Para p = (Doc.Para) b;
            for (Doc.Run r : p.runs) {
                if (r.size <= 0) r.size = baseSize;
                if (r.color == 0) r.color = ps.color != 0 ? ps.color : 0xFF000000;
                if (!r.b && ps.b != null && ps.b) r.b = true;
            }
            if (p.level >= 0) { p.hangPt = 16; p.indentPt = 16 * (p.level + 1); }
            if (p.heading > 0) p.heading = 0;
            s.paras.add(p);
        }
        if (s.kind == Slides.Shape.PIC && s.image == null) return;
        if (s.kind == Slides.Shape.BOX && s.fill == 0 && s.line == 0 && !s.hasText()) return;
        slide.shapes.add(s);
    }
}
