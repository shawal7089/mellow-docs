package dev.mellow.docs;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StrikethroughSpan;
import android.text.style.StyleSpan;
import android.text.style.SubscriptSpan;
import android.text.style.SuperscriptSpan;
import android.text.style.TypefaceSpan;
import android.text.style.UnderlineSpan;
import android.view.View;

import java.util.List;

/** Draws one slide of a presentation. Rendered once into a bitmap, then blitted. */
final class SlideView extends View {
    private Slides deck;
    private Slides.Slide slide;
    private boolean fit;                 // true: fit inside the parent (present mode)
    private Bitmap cache;
    private int cacheW;
    private final Paint fillP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strokeP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint imgP = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint blit = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final RectF rf = new RectF();
    private final Rect r1 = new Rect();

    SlideView(Context c, boolean fit) {
        super(c);
        this.fit = fit;
    }

    void setSlide(Slides d, Slides.Slide s) {
        deck = d;
        slide = s;
        drop();
        requestLayout();
        invalidate();
    }

    private void drop() { cache = null; }

    @Override protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        float ratio = deck == null ? 0.5625f : (float) deck.h / deck.w;
        if (fit) {
            int h = MeasureSpec.getSize(hSpec);
            int fw = w, fh = Math.round(w * ratio);
            if (fh > h) { fh = h; fw = Math.round(h / ratio); }
            setMeasuredDimension(Math.max(1, fw), Math.max(1, fh));
        } else {
            setMeasuredDimension(w, Math.max(1, Math.round(w * ratio)));
        }
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) { drop(); }

    @Override protected void onDraw(Canvas c) {
        if (deck == null || slide == null || getWidth() <= 0) return;
        if (cache == null || cacheW != getWidth()) {
            try {
                cache = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
                cacheW = getWidth();
                Canvas cc = new Canvas(cache);
                render(cc, getWidth() / (float) deck.w);
            } catch (OutOfMemoryError e) {
                cache = null;
                render(c, getWidth() / (float) deck.w);
                return;
            }
        }
        c.drawBitmap(cache, 0, 0, blit);
    }

    private void imagesReady() { drop(); invalidate(); }

    // ---- rendering ----------------------------------------------------------------------------------
    private void render(Canvas c, float k) {   // k = pixels per EMU
        fillP.setStyle(Paint.Style.FILL);
        fillP.setColor(slide.bg == 0 ? 0xFFFFFFFF : slide.bg);
        c.drawRect(0, 0, deck.w * k, deck.h * k, fillP);
        for (Slides.Shape s : slide.shapes) drawShape(c, s, k);
    }

    private void drawShape(Canvas c, Slides.Shape s, float k) {
        float x = s.x * k, y = s.y * k, w = s.w * k, h = s.h * k;
        c.save();
        if (s.rot != 0) c.rotate(s.rot, x + w / 2f, y + h / 2f);
        if (s.flipH || s.flipV) c.scale(s.flipH ? -1 : 1, s.flipV ? -1 : 1, x + w / 2f, y + h / 2f);
        rf.set(x, y, x + w, y + h);
        float lw = Math.max(1f, s.lineW * 12700f * k);
        switch (s.kind) {
            case Slides.Shape.LINE:
                strokeP.setStyle(Paint.Style.STROKE);
                strokeP.setStrokeWidth(lw);
                strokeP.setColor(s.line != 0 ? s.line : 0xFF444444);
                c.drawLine(x, y, x + w, y + h, strokeP);
                break;
            case Slides.Shape.PIC: {
                Bitmap b = Images.get(deck.zip, s.image, Math.max(300, Math.round(w)), this::imagesReady);
                if (b != null) {
                    if (s.crop != null && s.crop.length >= 4) {
                        r1.set(Math.round(b.getWidth() * s.crop[0]), Math.round(b.getHeight() * s.crop[1]),
                                Math.round(b.getWidth() * (1 - s.crop[2])), Math.round(b.getHeight() * (1 - s.crop[3])));
                        if (r1.width() < 2 || r1.height() < 2) r1.set(0, 0, b.getWidth(), b.getHeight());
                    } else r1.set(0, 0, b.getWidth(), b.getHeight());
                    c.drawBitmap(b, r1, rf, imgP);
                } else {
                    fillP.setColor(0x14000000);
                    c.drawRect(rf, fillP);
                }
                if (s.line != 0) { strokeP.setStyle(Paint.Style.STROKE); strokeP.setStrokeWidth(lw); strokeP.setColor(s.line); c.drawRect(rf, strokeP); }
                break;
            }
            case Slides.Shape.TABLE:
                drawTable(c, s, k);
                break;
            case Slides.Shape.NOTE: {
                strokeP.setStyle(Paint.Style.STROKE);
                strokeP.setStrokeWidth(Math.max(1f, 1.5f * Ui.density * 0.5f));
                strokeP.setColor(0x66808080);
                strokeP.setPathEffect(new DashPathEffect(new float[]{12, 8}, 0));
                c.drawRoundRect(rf, 12, 12, strokeP);
                strokeP.setPathEffect(null);
                TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
                tp.setColor(0xFF808080);
                tp.setTextSize(Math.max(14f, Math.min(h * 0.12f, 42f)));
                tp.setTextAlign(Paint.Align.CENTER);
                c.drawText(s.label.isEmpty() ? "Chart or diagram" : s.label, x + w / 2f, y + h / 2f, tp);
                break;
            }
            default: {
                if (s.fill != 0) {
                    fillP.setColor(s.fill);
                    shapePath(c, s, rf, fillP);
                }
                if (s.line != 0) {
                    strokeP.setStyle(Paint.Style.STROKE);
                    strokeP.setStrokeWidth(lw);
                    strokeP.setColor(s.line);
                    shapePath(c, s, rf, strokeP);
                }
                if (s.hasText()) {
                    float l = x + s.insL * k, t = y + s.insT * k, r = x + w - s.insR * k, b = y + h - s.insB * k;
                    drawParas(c, s.paras, l, t, Math.max(10, r - l), Math.max(10, b - t), s.anchor, k, s.fontScale, s.autofit);
                }
            }
        }
        c.restore();
    }

    private void shapePath(Canvas c, Slides.Shape s, RectF r, Paint p) {
        switch (s.geom) {
            case 1: { float rad = Math.min(r.width(), r.height()) * 0.1667f; c.drawRoundRect(r, rad, rad, p); break; }
            case 2: c.drawOval(r, p); break;
            case 3: {
                Path t = new Path();
                t.moveTo(r.centerX(), r.top); t.lineTo(r.right, r.bottom); t.lineTo(r.left, r.bottom); t.close();
                c.drawPath(t, p);
                break;
            }
            default: c.drawRect(r, p);
        }
    }

    private void drawTable(Canvas c, Slides.Shape s, float k) {
        int rows = s.cells.size();
        if (rows == 0) return;
        int cols = 0;
        for (List<Slides.TCell> r : s.cells) cols = Math.max(cols, r.size());
        if (cols == 0) return;
        float[] cx = new float[cols + 1], ry = new float[rows + 1];
        cx[0] = s.x * k; ry[0] = s.y * k;
        for (int i = 0; i < cols; i++) cx[i + 1] = cx[i] + (i < s.colW.length && s.colW[i] > 0 ? s.colW[i] : s.w / cols) * k;
        for (int i = 0; i < rows; i++) ry[i + 1] = ry[i] + (i < s.rowH.length && s.rowH[i] > 0 ? s.rowH[i] : s.h / rows) * k;
        strokeP.setStyle(Paint.Style.STROKE);
        strokeP.setStrokeWidth(Math.max(1f, 0.75f * Ui.density));
        strokeP.setColor(0x55808080);
        for (int r = 0; r < rows; r++) {
            List<Slides.TCell> row = s.cells.get(r);
            for (int cI = 0; cI < row.size() && cI < cols; cI++) {
                Slides.TCell cell = row.get(cI);
                if (cell.merged) continue;
                int span = Math.max(1, Math.min(cell.span, cols - cI));
                float l = cx[cI], t = ry[r], rr = cx[cI + span], b = ry[r + 1];
                if (cell.fill != 0) { fillP.setColor(cell.fill); c.drawRect(l, t, rr, b, fillP); }
                c.drawRect(l, t, rr, b, strokeP);
                if (!cell.paras.isEmpty()) {
                    float pad = 91440 * k;
                    drawParas(c, cell.paras, l + pad, t + 45720 * k, Math.max(10, rr - l - 2 * pad), Math.max(10, b - t - 91440 * k), 1, k, 1f, true);
                }
            }
        }
    }

    // ---- text ---------------------------------------------------------------------------------------
    private CharSequence build(Doc.Para p, float k, float fs, boolean withBullet) {
        SpannableStringBuilder sb = new SpannableStringBuilder();
        for (Doc.Run r : p.runs) {
            if (r.text.isEmpty()) continue;
            int s = sb.length();
            sb.append(r.text.replace('\u000b', '\n'));
            int e = sb.length();
            int f = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE;
            float pt = r.size > 0 ? r.size : 18f;
            sb.setSpan(new AbsoluteSizeSpan(Math.max(4, Math.round(pt * 12700f * k * fs)), false), s, e, f);
            if (r.b && r.i) sb.setSpan(new StyleSpan(Typeface.BOLD_ITALIC), s, e, f);
            else if (r.b) sb.setSpan(new StyleSpan(Typeface.BOLD), s, e, f);
            else if (r.i) sb.setSpan(new StyleSpan(Typeface.ITALIC), s, e, f);
            if (r.u) sb.setSpan(new UnderlineSpan(), s, e, f);
            if (r.s) sb.setSpan(new StrikethroughSpan(), s, e, f);
            if (r.mono) sb.setSpan(new TypefaceSpan("monospace"), s, e, f);
            if (r.sup) sb.setSpan(new SuperscriptSpan(), s, e, f);
            if (r.sub) sb.setSpan(new SubscriptSpan(), s, e, f);
            sb.setSpan(new ForegroundColorSpan(r.color != 0 ? r.color : 0xFF000000), s, e, f);
        }
        return sb;
    }

    private static final class Laid {
        StaticLayout layout;
        float x, before, after, bulletX;
        String bullet;
        int bulletColor;
        float bulletSize;
        boolean bold;
    }

    private float layoutAll(List<Doc.Para> paras, float width, float k, float fs, List<Laid> out) {
        float total = 0;
        for (Doc.Para p : paras) {
            Laid L = new Laid();
            float indent = p.indentPt * 12700f * k;
            float hang = p.hangPt * 12700f * k;
            float avail = Math.max(10, width - indent);
            CharSequence text = build(p, k, fs, true);
            Layout.Alignment al = p.align == 1 ? Layout.Alignment.ALIGN_CENTER : p.align == 2 ? Layout.Alignment.ALIGN_OPPOSITE : Layout.Alignment.ALIGN_NORMAL;
            TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            tp.setTextSize(Math.max(4, 18f * 12700f * k * fs));
            if (text.length() == 0) {
                // blank paragraph still takes one line of the paragraph's size
                float pt = p.runs.isEmpty() || p.runs.get(0).size <= 0 ? 18f : p.runs.get(0).size;
                L.layout = null;
                L.before = p.spaceBeforePt * 12700f * k;
                L.after = p.spaceAfterPt * 12700f * k + pt * 1.2f * 12700f * k * fs;
                total += L.before + L.after;
                L.x = indent;
                out.add(L);
                continue;
            }
            StaticLayout.Builder b = StaticLayout.Builder.obtain(text, 0, text.length(), tp, Math.round(avail)).setAlignment(al).setIncludePad(false);
            if (p.lineMult > 0) b.setLineSpacing(0, Math.max(0.7f, p.lineMult));
            L.layout = b.build();
            L.x = indent;
            L.before = p.spaceBeforePt * 12700f * k;
            L.after = p.spaceAfterPt * 12700f * k;
            if (p.level >= 0 && p.bullet != null && !p.bullet.isEmpty() && !p.runs.isEmpty()) {
                L.bullet = p.bullet;
                L.bulletX = indent - hang;
                Doc.Run r0 = p.runs.get(0);
                L.bulletColor = r0.color != 0 ? r0.color : 0xFF000000;
                L.bulletSize = Math.max(4, (r0.size > 0 ? r0.size : 18f) * 12700f * k * fs);
            }
            total += L.before + L.layout.getHeight() + L.after;
            out.add(L);
        }
        return total;
    }

    private void drawParas(Canvas c, List<Doc.Para> paras, float l, float t, float w, float h, int anchor, float k, float fontScale, boolean autofit) {
        float fs = fontScale <= 0 ? 1f : fontScale;
        List<Laid> laid = new java.util.ArrayList<>();
        float total = layoutAll(paras, w, k, fs, laid);
        int guard = 0;
        while (autofit && total > h * 1.02f && fs > 0.4f && guard++ < 6) {
            fs *= Math.max(0.75f, Math.min(0.95f, h / total));
            laid.clear();
            total = layoutAll(paras, w, k, fs, laid);
        }
        float y = t;
        if (anchor == 1) y = t + (h - total) / 2f;
        else if (anchor == 2) y = t + h - total;
        TextPaint bp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        for (Laid L : laid) {
            y += L.before;
            if (L.layout != null) {
                c.save();
                c.translate(l + L.x, y);
                L.layout.draw(c);
                c.restore();
                if (L.bullet != null) {
                    bp.setColor(L.bulletColor);
                    bp.setTextSize(L.bulletSize);
                    c.drawText(L.bullet, l + L.bulletX, y + L.layout.getLineBaseline(0), bp);
                }
                y += L.layout.getHeight();
            }
            y += L.after;
        }
    }
}
