package dev.mellow.docs;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.OverScroller;

/** Scrollable, pinch-zoomable grid for one spreadsheet sheet. Only visible cells are drawn. */
final class SheetView extends View {
    interface Listener { void onCell(String ref, String text); void onLongCell(String text); }

    private Sheets.Sheet sheet;
    private Listener listener;
    private float zoom = 1f;
    private float sx, sy;
    private float[] colX = new float[1];      // left edge of every column at zoom 1 (px)
    private float rowH, headH, headW;
    private int selRow = -1, selCol = -1;
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint();
    private final Paint line = new Paint();
    private final OverScroller scroller;
    private final GestureDetector gd;
    private final ScaleGestureDetector sd;

    SheetView(Context c) {
        super(c);
        scroller = new OverScroller(c);
        line.setStrokeWidth(Math.max(1f, Ui.density * 0.6f));
        gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { scroller.forceFinished(true); return true; }
            @Override public boolean onScroll(MotionEvent a, MotionEvent b, float dx, float dy) {
                sx += dx; sy += dy; clamp(); invalidate(); return true;
            }
            @Override public boolean onFling(MotionEvent a, MotionEvent b, float vx, float vy) {
                scroller.fling(Math.round(sx), Math.round(sy), Math.round(-vx), Math.round(-vy), 0, Math.round(maxX()), 0, Math.round(maxY()));
                postInvalidateOnAnimation();
                return true;
            }
            @Override public boolean onSingleTapUp(MotionEvent e) { pick(e.getX(), e.getY()); return true; }
            @Override public void onLongPress(MotionEvent e) {
                pick(e.getX(), e.getY());
                if (listener != null && sheet != null && selRow >= 0) listener.onLongCell(cell(selRow, selCol));
            }
            @Override public boolean onDoubleTap(MotionEvent e) { setZoom(zoom > 1.2f ? 1f : 1.8f, e.getX(), e.getY()); return true; }
        });
        sd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) { setZoom(zoom * d.getScaleFactor(), d.getFocusX(), d.getFocusY()); return true; }
        });
    }

    void setListener(Listener l) { listener = l; }

    void setSheet(Sheets.Sheet s) {
        sheet = s;
        sx = sy = 0;
        selRow = selCol = -1;
        zoom = 1f;
        rebuild();
        invalidate();
    }

    private void rebuild() {
        if (sheet == null) return;
        float ch = Ui.dp(7.3f);
        colX = new float[sheet.cols + 1];
        for (int i = 0; i < sheet.cols; i++) colX[i + 1] = colX[i] + sheet.colChars[i] * ch;
        rowH = Ui.dp(32);
        headH = Ui.dp(28);
        headW = Ui.dp(sheet.rows.size() > 9999 ? 56 : sheet.rows.size() > 999 ? 48 : 38);
    }

    private float maxX() { return sheet == null ? 0 : Math.max(0, colX[sheet.cols] * zoom - (getWidth() - headW)); }
    private float maxY() { return sheet == null ? 0 : Math.max(0, sheet.rows.size() * rowH * zoom - (getHeight() - headH)); }

    private void clamp() {
        sx = Math.max(0, Math.min(maxX(), sx));
        sy = Math.max(0, Math.min(maxY(), sy));
    }

    private void setZoom(float z, float fx, float fy) {
        z = Math.max(0.55f, Math.min(2.6f, z));
        float ux = (sx + fx - headW) / zoom, uy = (sy + fy - headH) / zoom;
        zoom = z;
        sx = ux * zoom - (fx - headW);
        sy = uy * zoom - (fy - headH);
        clamp();
        invalidate();
    }

    private String cell(int r, int c) {
        if (r < 0 || r >= sheet.rows.size()) return "";
        String[] row = sheet.rows.get(r);
        return c >= 0 && c < row.length && row[c] != null ? row[c] : "";
    }

    private void pick(float x, float y) {
        if (sheet == null || x < headW || y < headH) return;
        float ux = (sx + x - headW) / zoom, uy = (sy + y - headH) / zoom;
        int r = (int) (uy / rowH);
        int c = colAt(ux);
        if (r < 0 || r >= sheet.rows.size() || c < 0) return;
        selRow = r; selCol = c;
        invalidate();
        if (listener != null) listener.onCell(Sheets.colName(c) + (r + 1), cell(r, c));
    }

    private int colAt(float ux) {
        int lo = 0, hi = sheet.cols - 1;
        if (hi < 0 || ux < 0 || ux >= colX[sheet.cols]) return -1;
        while (lo < hi) { int m = (lo + hi + 1) >>> 1; if (colX[m] <= ux) lo = m; else hi = m - 1; }
        return lo;
    }

    @Override public void computeScroll() {
        if (scroller.computeScrollOffset()) {
            sx = scroller.getCurrX(); sy = scroller.getCurrY(); clamp();
            postInvalidateOnAnimation();
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        sd.onTouchEvent(e);
        if (!sd.isInProgress()) gd.onTouchEvent(e);
        return true;
    }

    private static boolean numeric(String s) {
        int n = s.length();
        if (n == 0 || n > 24) return false;
        char a = s.charAt(0), b = s.charAt(n - 1);
        boolean start = Character.isDigit(a) || a == '-' || a == '$' || a == '(' || a == '+' || a == '€' || a == '£' || a == '.';
        boolean end = Character.isDigit(b) || b == '%' || b == ')';
        if (!start || !end) return false;
        for (int i = 0; i < n; i++) { char ch = s.charAt(i); if (Character.isLetter(ch)) return false; }
        return true;
    }

    @Override protected void onDraw(Canvas c) {
        boolean dark = Paper.night;
        int bg = Paper.bg, fg = Paper.fg;
        int headBg = dark ? 0xFF22242c : 0xFFeeebe5, band = dark ? 0x0DFFFFFF : 0x08000000;
        int grid = Paper.cellLine & 0x00FFFFFF | 0x30000000;
        c.drawColor(bg);
        if (sheet == null || sheet.rows.isEmpty()) return;
        float rh = rowH * zoom;
        float ts = Ui.sp(13f) * Math.max(0.75f, zoom);
        text.setTextSize(ts);
        text.setTypeface(Typeface.DEFAULT);
        int r0 = Math.max(0, (int) (sy / rh)), r1 = Math.min(sheet.rows.size() - 1, (int) ((sy + getHeight()) / rh));
        float ux0 = sx / zoom, ux1 = (sx + getWidth()) / zoom;
        int c0 = Math.max(0, colAt(Math.min(ux0, colX[sheet.cols] - 1)));
        int c1 = sheet.cols - 1;
        float baseY = (rh - (text.descent() + text.ascent())) / 2f;
        line.setColor(grid);
        for (int r = r0; r <= r1; r++) {
            float y = headH + r * rh - sy;
            if (r % 2 == 1) { fill.setColor(band); c.drawRect(headW, y, getWidth(), y + rh, fill); }
            c.drawLine(headW, y + rh, getWidth(), y + rh, line);
            String[] row = sheet.rows.get(r);
            for (int cI = c0; cI <= c1; cI++) {
                float x = headW + colX[cI] * zoom - sx;
                if (x > getWidth()) break;
                float w = (colX[cI + 1] - colX[cI]) * zoom;
                if (cI == selCol && r == selRow) {
                    fill.setColor(Palette.alpha(Ui.t.a1, dark ? 70 : 60));
                    c.drawRect(x, y, x + w, y + rh, fill);
                }
                if (cI < row.length && row[cI] != null && !row[cI].isEmpty()) {
                    String t = row[cI];
                    int nl = t.indexOf('\n');
                    if (nl >= 0) t = t.substring(0, nl);
                    boolean num = numeric(t);
                    c.save();
                    c.clipRect(x + 2, y, x + w - 2, y + rh);
                    text.setColor(fg);
                    float pad = Ui.dp(6);
                    if (num) { text.setTextAlign(Paint.Align.RIGHT); c.drawText(t, x + w - pad, y + baseY, text); }
                    else { text.setTextAlign(Paint.Align.LEFT); c.drawText(t, x + pad, y + baseY, text); }
                    c.restore();
                }
            }
        }
        for (int cI = c0; cI <= c1; cI++) {
            float x = headW + colX[cI + 1] * zoom - sx;
            if (x - (colX[cI + 1] - colX[cI]) * zoom > getWidth()) break;
            c.drawLine(x, headH, x, getHeight(), line);
        }
        // headers
        fill.setColor(headBg);
        c.drawRect(0, 0, getWidth(), headH, fill);
        c.drawRect(0, 0, headW, getHeight(), fill);
        text.setTextSize(Ui.sp(11.5f));
        text.setColor(Paper.muted);
        text.setTextAlign(Paint.Align.CENTER);
        float hb = (headH - (text.descent() + text.ascent())) / 2f;
        for (int cI = c0; cI <= c1; cI++) {
            float x = headW + colX[cI] * zoom - sx, w = (colX[cI + 1] - colX[cI]) * zoom;
            if (x > getWidth()) break;
            if (cI == selCol) { fill.setColor(Palette.alpha(Ui.t.a1, 80)); c.drawRect(x, 0, x + w, headH, fill); }
            c.drawText(Sheets.colName(cI), x + w / 2f, hb, text);
        }
        for (int r = r0; r <= r1; r++) {
            float y = headH + r * rh - sy;
            if (r == selRow) { fill.setColor(Palette.alpha(Ui.t.a1, 80)); c.drawRect(0, y, headW, y + rh, fill); }
            c.drawText(String.valueOf(r + 1), headW / 2f, y + (rh - (text.descent() + text.ascent())) / 2f, text);
        }
        fill.setColor(headBg);
        c.drawRect(0, 0, headW, headH, fill);
        c.drawLine(0, headH, getWidth(), headH, line);
        c.drawLine(headW, 0, headW, getHeight(), line);
    }
}
