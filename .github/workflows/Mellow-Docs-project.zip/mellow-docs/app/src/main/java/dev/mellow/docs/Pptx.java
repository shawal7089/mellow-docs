package dev.mellow.docs;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** PowerPoint (.pptx) reader: slide size, backgrounds, text, pictures, tables, template (layout/master) shapes. Pure Java. */
final class Pptx {
    private Pptx() {}

    // ---- small value types ------------------------------------------------------------------------
    private static final class Lvl {
        float size;
        int color;
        int b = -1, i = -1, algn = -1;
        long marL = -1, indent = Long.MIN_VALUE;
        int buKind = -1;          // -1 unset, 0 none, 1 char, 2 auto
        String bu = "";
        int startAt = 1;
        float spcBef = -1, spcAft = -1, lnMult;

        static Lvl merge(Lvl a, Lvl o) {
            if (a == null) return o;
            if (o == null) return a;
            Lvl r = new Lvl();
            r.size = o.size > 0 ? o.size : a.size;
            r.color = o.color != 0 ? o.color : a.color;
            r.b = o.b >= 0 ? o.b : a.b;
            r.i = o.i >= 0 ? o.i : a.i;
            r.algn = o.algn >= 0 ? o.algn : a.algn;
            r.marL = o.marL >= 0 ? o.marL : a.marL;
            r.indent = o.indent != Long.MIN_VALUE ? o.indent : a.indent;
            if (o.buKind >= 0) { r.buKind = o.buKind; r.bu = o.bu; r.startAt = o.startAt; } else { r.buKind = a.buKind; r.bu = a.bu; r.startAt = a.startAt; }
            r.spcBef = o.spcBef >= 0 ? o.spcBef : a.spcBef;
            r.spcAft = o.spcAft >= 0 ? o.spcAft : a.spcAft;
            r.lnMult = o.lnMult > 0 ? o.lnMult : a.lnMult;
            return r;
        }
    }

    private static final class Ph {
        boolean hasXfrm;
        long x, y, w, h;
        int anchor = -1;
        Lvl[] lst = new Lvl[9];
    }

    private static final class Part {
        String path;
        Map<String, Pkg.Rel> rels = new HashMap<>();
        Map<String, Integer> theme = new HashMap<>();
        Map<String, String> clrMap = new HashMap<>();
        Map<String, Ph> phs = new HashMap<>();
        List<Slides.Shape> decor = new ArrayList<>();
        int bg;
        boolean showMaster = true;
        Lvl[] title = new Lvl[9], body = new Lvl[9], other = new Lvl[9];
        Part master;
    }

    private static final class Xf {
        long x, y, w, h, cx, cy, cw, ch;
        float rot;
        boolean flipH, flipV;
        boolean ok;
    }

    private static final class Ctx {
        Pkg pkg;
        Slides out;
        Part part;      // the part being parsed (rels for pictures)
        Part layout;    // null while parsing layout/master
        Part master;    // colours / text styles
        boolean isSlide;
        Map<String, Part> cache = new HashMap<>();
    }

    // ---- entry ---------------------------------------------------------------------------------------
    static Slides parse(File f) throws IOException {
        try (Pkg p = new Pkg(f)) {
            Xml x = p.xml("ppt/presentation.xml");
            if (x == null) throw new IOException("This is not a PowerPoint (.pptx) file");
            Slides out = new Slides();
            out.zip = f;
            List<String> ids = new ArrayList<>();
            while (x.next() != Xml.EOF) {
                if (x.is("sldSz")) { out.w = x.attrLong("cx", out.w); out.h = x.attrLong("cy", out.h); }
                else if (x.is("sldId")) ids.add(x.attr("r:id", x.attr("id", "")));
            }
            Map<String, Pkg.Rel> rels = p.rels("ppt/presentation.xml");
            Ctx c = new Ctx();
            c.pkg = p;
            c.out = out;
            for (String id : ids) {
                Pkg.Rel r = rels.get(id);
                if (r == null || r.target == null) continue;
                if (out.slides.size() >= 400) { out.truncated = true; break; }
                try {
                    out.slides.add(slide(c, r.target));
                } catch (RuntimeException e) {
                    Slides.Slide s = new Slides.Slide();
                    out.slides.add(s);
                }
            }
            return out;
        }
    }

    private static Slides.Slide slide(Ctx c, String path) {
        Slides.Slide s = new Slides.Slide();
        Part sp = new Part();
        sp.path = path;
        sp.rels = c.pkg.rels(path);
        Part layout = null;
        for (Pkg.Rel r : sp.rels.values()) {
            if (r.type.endsWith("/slideLayout") && r.target != null) { layout = part(c, r.target, false); break; }
        }
        Part master = layout != null ? layout.master : null;
        if (master == null) master = new Part();
        c.part = sp;
        c.layout = layout;
        c.master = master;
        c.isSlide = true;
        // template shapes first (under the slide's own)
        boolean showMaster = layout == null || layout.showMaster;
        if (showMaster && master.decor != null) {
            if (layout == null || layout.showMaster) for (Slides.Shape sh : master.decor) s.shapes.add(sh);
        }
        if (layout != null) s.shapes.addAll(layout.decor);
        s.bg = layout != null && layout.bg != 0 ? layout.bg : master.bg != 0 ? master.bg : 0xFFFFFFFF;
        Xml x = c.pkg.xml(path);
        if (x == null) return s;
        double[] g = {1, 1, 0, 0};
        while (x.next() != Xml.EOF) {
            if (x.is("bg")) {
                int col = background(x, c);
                if (col != 0) s.bg = col;
            } else if (x.is("spTree")) {
                tree(x, c, s.shapes, null, g);
            }
        }
        for (Slides.Shape sh : s.shapes) {
            if (s.title.isEmpty() && sh.hasText()) {
                s.title = sh.paras.get(0).text().trim();
                if (s.title.isEmpty()) for (Doc.Para pa : sh.paras) if (!pa.isBlank()) { s.title = pa.text().trim(); break; }
            }
        }
        return s;
    }

    /** Parses a slide layout or slide master (once). */
    private static Part part(Ctx c, String path, boolean isMaster) {
        Part cached = c.cache.get(path);
        if (cached != null) return cached;
        Part p = new Part();
        p.path = path;
        c.cache.put(path, p);
        p.rels = c.pkg.rels(path);
        Part saveP = c.part, saveL = c.layout, saveM = c.master;
        boolean saveS = c.isSlide;
        if (!isMaster) {
            for (Pkg.Rel r : p.rels.values()) {
                if (r.type.endsWith("/slideMaster") && r.target != null) { p.master = part(c, r.target, true); break; }
            }
            if (p.master == null) p.master = new Part();
        } else {
            for (Pkg.Rel r : p.rels.values()) {
                if (r.type.endsWith("/theme") && r.target != null) { readTheme(c.pkg, r.target, p.theme); break; }
            }
            p.master = p;
        }
        c.part = p;
        c.layout = null;
        c.master = p.master;
        c.isSlide = false;
        Xml x = c.pkg.xml(path);
        if (x != null) {
            double[] g = {1, 1, 0, 0};
            while (x.next() != Xml.EOF) {
                if (x.is("sldLayout")) p.showMaster = !"0".equals(x.attr("showMasterSp", "1"));
                else if (x.is("clrMap")) {
                    p.clrMap.put("bg1", x.attr("bg1", "lt1")); p.clrMap.put("tx1", x.attr("tx1", "dk1"));
                    p.clrMap.put("bg2", x.attr("bg2", "lt2")); p.clrMap.put("tx2", x.attr("tx2", "dk2"));
                } else if (x.is("bg")) {
                    int col = background(x, c);
                    if (col != 0) p.bg = col;
                } else if (x.is("spTree")) {
                    tree(x, c, p.decor, p.phs, g);
                } else if (x.is("titleStyle")) levels(x, c, p.title);
                else if (x.is("bodyStyle")) levels(x, c, p.body);
                else if (x.is("otherStyle")) levels(x, c, p.other);
            }
        }
        c.part = saveP; c.layout = saveL; c.master = saveM; c.isSlide = saveS;
        return p;
    }

    private static void readTheme(Pkg pkg, String path, Map<String, Integer> out) {
        Xml x = pkg.xml(path);
        if (x == null) return;
        while (x.next() != Xml.EOF) {
            if (x.is("clrScheme")) {
                int d = x.depth;
                while (x.next() != Xml.EOF) {
                    if (x.type == Xml.END && x.depth == d) break;
                    if (x.type == Xml.START && !x.name.equals("clrScheme")) {
                        String slot = x.name;
                        int dd = x.depth;
                        while (x.next() != Xml.EOF) {
                            if (x.type == Xml.END && x.depth == dd) break;
                            if (x.is("srgbClr")) { out.put(slot, 0xFF000000 | hex(x.attr("val", "000000"))); }
                            else if (x.is("sysClr")) { out.put(slot, 0xFF000000 | hex(x.attr("lastClr", "000000"))); }
                        }
                    }
                }
                return;
            }
        }
    }

    private static int hex(String v) {
        try { return Integer.parseInt(v.trim(), 16) & 0xFFFFFF; } catch (NumberFormatException e) { return 0; }
    }

    // ---- colours ----------------------------------------------------------------------------------
    private static int scheme(Ctx c, String name) {
        Part m = c.master;
        String slot = name;
        if (m != null && m.clrMap.containsKey(name)) slot = m.clrMap.get(name);
        else if (name.equals("tx1")) slot = "dk1";
        else if (name.equals("bg1")) slot = "lt1";
        else if (name.equals("tx2")) slot = "dk2";
        else if (name.equals("bg2")) slot = "lt2";
        Integer v = m == null ? null : m.theme.get(slot);
        if (v != null) return v;
        switch (slot) {
            case "lt1": return 0xFFFFFFFF;
            case "lt2": return 0xFFEEECE1;
            case "dk2": return 0xFF1F497D;
            case "accent1": return 0xFF4F81BD;
            case "accent2": return 0xFFC0504D;
            case "accent3": return 0xFF9BBB59;
            case "accent4": return 0xFF8064A2;
            case "accent5": return 0xFF4BACC6;
            case "accent6": return 0xFFF79646;
            default: return 0xFF000000;
        }
    }

    /** x is on a colour element (srgbClr, schemeClr, sysClr, prstClr); leaves it on that element's END. */
    private static int readColor(Xml x, Ctx c) {
        int base;
        String n = x.name;
        switch (n) {
            case "srgbClr": base = 0xFF000000 | hex(x.attr("val", "000000")); break;
            case "schemeClr": base = scheme(c, x.attr("val", "tx1")); break;
            case "sysClr": base = 0xFF000000 | hex(x.attr("lastClr", "000000")); break;
            case "prstClr": {
                String v = x.attr("val", "black");
                base = v.equals("white") ? 0xFFFFFFFF : v.equals("red") ? 0xFFFF0000 : v.equals("blue") ? 0xFF0000FF : v.equals("green") ? 0xFF008000 : v.equals("gray") ? 0xFF808080 : 0xFF000000;
                break;
            }
            default: base = 0xFF000000; break;
        }
        int alpha = 255;
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type != Xml.START) continue;
            double v = x.attrDouble("val", 100000) / 100000.0;
            switch (x.name) {
                case "lumMod": case "lumOff": {
                    float[] hsl = Palette.toHsl(base);
                    float l = hsl[2];
                    if (x.name.equals("lumMod")) l = (float) (l * v); else l = (float) (l + v);
                    base = Palette.hsl(hsl[0], hsl[1], Math.max(0f, Math.min(1f, l)));
                    break;
                }
                case "satMod": {
                    float[] hsl = Palette.toHsl(base);
                    base = Palette.hsl(hsl[0], (float) Math.max(0, Math.min(1, hsl[1] * v)), hsl[2]);
                    break;
                }
                case "tint": base = Palette.mix(0xFFFFFFFF, base, (float) v); break;
                case "shade": base = Palette.mix(0xFF000000, base, (float) v); break;
                case "alpha": alpha = (int) Math.round(255 * v); break;
                default: break;
            }
        }
        if (alpha < 12) return 0;
        return 0xFF000000 | (base & 0xFFFFFF);
    }

    /** x is on solidFill (or any element whose first colour child is wanted). */
    private static int solid(Xml x, Ctx c) {
        int d = x.depth;
        int col = 0;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type == Xml.START && col == 0 && (x.name.equals("srgbClr") || x.name.equals("schemeClr") || x.name.equals("sysClr") || x.name.equals("prstClr"))) {
                col = readColor(x, c);
            }
        }
        return col;
    }

    /** x is on p:bg. */
    private static int background(Xml x, Ctx c) {
        int d = x.depth;
        int col = 0;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.is("solidFill") && col == 0) col = solid(x, c);
            else if (x.is("bgRef") && col == 0) col = solid(x, c);
        }
        return col;
    }

    // ---- text styles ---------------------------------------------------------------------------------
    private static void levels(Xml x, Ctx c, Lvl[] out) {
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type == Xml.START && x.name.startsWith("lvl") && x.name.endsWith("pPr") && x.name.length() == 7) {
                int n = x.name.charAt(3) - '1';
                Lvl l = lvl(x, c);
                if (n >= 0 && n < 9) out[n] = l;
            }
        }
    }

    /** x is on a lvlNpPr / pPr element. */
    private static Lvl lvl(Xml x, Ctx c) {
        Lvl l = new Lvl();
        String al = x.attr("algn");
        if (al != null) l.algn = al.equals("ctr") ? 1 : al.equals("r") ? 2 : al.equals("just") ? 3 : 0;
        if (x.attr("marL") != null) l.marL = x.attrLong("marL", 0);
        if (x.attr("indent") != null) l.indent = x.attrLong("indent", 0);
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type != Xml.START) continue;
            switch (x.name) {
                case "defRPr": run(x, c, l); break;
                case "buNone": l.buKind = 0; break;
                case "buChar": l.buKind = 1; l.bu = x.attr("char", "•"); break;
                case "buAutoNum": l.buKind = 2; l.bu = x.attr("type", "arabicPeriod"); l.startAt = x.attrInt("startAt", 1); break;
                case "spcBef": l.spcBef = spacing(x, true); break;
                case "spcAft": l.spcAft = spacing(x, false); break;
                case "lnSpc": {
                    int dd = x.depth;
                    while (x.next() != Xml.EOF) {
                        if (x.type == Xml.END && x.depth == dd) break;
                        if (x.is("spcPct")) l.lnMult = (float) (x.attrDouble("val", 100000) / 100000.0);
                    }
                    break;
                }
                default: break;
            }
        }
        return l;
    }

    /** points; negative values (-percent/100) are stored as -fraction. */
    private static float spacing(Xml x, boolean before) {
        float out = -1;
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.is("spcPts")) out = (float) (x.attrDouble("val", 0) / 100.0);
            else if (x.is("spcPct")) out = (float) (-x.attrDouble("val", 0) / 100000.0) - 0.0001f;
        }
        return out;
    }

    /** x is on rPr / defRPr / endParaRPr: fills size, bold, italic, colour into l. */
    private static void run(Xml x, Ctx c, Lvl l) {
        int sz = x.attrInt("sz", 0);
        if (sz > 0) l.size = sz / 100f;
        if (x.attr("b") != null) l.b = x.attrOn("b") ? 1 : 0;
        if (x.attr("i") != null) l.i = x.attrOn("i") ? 1 : 0;
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.is("solidFill")) l.color = solid(x, c);
        }
    }

    // ---- shape tree ------------------------------------------------------------------------------------
    private static Xf xfrm(Xml x) {
        Xf f = new Xf();
        f.ok = true;
        f.rot = (float) (x.attrDouble("rot", 0) / 60000.0);
        f.flipH = "1".equals(x.attr("flipH")) || "true".equals(x.attr("flipH"));
        f.flipV = "1".equals(x.attr("flipV")) || "true".equals(x.attr("flipV"));
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.is("off")) { f.x = x.attrLong("x", 0); f.y = x.attrLong("y", 0); }
            else if (x.is("ext")) { f.w = x.attrLong("cx", 0); f.h = x.attrLong("cy", 0); }
            else if (x.is("chOff")) { f.cx = x.attrLong("x", 0); f.cy = x.attrLong("y", 0); }
            else if (x.is("chExt")) { f.cw = x.attrLong("cx", 0); f.ch = x.attrLong("cy", 0); }
        }
        return f;
    }

    private static void apply(Slides.Shape s, Xf f, double[] g) {
        s.x = Math.round(g[2] + f.x * g[0]);
        s.y = Math.round(g[3] + f.y * g[1]);
        s.w = Math.round(f.w * g[0]);
        s.h = Math.round(f.h * g[1]);
        s.rot = f.rot;
        s.flipH = f.flipH;
        s.flipV = f.flipV;
    }

    /** x is on spTree or grpSp (children are shapes). */
    private static void tree(Xml x, Ctx c, List<Slides.Shape> out, Map<String, Ph> phOut, double[] g) {
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type != Xml.START) continue;
            switch (x.name) {
                case "sp": case "pic": case "cxnSp": case "graphicFrame": case "grpSp":
                    shape(x, c, out, phOut, g);
                    break;
                case "nvGrpSpPr": case "grpSpPr": case "Fallback": x.skip(); break;
                default: break;
            }
        }
    }

    private static Ph find(Part p, String type, int idx) {
        if (p == null) return null;
        Ph r = idx >= 0 ? p.phs.get(type + "|" + idx) : null;
        if (r == null) r = p.phs.get(type + "|-1");
        if (r == null && idx >= 0) r = p.phs.get("|" + idx);
        return r;
    }

    private static String phClass(String type) {
        switch (type) {
            case "title": case "ctrTitle": return "title";
            case "": case "body": case "subTitle": case "obj": return "body";
            default: return type;
        }
    }

    private static void shape(Xml x, Ctx c, List<Slides.Shape> out, Map<String, Ph> phOut, double[] g) {
        String kind = x.name;
        if (kind.equals("grpSp")) {
            int d = x.depth;
            double[] g2 = g;
            while (x.next() != Xml.EOF) {
                if (x.type == Xml.END && x.depth == d) break;
                if (x.type != Xml.START) continue;
                if (x.name.equals("grpSpPr")) {
                    int dd = x.depth;
                    while (x.next() != Xml.EOF) {
                        if (x.type == Xml.END && x.depth == dd) break;
                        if (x.is("xfrm")) {
                            Xf f = xfrm(x);
                            double sx = f.cw > 0 ? (double) f.w / f.cw : 1, sy = f.ch > 0 ? (double) f.h / f.ch : 1;
                            double ax = g[2] + f.x * g[0], ay = g[3] + f.y * g[1];
                            g2 = new double[]{sx * g[0], sy * g[1], ax - f.cx * sx * g[0], ay - f.cy * sy * g[1]};
                        }
                    }
                } else if (x.name.equals("sp") || x.name.equals("pic") || x.name.equals("cxnSp") || x.name.equals("graphicFrame") || x.name.equals("grpSp")) {
                    shape(x, c, out, phOut, g2);
                } else if (x.name.equals("nvGrpSpPr")) {
                    x.skip();
                }
            }
            return;
        }
        Slides.Shape s = new Slides.Shape();
        s.kind = kind.equals("pic") ? Slides.Shape.PIC : kind.equals("cxnSp") ? Slides.Shape.LINE : Slides.Shape.BOX;
        String phType = null;
        int phIdx = -1;
        Xf xf = null;
        Ph own = new Ph();
        int styleFill = 0, styleLine = 0, styleText = 0;
        boolean hasFill = false, hasLine = false;
        Lvl[] ownLst = new Lvl[9];
        List<Doc.Para> paras = new ArrayList<>();
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type != Xml.START) continue;
            switch (x.name) {
                case "ph":
                    phType = x.attr("type", "");
                    phIdx = x.attrInt("idx", -1);
                    break;
                case "spPr": {
                    int dd = x.depth;
                    while (x.next() != Xml.EOF) {
                        if (x.type == Xml.END && x.depth == dd) break;
                        if (x.type != Xml.START) continue;
                        switch (x.name) {
                            case "xfrm": xf = xfrm(x); break;
                            case "prstGeom": {
                                String p = x.attr("prst", "rect");
                                s.geom = p.equals("roundRect") || p.equals("round2SameRect") ? 1 : p.equals("ellipse") ? 2 : p.equals("triangle") ? 3 : 0;
                                break;
                            }
                            case "solidFill": s.fill = solid(x, c); hasFill = true; break;
                            case "noFill": hasFill = true; s.fill = 0; break;
                            case "gradFill": {
                                int g0 = x.depth;
                                int col = 0;
                                while (x.next() != Xml.EOF) {
                                    if (x.type == Xml.END && x.depth == g0) break;
                                    if (x.is("gs") && col == 0) col = solid(x, c);
                                }
                                s.fill = col;
                                hasFill = true;
                                break;
                            }
                            case "ln": {
                                s.lineW = (float) (x.attrDouble("w", 12700) / 12700.0);
                                int l0 = x.depth;
                                hasLine = true;
                                s.line = 0;
                                boolean explicit = false;
                                while (x.next() != Xml.EOF) {
                                    if (x.type == Xml.END && x.depth == l0) break;
                                    if (x.is("solidFill")) { s.line = solid(x, c); explicit = true; }
                                    else if (x.is("noFill")) { s.line = 0; explicit = true; }
                                }
                                hasLine = explicit || true;
                                break;
                            }
                            default: break;
                        }
                    }
                    break;
                }
                case "blipFill": {
                    int dd = x.depth;
                    while (x.next() != Xml.EOF) {
                        if (x.type == Xml.END && x.depth == dd) break;
                        if (x.is("blip")) {
                            String id = x.attr("r:embed");
                            Pkg.Rel r = id == null ? null : c.part.rels.get(id);
                            if (r != null && r.target != null && !r.external) s.image = r.target;
                        } else if (x.is("srcRect")) {
                            s.crop = new float[]{x.attrInt("l", 0) / 100000f, x.attrInt("t", 0) / 100000f, x.attrInt("r", 0) / 100000f, x.attrInt("b", 0) / 100000f};
                        }
                    }
                    break;
                }
                case "style": {
                    int dd = x.depth;
                    while (x.next() != Xml.EOF) {
                        if (x.type == Xml.END && x.depth == dd) break;
                        if (x.is("fillRef")) { int idx = x.attrInt("idx", 0); int col = solid(x, c); if (idx > 0) styleFill = col; }
                        else if (x.is("lnRef")) { int idx = x.attrInt("idx", 0); int col = solid(x, c); if (idx > 0) styleLine = col; }
                        else if (x.is("fontRef")) styleText = solid(x, c);
                    }
                    break;
                }
                case "txBody": {
                    String cls = phType == null ? "other" : phClass(phType);
                    Lvl[] base = cls.equals("title") ? c.master.title : cls.equals("body") ? c.master.body : c.master.other;
                    Ph lp = phType == null ? null : find(c.layout, phType, phIdx);
                    if (lp == null && phType != null && c.layout != null) lp = find(c.layout, phType, -1);
                    Ph mp = phType == null || c.master == null ? null : find(c.master, cls.equals("title") ? "title" : cls.equals("body") ? "body" : phType, -1);
                    int defColor = styleText != 0 ? styleText : scheme(c, "tx1");
                    textBody(x, c, s, base, mp == null ? null : mp.lst, lp == null ? null : lp.lst, ownLst, own, paras, defColor, styleText);
                    break;
                }
                case "graphic": case "graphicData": break;     // look inside
                case "xfrm": xf = xfrm(x); break;                // graphicFrame's p:xfrm
                case "tbl": table(x, c, s); s.kind = Slides.Shape.TABLE; break;
                case "chart": s.kind = Slides.Shape.NOTE; s.label = "Chart"; break;
                case "relIds": s.kind = Slides.Shape.NOTE; s.label = "Diagram"; break;
                case "nvSpPr": case "nvPicPr": case "nvCxnSpPr": case "nvGraphicFramePr": break;     // look for ph inside
                default: break;
            }
        }
        // inherit position from the template placeholder
        Ph lp = phType == null ? null : find(c.layout, phType, phIdx);
        Ph mp = phType == null ? null : find(c.master, phClass(phType).equals("body") ? "body" : phClass(phType), -1);
        if (phType != null && !c.isSlide) {
            // storing a template placeholder
            Ph ph = own;
            if (xf != null) { ph.hasXfrm = true; ph.x = xf.x; ph.y = xf.y; ph.w = xf.w; ph.h = xf.h; }
            ph.lst = ownLst;
            if (phOut != null) {
                phOut.put(phType + "|" + phIdx, ph);
                if (!phOut.containsKey(phType + "|-1")) phOut.put(phType + "|-1", ph);
                if (phIdx >= 0 && !phOut.containsKey("|" + phIdx)) phOut.put("|" + phIdx, ph);
            }
            return;
        }
        if (xf == null && phType != null) {
            Ph src = lp != null && lp.hasXfrm ? lp : mp != null && mp.hasXfrm ? mp : null;
            if (src != null) { xf = new Xf(); xf.ok = true; xf.x = src.x; xf.y = src.y; xf.w = src.w; xf.h = src.h; }
        }
        if (xf == null) return;
        if (own.anchor < 0) own.anchor = lp != null && lp.anchor >= 0 ? lp.anchor : mp != null && mp.anchor >= 0 ? mp.anchor : 0;
        s.anchor = own.anchor < 0 ? 0 : own.anchor;
        apply(s, xf, g);
        if (!hasFill && styleFill != 0 && s.kind == Slides.Shape.BOX) s.fill = styleFill;
        if (!hasLine && styleLine != 0) { s.line = styleLine; s.lineW = 1f; }
        else if (hasLine && s.line == 0) { /* explicit no line */ }
        if (s.kind == Slides.Shape.LINE && s.line == 0) s.line = styleLine != 0 ? styleLine : 0xFF000000;
        s.paras.addAll(paras);
        if (s.kind == Slides.Shape.BOX && s.fill == 0 && s.line == 0 && !s.hasText()) return;
        if (s.kind == Slides.Shape.PIC && s.image == null) return;
        out.add(s);
    }

    // ---- text bodies ----------------------------------------------------------------------------------
    private static void textBody(Xml x, Ctx c, Slides.Shape s, Lvl[] master, Lvl[] mph, Lvl[] lph, Lvl[] ownLst, Ph own, List<Doc.Para> out, int defColor, int fontRef) {
        int d = x.depth;
        int[] counters = new int[9];
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type != Xml.START) continue;
            switch (x.name) {
                case "bodyPr": {
                    String a = x.attr("anchor");
                    if (a != null) own.anchor = a.equals("ctr") ? 1 : a.equals("b") ? 2 : 0;
                    if (x.attr("lIns") != null) s.insL = x.attrLong("lIns", 91440);
                    if (x.attr("tIns") != null) s.insT = x.attrLong("tIns", 45720);
                    if (x.attr("rIns") != null) s.insR = x.attrLong("rIns", 91440);
                    if (x.attr("bIns") != null) s.insB = x.attrLong("bIns", 45720);
                    if ("none".equals(x.attr("wrap"))) s.wrap = false;
                    int dd = x.depth;
                    while (x.next() != Xml.EOF) {
                        if (x.type == Xml.END && x.depth == dd) break;
                        if (x.is("normAutofit")) { s.autofit = true; s.fontScale = (float) (x.attrDouble("fontScale", 100000) / 100000.0); }
                        else if (x.is("spAutoFit")) { /* box grows with text: nothing to do */ }
                    }
                    break;
                }
                case "lstStyle": levels(x, c, ownLst); break;
                case "p": paragraph(x, c, master, mph, lph, ownLst, counters, out, defColor, fontRef); break;
                default: break;
            }
        }
    }

    private static void paragraph(Xml x, Ctx c, Lvl[] master, Lvl[] mph, Lvl[] lph, Lvl[] own, int[] counters, List<Doc.Para> out, int defColor, int fontRef) {
        Doc.Para p = new Doc.Para();
        int d = x.depth;
        int lvlIdx = 0;
        Lvl pp = null;
        List<Doc.Run> runs = new ArrayList<>();
        List<Lvl> runStyle = new ArrayList<>();
        Lvl end = null;
        // paragraph properties come first
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type != Xml.START) continue;
            switch (x.name) {
                case "pPr": {
                    lvlIdx = Math.max(0, Math.min(8, x.attrInt("lvl", 0)));
                    pp = lvl(x, c);
                    break;
                }
                case "r": case "fld": {
                    Lvl rs = new Lvl();
                    String text = "";
                    String face = "";
                    int dd = x.depth;
                    while (x.next() != Xml.EOF) {
                        if (x.type == Xml.END && x.depth == dd) break;
                        if (x.type != Xml.START) continue;
                        if (x.name.equals("rPr")) {
                            String bl = x.attr("baseline");
                            if (bl != null) { rs.spcBef = (float) x.attrDouble("baseline", 0); }
                            boolean u = x.attr("u") != null && !"none".equals(x.attr("u"));
                            boolean st = x.attr("strike") != null && !"noStrike".equals(x.attr("strike"));
                            if (u) rs.startAt = 1; else rs.startAt = 0;
                            rs.lnMult = st ? 1 : 0;
                            int dr = x.depth;
                            int sz = x.attrInt("sz", 0);
                            if (sz > 0) rs.size = sz / 100f;
                            if (x.attr("b") != null) rs.b = x.attrOn("b") ? 1 : 0;
                            if (x.attr("i") != null) rs.i = x.attrOn("i") ? 1 : 0;
                            while (x.next() != Xml.EOF) {
                                if (x.type == Xml.END && x.depth == dr) break;
                                if (x.is("solidFill")) rs.color = solid(x, c);
                                else if (x.is("latin")) face = x.attr("typeface", "");
                            }
                        } else if (x.name.equals("t")) {
                            text += x.textOf();
                        }
                    }
                    if (!text.isEmpty()) {
                        Doc.Run r = new Doc.Run(text);
                        String f = face.toLowerCase(Locale.ROOT);
                        r.mono = f.contains("courier") || f.contains("consolas") || f.contains("mono");
                        r.u = rs.startAt == 1;
                        r.s = rs.lnMult == 1;
                        if (rs.spcBef > 0) r.sup = true; else if (rs.spcBef < 0) r.sub = true;
                        runs.add(r);
                        runStyle.add(rs);
                    }
                    break;
                }
                case "br": {
                    Doc.Run r = new Doc.Run("\n");
                    runs.add(r);
                    runStyle.add(new Lvl());
                    break;
                }
                case "endParaRPr": { end = new Lvl(); run(x, c, end); break; }
                default: break;
            }
        }
        // effective paragraph style
        Lvl eff = null;
        int li = lvlIdx;
        eff = Lvl.merge(eff, master == null ? null : master[li]);
        eff = Lvl.merge(eff, mph == null ? null : mph[li]);
        eff = Lvl.merge(eff, lph == null ? null : lph[li]);
        if (fontRef != 0) {
            eff = Lvl.merge(new Lvl(), eff);
            eff.color = fontRef;
        }
        eff = Lvl.merge(eff, own == null ? null : own[li]);
        eff = Lvl.merge(eff, pp);
        if (eff == null) eff = new Lvl();
        float baseSize = eff.size > 0 ? eff.size : 18f;
        for (int k = 0; k < runs.size(); k++) {
            Doc.Run r = runs.get(k);
            Lvl rs = runStyle.get(k);
            r.size = rs.size > 0 ? rs.size : baseSize;
            r.color = rs.color != 0 ? rs.color : eff.color != 0 ? eff.color : defColor;
            r.b = rs.b >= 0 ? rs.b == 1 : eff.b == 1;
            r.i = rs.i >= 0 ? rs.i == 1 : eff.i == 1;
            p.runs.add(r);
        }
        if (p.runs.isEmpty()) {
            Doc.Run r = new Doc.Run("");
            r.size = end != null && end.size > 0 ? end.size : baseSize;
            p.runs.add(r);
        }
        p.align = eff.algn < 0 ? 0 : eff.algn;
        long marL = eff.marL >= 0 ? eff.marL : 0;
        long indent = eff.indent != Long.MIN_VALUE ? eff.indent : 0;
        p.indentPt = marL / 12700f;
        p.heading = 0;
        p.level = lvlIdx;
        // bullets
        for (int k = lvlIdx + 1; k < 9; k++) counters[k] = 0;
        String label = "";
        if (eff.buKind == 1 && !eff.bu.isEmpty()) {
            label = bulletChar(eff.bu);
        } else if (eff.buKind == 2) {
            counters[lvlIdx] = counters[lvlIdx] == 0 ? eff.startAt : counters[lvlIdx] + 1;
            label = autoNum(counters[lvlIdx], eff.bu);
        } else {
            counters[lvlIdx] = 0;
        }
        p.bullet = label;
        p.hangPt = label.isEmpty() ? 0 : (indent < 0 ? -indent / 12700f : 0);
        if (!label.isEmpty() && indent >= 0) p.hangPt = 0;
        p.spaceBeforePt = eff.spcBef >= 0 ? eff.spcBef : eff.spcBef < -0.00001f ? (-(eff.spcBef + 0.0001f)) * baseSize : 0;
        p.spaceAfterPt = eff.spcAft >= 0 ? eff.spcAft : eff.spcAft < -0.00001f ? (-(eff.spcAft + 0.0001f)) * baseSize : 0;
        p.lineMult = eff.lnMult;
        out.add(p);
    }

    private static String bulletChar(String b) {
        if (b.length() == 0) return "•";
        char ch = b.charAt(0);
        // Wingdings / Symbol private-use bullets become a plain dot
        if (ch >= 0xF000 || ch == '§' || ch == 'Ø' || ch == 'v') return "•";
        return b;
    }

    private static String autoNum(int n, String type) {
        String num;
        if (type.startsWith("alphaLc")) num = Docx.letters(n, false);
        else if (type.startsWith("alphaUc")) num = Docx.letters(n, true);
        else if (type.startsWith("romanLc")) num = Docx.roman(n).toLowerCase(Locale.ROOT);
        else if (type.startsWith("romanUc")) num = Docx.roman(n);
        else num = String.valueOf(n);
        return type.endsWith("ParenR") ? num + ")" : type.endsWith("ParenBoth") ? "(" + num + ")" : num + ".";
    }

    // ---- tables ---------------------------------------------------------------------------------------
    private static void table(Xml x, Ctx c, Slides.Shape s) {
        List<Long> cols = new ArrayList<>();
        List<Long> rows = new ArrayList<>();
        int d = x.depth;
        int defColor = scheme(c, "tx1");
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.is("gridCol")) cols.add(x.attrLong("w", 914400));
            else if (x.is("tr")) {
                rows.add(x.attrLong("h", 370840));
                List<Slides.TCell> row = new ArrayList<>();
                int dr = x.depth;
                while (x.next() != Xml.EOF) {
                    if (x.type == Xml.END && x.depth == dr) break;
                    if (x.is("tc")) {
                        Slides.TCell tc = new Slides.TCell();
                        tc.span = Math.max(1, x.attrInt("gridSpan", 1));
                        tc.merged = "1".equals(x.attr("hMerge")) || "true".equals(x.attr("hMerge"));
                        int dc = x.depth;
                        int[] counters = new int[9];
                        while (x.next() != Xml.EOF) {
                            if (x.type == Xml.END && x.depth == dc) break;
                            if (x.is("p")) paragraph(x, c, c.master == null ? null : c.master.other, null, null, null, counters, tc.paras, defColor, 0);
                            else if (x.is("tcPr")) {
                                int dp = x.depth;
                                while (x.next() != Xml.EOF) {
                                    if (x.type == Xml.END && x.depth == dp) break;
                                    if (x.is("solidFill")) tc.fill = solid(x, c);
                                }
                            }
                        }
                        row.add(tc);
                    }
                }
                s.cells.add(row);
            }
        }
        s.colW = new long[cols.size()];
        for (int i = 0; i < cols.size(); i++) s.colW[i] = cols.get(i);
        s.rowH = new long[rows.size()];
        for (int i = 0; i < rows.size(); i++) s.rowH[i] = rows.get(i);
    }
}
