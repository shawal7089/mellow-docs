package dev.mellow.docs;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.util.LruCache;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.OverScroller;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Continuous-scroll PDF page viewer with pinch zoom, built on the system PdfRenderer. */
final class PdfView extends View {
    interface Listener {
        void onPage(int page, int count);
        void onTap();
    }

    private final ParcelFileDescriptor pfd;
    private final PdfRenderer renderer;
    private final int count;
    private final float[] pw, ph;            // page size in points
    private final float[] top;               // top of every page in content px
    private final Object lock = new Object();
    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private final Set<Integer> pending = new HashSet<>();
    private final LruCache<Integer, Bitmap> cache;
    private final int[] want;                // pixel width wanted for each page
    private volatile int visLo, visHi;
    private volatile boolean closed;

    private final Paint paper = new Paint();
    private final Paint bmp = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint shadow = new Paint();
    private final Rect src = new Rect();
    private final RectF dst = new RectF();

    private final OverScroller scroller;
    private final GestureDetector gd;
    private final ScaleGestureDetector sd;
    private Listener listener;
    private boolean night;
    private float zoom = 1f;
    private float sx, sy, contentW, contentH;
    private int gap, lastPage = -1;
    private boolean sized;

    PdfView(Context c, File f) throws IOException {
        super(c);
        pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
        PdfRenderer r;
        try {
            r = new PdfRenderer(pfd);
        } catch (IOException | SecurityException e) {
            pfd.close();
            throw e instanceof IOException ? (IOException) e : new IOException("This PDF is password protected");
        }
        renderer = r;
        count = r.getPageCount();
        pw = new float[count];
        ph = new float[count];
        top = new float[count + 1];
        want = new int[count];
        gap = Ui.dp(8);
        long mem = Math.min(96L * 1024 * 1024, Runtime.getRuntime().maxMemory() / 4);
        cache = new LruCache<Integer, Bitmap>((int) mem) {
            @Override protected int sizeOf(Integer k, Bitmap b) { return b.getByteCount(); }
        };
        scroller = new OverScroller(c);
        gd = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { scroller.forceFinished(true); return true; }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) { if (listener != null) listener.onTap(); return true; }
            @Override public boolean onScroll(MotionEvent a, MotionEvent b, float dx, float dy) { scrollBy(dx, dy); return true; }
            @Override public boolean onFling(MotionEvent a, MotionEvent b, float vx, float vy) {
                scroller.fling(Math.round(sx), Math.round(sy), Math.round(-vx), Math.round(-vy), 0, Math.round(maxX()), 0, Math.round(maxY()));
                postInvalidateOnAnimation();
                return true;
            }
            @Override public boolean onDoubleTap(MotionEvent e) {
                zoomTo(zoom > 1.2f ? 1f : 2.5f, e.getX(), e.getY());
                return true;
            }
        });
        sd = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                zoomTo(zoom * d.getScaleFactor(), d.getFocusX(), d.getFocusY());
                return true;
            }
        });
        shadow.setColor(0x33000000);
        for (int i = 0; i < count; i++) { pw[i] = 0; ph[i] = 0; }
        pool.execute(this::readSizes);
        setNight(false);
    }

    void setListener(Listener l) { listener = l; }

    int pageCount() { return count; }

    boolean isNight() { return night; }

    void setNight(boolean n) {
        night = n;
        paper.setColor(n ? 0xFF1b1c22 : 0xFFFFFFFF);
        if (n) {
            // soft inversion: white becomes a dark grey, black becomes a pale grey
            float a = -0.82f, o = 232f;
            bmp.setColorFilter(new ColorMatrixColorFilter(new ColorMatrix(new float[]{
                    a, 0, 0, 0, o, 0, a, 0, 0, o, 0, 0, a, 0, o, 0, 0, 0, 1, 0})));
        } else {
            bmp.setColorFilter(null);
        }
        invalidate();
    }

    // ---- page sizes -------------------------------------------------------------------------------
    private void readSizes() {
        for (int i = 0; i < count && !closed; i++) {
            synchronized (lock) {
                if (closed) return;
                PdfRenderer.Page p = renderer.openPage(i);
                pw[i] = Math.max(1, p.getWidth());
                ph[i] = Math.max(1, p.getHeight());
                p.close();
            }
            if (i == 0 || i == count - 1 || i % 64 == 0) post(this::relayout);
        }
        post(this::relayout);
    }

    private float sizeW(int i) { return pw[i] > 0 ? pw[i] : (pw[0] > 0 ? pw[0] : 595f); }
    private float sizeH(int i) { return ph[i] > 0 ? ph[i] : (ph[0] > 0 ? ph[0] : 842f); }

    private void relayout() {
        if (getWidth() == 0) return;
        float anchor = contentH > 0 ? (sy + getHeight() / 2f) / contentH : 0;
        float dw = (getWidth() - 2 * gap) * zoom;
        float y = gap;
        for (int i = 0; i < count; i++) {
            top[i] = y;
            y += dw * sizeH(i) / sizeW(i) + gap;
        }
        top[count] = y;
        contentH = y;
        contentW = dw + 2 * gap;
        if (!sized) { sized = true; } else { sy = anchor * contentH - getHeight() / 2f; }
        clamp();
        invalidate();
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        relayout();
        if (pendingPage >= 0) { goTo(pendingPage); }
    }

    private int pendingPage = -1;

    private float maxX() { return Math.max(0, contentW - getWidth()); }
    private float maxY() { return Math.max(0, contentH - getHeight()); }

    private void clamp() {
        sx = Math.max(0, Math.min(maxX(), sx));
        sy = Math.max(0, Math.min(maxY(), sy));
    }

    private void scrollBy(float dx, float dy) {
        sx += dx; sy += dy;
        clamp();
        invalidate();
    }

    private void zoomTo(float z, float fx, float fy) {
        z = Math.max(1f, Math.min(5f, z));
        if (Math.abs(z - zoom) < 0.001f || contentH <= 0) return;
        float rx = (sx + fx) / contentW, ry = (sy + fy) / contentH;
        zoom = z;
        float oldH = contentH;
        relayoutKeep();
        sx = rx * contentW - fx;
        sy = ry * contentH - fy;
        clamp();
        invalidate();
    }

    private void relayoutKeep() {
        float dw = (getWidth() - 2 * gap) * zoom;
        float y = gap;
        for (int i = 0; i < count; i++) { top[i] = y; y += dw * sizeH(i) / sizeW(i) + gap; }
        top[count] = y;
        contentH = y;
        contentW = dw + 2 * gap;
    }

    @Override public void computeScroll() {
        if (scroller.computeScrollOffset()) {
            sx = scroller.getCurrX();
            sy = scroller.getCurrY();
            clamp();
            postInvalidateOnAnimation();
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        sd.onTouchEvent(e);
        if (!sd.isInProgress()) gd.onTouchEvent(e);
        return true;
    }

    // ---- navigation -------------------------------------------------------------------------------
    int page() {
        if (count == 0 || contentH <= 0) return 0;
        float mid = sy + getHeight() * 0.4f;
        int lo = 0, hi = count - 1;
        while (lo < hi) {
            int m = (lo + hi + 1) >>> 1;
            if (top[m] <= mid) lo = m; else hi = m - 1;
        }
        return lo;
    }

    void goTo(int p) {
        p = Math.max(0, Math.min(count - 1, p));
        if (getWidth() == 0 || contentH <= 0) { pendingPage = p; return; }
        pendingPage = -1;
        scroller.forceFinished(true);
        sy = top[p] - gap;
        clamp();
        invalidate();
    }

    float zoomLevel() { return zoom; }

    // ---- drawing ----------------------------------------------------------------------------------
    @Override protected void onDraw(Canvas c) {
        c.drawColor(night ? 0xFF0e0f13 : 0xFFe9e7e2);
        if (count == 0 || contentH <= 0) return;
        float dw = (getWidth() - 2 * gap) * zoom;
        float x0 = gap - sx;
        int first = 0;
        {
            int lo = 0, hi = count - 1;
            while (lo < hi) { int m = (lo + hi + 1) >>> 1; if (top[m + 0] <= sy) lo = m; else hi = m - 1; }
            first = lo;
        }
        int last = first;
        for (int i = first; i < count; i++) {
            float t = top[i] - sy;
            if (t > getHeight()) break;
            last = i;
            float h = dw * sizeH(i) / sizeW(i);
            dst.set(x0, t, x0 + dw, t + h);
            c.drawRect(dst.left + 1, dst.top + 2, dst.right + 1, dst.bottom + 2, shadow);
            c.drawRect(dst, paper);
            Bitmap b = cache.get(i);
            if (b != null) {
                src.set(0, 0, b.getWidth(), b.getHeight());
                c.drawBitmap(b, src, dst, bmp);
            }
            want[i] = Math.round(dw);
        }
        visLo = Math.max(0, first - 1);
        visHi = Math.min(count - 1, last + 1);
        for (int i = visLo; i <= visHi; i++) {
            if (pw[i] <= 0) continue;
            want[i] = Math.round(dw);
            Bitmap b = cache.get(i);
            if (b == null || b.getWidth() < dw * 0.85f && b.getWidth() < 3600) request(i);
        }
        int cur = page();
        if (cur != lastPage) {
            lastPage = cur;
            if (listener != null) listener.onPage(cur, count);
        }
    }

    private void request(final int i) {
        synchronized (pending) {
            if (!pending.add(i)) return;
        }
        pool.execute(() -> {
            Bitmap out = null;
            try {
                if (!closed && i >= visLo && i <= visHi) {
                    int w = Math.max(200, Math.min(want[i], 3600));
                    int h = Math.round(w * ph[i] / pw[i]);
                    while ((long) w * h > 9_000_000L) { w = w * 9 / 10; h = h * 9 / 10; }
                    out = Bitmap.createBitmap(w, Math.max(1, h), Bitmap.Config.ARGB_8888);
                    out.eraseColor(0xFFFFFFFF);
                    synchronized (lock) {
                        if (closed) return;
                        PdfRenderer.Page p = renderer.openPage(i);
                        p.render(out, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                        p.close();
                    }
                }
            } catch (Throwable t) {
                out = null;
            }
            final Bitmap res = out;
            post(() -> {
                synchronized (pending) { pending.remove(i); }
                if (res != null && !closed) { cache.put(i, res); invalidate(); }
            });
        });
    }

    void close() {
        closed = true;
        pool.shutdownNow();
        synchronized (lock) {
            try { renderer.close(); } catch (Throwable ignored) { }
            try { pfd.close(); } catch (Throwable ignored) { }
        }
        cache.evictAll();
    }
}
