package dev.mellow.docs;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** An Office / OpenDocument / EPUB file: a zip full of XML parts. Pure Java. */
final class Pkg implements Closeable {
    static final class Rel {
        String id, type, target;     // target is already resolved to a zip path (unless external)
        boolean external;
    }

    final File file;
    private final ZipFile zip;

    Pkg(File f) throws IOException {
        file = f;
        zip = new ZipFile(f);
    }

    @Override public void close() throws IOException { zip.close(); }

    private static String norm(String n) {
        while (n.startsWith("/")) n = n.substring(1);
        return n;
    }

    boolean has(String name) { return zip.getEntry(norm(name)) != null; }

    byte[] bytes(String name) {
        try {
            ZipEntry e = zip.getEntry(norm(name));
            if (e == null) return null;
            if (e.getSize() > 120L * 1024 * 1024) return null;
            try (InputStream in = zip.getInputStream(e)) {
                ByteArrayOutputStream out = new ByteArrayOutputStream((int) Math.max(1024, Math.min(e.getSize(), 1 << 24)));
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return out.toByteArray();
            }
        } catch (IOException | RuntimeException ex) {
            return null;
        }
    }

    Xml xml(String name) {
        byte[] b = bytes(name);
        return b == null ? null : new Xml(b);
    }

    /** "ppt/slides/slide1.xml" + "../media/a.png" -> "ppt/media/a.png". */
    static String resolve(String part, String target) {
        if (target == null) return null;
        if (target.startsWith("/")) return target.substring(1);
        String dir = part.contains("/") ? part.substring(0, part.lastIndexOf('/')) : "";
        String[] segs = (dir.isEmpty() ? target : dir + "/" + target).split("/");
        java.util.ArrayList<String> out = new java.util.ArrayList<>();
        for (String s : segs) {
            if (s.equals("..")) { if (!out.isEmpty()) out.remove(out.size() - 1); }
            else if (!s.equals(".") && !s.isEmpty()) out.add(s);
        }
        return String.join("/", out);
    }

    /** Relationships of one part, by id. */
    Map<String, Rel> rels(String part) {
        Map<String, Rel> m = new HashMap<>();
        String dir = part.contains("/") ? part.substring(0, part.lastIndexOf('/') + 1) : "";
        String file = part.substring(part.lastIndexOf('/') + 1);
        Xml x = xml(dir + "_rels/" + file + ".rels");
        if (x == null) return m;
        while (x.next() != Xml.EOF) {
            if (x.is("Relationship")) {
                Rel r = new Rel();
                r.id = x.attr("Id");
                r.type = x.attr("Type", "");
                String t = x.attr("Target", "");
                r.external = "External".equalsIgnoreCase(x.attr("TargetMode", ""));
                r.target = r.external ? t : resolve(part, t);
                if (r.id != null) m.put(r.id, r);
            }
        }
        return m;
    }
}
