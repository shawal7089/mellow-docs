package dev.mellow.docs;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** A presentation: slides made of positioned shapes (EMU units). Pure Java. */
final class Slides {
    long w = 9144000, h = 5143500;
    File zip;
    final List<Slide> slides = new ArrayList<>();
    boolean truncated;

    static final class Slide {
        int bg = 0xFFFFFFFF;
        final List<Shape> shapes = new ArrayList<>();
        String title = "";
    }

    static final class TCell {
        final List<Doc.Para> paras = new ArrayList<>();
        int fill;
        int span = 1;
        boolean merged;      // covered by a neighbour
    }

    static final class Shape {
        static final int BOX = 0, PIC = 1, TABLE = 2, LINE = 3, NOTE = 4;
        int kind;
        long x, y, w, h;
        float rot;
        boolean flipH, flipV;
        int geom;                 // 0 rect, 1 round rect, 2 ellipse, 3 triangle
        int fill, line;           // ARGB, 0 = none
        float lineW = 1f;
        String image;
        float[] crop;             // l t r b as fractions
        final List<Doc.Para> paras = new ArrayList<>();
        int anchor;               // 0 top, 1 middle, 2 bottom
        float fontScale = 1f;
        boolean autofit;
        boolean wrap = true;
        long insL = 91440, insT = 45720, insR = 91440, insB = 45720;
        // table
        long[] colW = new long[0], rowH = new long[0];
        final List<List<TCell>> cells = new ArrayList<>();
        String label = "";

        boolean hasText() {
            for (Doc.Para p : paras) if (!p.isBlank()) return true;
            return false;
        }
    }
}
