package dev.mellow.docs;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Word (.docx) reader. Pure Java. Handles headings, lists, bold/italic/colour, tables, pictures, links. */
final class Docx {
    private Docx() {}

    private static final int MAX_BLOCKS = 80000;

    // ---- styles ---------------------------------------------------------------------------------
    private static final class Style {
        String id, name, basedOn;
        int heading;
        boolean title;
        Boolean b, i, u, s;
        float size;
        int color;
        int numId = -1, ilvl = -1;
        int align = -1;
        float indent = -1;
        boolean resolved;
    }

    private static final class Styles {
        final Map<String, Style> map = new HashMap<>();
        float defaultSize = 11;

        Style get(String id) {
            if (id == null) return null;
            Style s = map.get(id);
            if (s == null) return null;
            resolve(s, 0);
            return s;
        }

        private void resolve(Style s, int depth) {
            if (s.resolved || depth > 8) return;
            s.resolved = true;
            Style p = s.basedOn == null ? null : map.get(s.basedOn);
            if (p == null) return;
            resolve(p, depth + 1);
            if (s.heading == 0 && !s.title) { s.heading = p.heading; s.title = p.title; }
            if (s.b == null) s.b = p.b;
            if (s.i == null) s.i = p.i;
            if (s.u == null) s.u = p.u;
            if (s.s == null) s.s = p.s;
            if (s.size == 0) s.size = p.size;
            if (s.color == 0) s.color = p.color;
            if (s.numId < 0) { s.numId = p.numId; s.ilvl = p.ilvl; }
            if (s.align < 0) s.align = p.align;
            if (s.indent < 0) s.indent = p.indent;
        }
    }

    private static Styles readStyles(Pkg p) {
        Styles st = new Styles();
        Xml x = p.xml("word/styles.xml");
        if (x == null) return st;
        while (x.next() != Xml.EOF) {
            if (x.is("rPrDefault")) {
                int d = x.depth;
                while (x.next() != Xml.EOF) {
                    if (x.type == Xml.END && x.depth == d) break;
                    if (x.is("sz")) { int v = x.attrInt("val", 0); if (v > 0) st.defaultSize = v / 2f; }
                }
            } else if (x.is("style")) {
                Style s = new Style();
                s.id = x.attr("styleId");
                int d = x.depth;
                while (x.next() != Xml.EOF) {
                    if (x.type == Xml.END && x.depth == d) break;
                    if (x.type != Xml.START) continue;
                    switch (x.name) {
                        case "name": {
                            s.name = x.attr("val", "");
                            String n = s.name.toLowerCase(Locale.ROOT);
                            if (n.startsWith("heading ")) {
                                try { s.heading = Math.min(6, Integer.parseInt(n.substring(8).trim())); } catch (NumberFormatException ignored) { }
                            } else if (n.equals("title")) {
                                s.title = true;
                            } else if (n.equals("subtitle")) {
                                s.heading = 2;
                            }
                            break;
                        }
                        case "basedOn": s.basedOn = x.attr("val"); break;
                        case "outlineLvl": if (s.heading == 0 && !s.title) s.heading = Math.min(6, x.attrInt("val", 0) + 1); break;
                        case "numId": s.numId = x.attrInt("val", -1); break;
                        case "ilvl": s.ilvl = x.attrInt("val", -1); break;
                        case "jc": s.align = align(x.attr("val", "")); break;
                        case "ind": {
                            String l = x.attr("left", x.attr("start"));
                            if (l != null) { try { s.indent = Integer.parseInt(l.trim()) / 20f; } catch (NumberFormatException ignored) { } }
                            break;
                        }
                        case "b": s.b = x.attrOn("val"); break;
                        case "i": s.i = x.attrOn("val"); break;
                        case "u": s.u = !"none".equals(x.attr("val", "single")); break;
                        case "strike": s.s = x.attrOn("val"); break;
                        case "sz": { int v = x.attrInt("val", 0); if (v > 0) s.size = v / 2f; break; }
                        case "color": s.color = color(x.attr("val")); break;
                        default: break;
                    }
                }
                if (s.id != null) st.map.put(s.id, s);
            }
        }
        return st;
    }

    static int align(String v) {
        switch (v) {
            case "center": return 1;
            case "right": case "end": return 2;
            case "both": case "distribute": return 3;
            default: return 0;
        }
    }

    static int color(String v) {
        if (v == null || v.length() != 6) return 0;
        try { return 0xFF000000 | Integer.parseInt(v, 16); } catch (NumberFormatException e) { return 0; }
    }

    // ---- numbering --------------------------------------------------------------------------------
    private static final class Level { String fmt = "decimal", text = "%1."; int start = 1; }

    private static final class Numbering {
        final Map<Integer, Integer> numToAbs = new HashMap<>();
        final Map<Integer, Map<Integer, Level>> abs = new HashMap<>();
        final Map<Integer, int[]> counters = new HashMap<>();

        String label(int numId, int ilvl) {
            if (numId <= 0) return "";
            Integer a = numToAbs.get(numId);
            Map<Integer, Level> lv = a == null ? null : abs.get(a);
            if (ilvl < 0) ilvl = 0;
            if (ilvl > 8) ilvl = 8;
            Level l = lv == null ? null : lv.get(ilvl);
            if (l == null) return "•";
            if (l.fmt.equals("bullet")) return ilvl % 3 == 0 ? "•" : ilvl % 3 == 1 ? "◦" : "▪";
            if (l.fmt.equals("none")) return "";
            int[] c = counters.get(numId);
            if (c == null) { c = new int[9]; counters.put(numId, c); }
            if (c[ilvl] == 0) c[ilvl] = l.start; else c[ilvl]++;
            for (int k = ilvl + 1; k < 9; k++) c[k] = 0;
            String t = l.text;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < t.length(); i++) {
                char ch = t.charAt(i);
                if (ch == '%' && i + 1 < t.length() && Character.isDigit(t.charAt(i + 1))) {
                    int k = t.charAt(i + 1) - '1';
                    Level kl = lv.get(k);
                    int n = k >= 0 && k < 9 ? c[k] : 0;
                    if (n == 0 && kl != null) n = kl.start;
                    sb.append(format(n, kl == null ? "decimal" : kl.fmt));
                    i++;
                } else {
                    sb.append(ch);
                }
            }
            return sb.toString();
        }
    }

    static String format(int n, String fmt) {
        switch (fmt) {
            case "lowerLetter": return letters(n, false);
            case "upperLetter": return letters(n, true);
            case "lowerRoman": return roman(n).toLowerCase(Locale.ROOT);
            case "upperRoman": return roman(n);
            case "decimalZero": return n < 10 ? "0" + n : String.valueOf(n);
            default: return String.valueOf(n);
        }
    }

    static String letters(int n, boolean up) {
        if (n <= 0) return "";
        StringBuilder sb = new StringBuilder();
        while (n > 0) {
            n--;
            sb.insert(0, (char) ((up ? 'A' : 'a') + n % 26));
            n /= 26;
        }
        return sb.toString();
    }

    static String roman(int n) {
        int[] v = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] r = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < v.length && n > 0; i++) while (n >= v[i]) { sb.append(r[i]); n -= v[i]; }
        return sb.toString();
    }

    private static Numbering readNumbering(Pkg p) {
        Numbering nb = new Numbering();
        Xml x = p.xml("word/numbering.xml");
        if (x == null) return nb;
        while (x.next() != Xml.EOF) {
            if (x.is("abstractNum")) {
                int id = x.attrInt("abstractNumId", -1);
                Map<Integer, Level> levels = new HashMap<>();
                int d = x.depth;
                while (x.next() != Xml.EOF) {
                    if (x.type == Xml.END && x.depth == d) break;
                    if (x.is("lvl")) {
                        int il = x.attrInt("ilvl", 0);
                        Level l = new Level();
                        int d2 = x.depth;
                        while (x.next() != Xml.EOF) {
                            if (x.type == Xml.END && x.depth == d2) break;
                            if (x.is("numFmt")) l.fmt = x.attr("val", "decimal");
                            else if (x.is("lvlText")) l.text = x.attr("val", "");
                            else if (x.is("start")) l.start = x.attrInt("val", 1);
                        }
                        levels.put(il, l);
                    }
                }
                nb.abs.put(id, levels);
            } else if (x.is("num")) {
                int id = x.attrInt("numId", -1);
                int d = x.depth;
                while (x.next() != Xml.EOF) {
                    if (x.type == Xml.END && x.depth == d) break;
                    if (x.is("abstractNumId")) nb.numToAbs.put(id, x.attrInt("val", -1));
                }
            }
        }
        return nb;
    }

    // ---- document ---------------------------------------------------------------------------------
    private static final class Ctx {
        Pkg pkg;
        Doc doc;
        Styles styles;
        Numbering num;
        Map<String, Pkg.Rel> rels;
        int count;
    }

    static Doc parse(File f) throws IOException {
        try (Pkg p = new Pkg(f)) {
            Xml x = p.xml("word/document.xml");
            if (x == null) throw new IOException("This is not a Word (.docx) file");
            Ctx c = new Ctx();
            c.pkg = p;
            c.doc = new Doc();
            c.styles = readStyles(p);
            c.num = readNumbering(p);
            c.rels = p.rels("word/document.xml");
            while (x.next() != Xml.EOF) {
                if (x.is("body")) { blocks(c, x, c.doc.blocks); break; }
            }
            for (Doc.Block b : c.doc.blocks) {
                if (b instanceof Doc.Para) {
                    Doc.Para pa = (Doc.Para) b;
                    if ((pa.title || pa.heading == 1) && !pa.isBlank()) { c.doc.title = pa.text().trim(); break; }
                }
            }
            return c.doc;
        }
    }

    private static void blocks(Ctx c, Xml x, List<Doc.Block> out) {
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type != Xml.START) continue;
            if (c.count > MAX_BLOCKS) { c.doc.truncated = true; x.skip(); continue; }
            switch (x.name) {
                case "p": para(c, x, out); break;
                case "tbl": table(c, x, out); break;
                case "sectPr": case "sdtPr": case "sdtEndPr": x.skip(); break;
                default: break; // sdt, sdtContent, customXml...: look inside
            }
        }
    }

    private static void table(Ctx c, Xml x, List<Doc.Block> out) {
        Doc.Table t = new Doc.Table();
        int d = x.depth;
        boolean first = true;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.is("tr")) {
                List<Doc.Cell> row = new ArrayList<>();
                int dr = x.depth;
                while (x.next() != Xml.EOF) {
                    if (x.type == Xml.END && x.depth == dr) break;
                    if (x.is("tc")) {
                        Doc.Cell cell = new Doc.Cell();
                        cell.header = first;
                        int dc = x.depth;
                        while (x.next() != Xml.EOF) {
                            if (x.type == Xml.END && x.depth == dc) break;
                            if (x.type != Xml.START) continue;
                            switch (x.name) {
                                case "tcPr": {
                                    int dp = x.depth;
                                    while (x.next() != Xml.EOF) {
                                        if (x.type == Xml.END && x.depth == dp) break;
                                        if (x.is("gridSpan")) cell.span = Math.max(1, x.attrInt("val", 1));
                                        else if (x.is("shd")) cell.bg = color(x.attr("fill"));
                                    }
                                    break;
                                }
                                case "p": para(c, x, cell.blocks); break;
                                case "tbl": table(c, x, cell.blocks); break;
                                default: break;
                            }
                        }
                        row.add(cell);
                    }
                }
                t.rows.add(row);
                first = false;
                c.count++;
            }
        }
        out.add(t);
    }

    private static void para(Ctx c, Xml x, List<Doc.Block> out) {
        Doc.Para para = new Doc.Para();
        List<Doc.Block> after = new ArrayList<>();
        int d = x.depth;
        Style st = null;
        int numId = -1, ilvl = -1;
        boolean pageBefore = false, pageBreak = false;
        String link = null;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END) {
                if (x.depth == d) break;
                if (x.name.equals("hyperlink")) link = null;
                continue;
            }
            if (x.type != Xml.START) continue;
            switch (x.name) {
                case "pPr": {
                    int dp = x.depth;
                    while (x.next() != Xml.EOF) {
                        if (x.type == Xml.END && x.depth == dp) break;
                        if (x.type != Xml.START) continue;
                        switch (x.name) {
                            case "pStyle": st = c.styles.get(x.attr("val")); break;
                            case "numId": numId = x.attrInt("val", -1); break;
                            case "ilvl": ilvl = x.attrInt("val", -1); break;
                            case "jc": para.align = align(x.attr("val", "")); break;
                            case "pageBreakBefore": pageBefore = x.attrOn("val"); break;
                            case "ind": {
                                String l = x.attr("left", x.attr("start"));
                                if (l != null) { try { para.indentPt = Integer.parseInt(l.trim()) / 20f; } catch (NumberFormatException ignored) { } }
                                break;
                            }
                            case "spacing": {
                                int b = x.attrInt("before", 0), a = x.attrInt("after", -1);
                                para.spaceBeforePt = b / 20f;
                                if (a >= 0) para.spaceAfterPt = a / 20f;
                                int line = x.attrInt("line", 0);
                                if (line > 0 && "auto".equals(x.attr("lineRule", "auto"))) para.lineMult = line / 240f;
                                break;
                            }
                            case "rPr": case "sectPr": case "pPrChange": x.skip(); break;
                            default: break;
                        }
                    }
                    if (st != null) {
                        para.heading = st.heading;
                        para.title = st.title;
                        if (para.align == 0 && st.align > 0) para.align = st.align;
                        if (para.indentPt == 0 && st.indent > 0) para.indentPt = st.indent;
                        if (numId < 0 && st.numId > 0) { numId = st.numId; if (ilvl < 0) ilvl = st.ilvl; }
                    }
                    if (numId > 0) {
                        para.level = Math.max(0, ilvl);
                        para.bullet = c.num.label(numId, para.level);
                    }
                    break;
                }
                case "r": {
                    if (run(c, x, para, st, link, after)) pageBreak = true;
                    break;
                }
                case "hyperlink": {
                    String rid = x.attr("r:id");
                    Pkg.Rel r = rid == null ? null : c.rels.get(rid);
                    link = r != null ? r.target : null;
                    break;
                }
                case "del": case "moveFrom": case "pPrChange": x.skip(); break;
                default: break;  // ins, smartTag, fldSimple, sdt...: keep going inside
            }
        }
        c.count++;
        if (pageBefore) out.add(new Doc.Rule(true));
        if (!para.runs.isEmpty() || after.isEmpty()) out.add(para);
        out.addAll(after);
        if (pageBreak) out.add(new Doc.Rule(true));
    }

    /** Returns true if the run contained a page break. */
    private static boolean run(Ctx c, Xml x, Doc.Para para, Style pst, String link, List<Doc.Block> pics) {
        Doc.Run r = new Doc.Run();
        r.link = link;
        if (pst != null) {
            if (pst.b != null) r.b = pst.b;
            if (pst.i != null) r.i = pst.i;
            if (pst.u != null) r.u = pst.u;
            if (pst.s != null) r.s = pst.s;
            r.size = pst.size;
            r.color = pst.color;
        }
        StringBuilder sb = new StringBuilder();
        boolean pageBreak = false;
        int d = x.depth;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type != Xml.START) continue;
            switch (x.name) {
                case "rPr": {
                    int dp = x.depth;
                    while (x.next() != Xml.EOF) {
                        if (x.type == Xml.END && x.depth == dp) break;
                        if (x.type != Xml.START) continue;
                        switch (x.name) {
                            case "rStyle": {
                                Style cs = c.styles.get(x.attr("val"));
                                if (cs != null) {
                                    if (cs.b != null) r.b = cs.b;
                                    if (cs.i != null) r.i = cs.i;
                                    if (cs.u != null) r.u = cs.u;
                                    if (cs.size > 0) r.size = cs.size;
                                    if (cs.color != 0) r.color = cs.color;
                                }
                                break;
                            }
                            case "b": r.b = x.attrOn("val"); break;
                            case "i": r.i = x.attrOn("val"); break;
                            case "u": r.u = !"none".equals(x.attr("val", "single")); break;
                            case "strike": case "dstrike": r.s = x.attrOn("val"); break;
                            case "color": { int col = color(x.attr("val")); if (col != 0) r.color = col; break; }
                            case "sz": { int v = x.attrInt("val", 0); if (v > 0) r.size = v / 2f; break; }
                            case "vertAlign": {
                                String v = x.attr("val", "");
                                r.sup = v.equals("superscript");
                                r.sub = v.equals("subscript");
                                break;
                            }
                            case "rFonts": {
                                String f = x.attr("ascii", "").toLowerCase(Locale.ROOT);
                                if (f.contains("courier") || f.contains("consolas") || f.contains("mono")) r.mono = true;
                                break;
                            }
                            default: break;
                        }
                    }
                    break;
                }
                case "t": sb.append(x.textOf()); break;
                case "tab": sb.append('\t'); break;
                case "br": case "cr":
                    if ("page".equals(x.attr("type"))) pageBreak = true; else sb.append('\n');
                    break;
                case "noBreakHyphen": sb.append('-'); break;
                case "instrText": case "delText": x.skip(); break;
                case "drawing": case "pict": case "object": picture(c, x, pics); break;
                default: break;
            }
        }
        if (sb.length() > 0) {
            r.text = sb.toString();
            para.runs.add(r);
        }
        return pageBreak;
    }

    private static void picture(Ctx c, Xml x, List<Doc.Block> out) {
        int d = x.depth;
        long cx = 0, cy = 0;
        while (x.next() != Xml.EOF) {
            if (x.type == Xml.END && x.depth == d) break;
            if (x.type != Xml.START) continue;
            if (x.name.equals("extent")) { cx = x.attrLong("cx", 0); cy = x.attrLong("cy", 0); }
            else if (x.name.equals("blip") || x.name.equals("imagedata")) {
                String id = x.attr("r:embed", x.attr("r:id", x.attr("r:link")));
                Pkg.Rel r = id == null ? null : c.rels.get(id);
                if (r != null && !r.external && r.target != null) {
                    Doc.Pic pic = new Doc.Pic();
                    pic.zip = c.pkg.file;
                    pic.path = r.target;
                    pic.wEmu = cx;
                    pic.hEmu = cy;
                    out.add(pic);
                }
            }
        }
    }
}
