package dev.mellow.docs;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsetsController;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** The library: every readable document on the phone, with type filters, search and recents. */
public class MainActivity extends Activity {
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int REQ_PICK = 41;
    private static final String[] CHIPS = {"All", "Recent", "PDF", "Word", "Slides", "Sheets", "Text"};

    private static final class Item {
        File file;
        String name;
        long size, mtime;
        int group;
    }

    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService scanner = Executors.newSingleThreadExecutor();
    private final List<File> roots = new ArrayList<>();
    private File primary;

    private final List<Item> all = new ArrayList<>();
    private final List<Item> shown = new ArrayList<>();
    private int chip;               // index into CHIPS
    private int sort;               // 0 date, 1 name, 2 size
    private String query = "";
    private boolean loaded;

    private FrameLayout root;
    private LinearLayout column, tabs;
    private TextView subView, emptyText;
    private EditText searchBox;
    private ListView list;
    private View permView;
    private Adapter adapter;
    private int scanGen;

    @Override protected void onCreate(Bundle b) {
        prefs = getSharedPreferences("mellowdocs", MODE_PRIVATE);
        Look.load(this, prefs);
        setTheme(Ui.t.dark ? R.style.AppDark : R.style.AppLight);
        super.onCreate(b);
        chip = Math.max(0, Math.min(CHIPS.length - 1, prefs.getInt("chip", 0)));
        sort = prefs.getInt("sort", 0);
        buildUi();
        if (!hasAccess()) showPermission();
    }

    @Override protected void onResume() {
        super.onResume();
        if (hasAccess()) {
            if (permView != null) { root.removeView(permView); permView = null; column.setVisibility(View.VISIBLE); }
            scan();
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        scanner.shutdownNow();
    }

    @Override public void onBackPressed() {
        if (searchBox.getVisibility() == View.VISIBLE) { closeSearch(); return; }
        super.onBackPressed();
    }

    private boolean hasAccess() { return Environment.isExternalStorageManager(); }

    // ---- ui -----------------------------------------------------------------------------------------
    private TextView label(String s, float sp, int color, boolean bold) { return Look.label(this, s, sp, color, bold); }

    private IconButton btn(String kind, View.OnClickListener l) {
        IconButton b = new IconButton(this, kind);
        b.setOnClickListener(l);
        return b;
    }

    private void buildUi() {
        final Palette.Theme t = Ui.t;
        root = new FrameLayout(this);
        root.setBackground(new Ui.GradientBg());
        column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(Ui.dp(10), Ui.dp(8), Ui.dp(10), 0);
        root.addView(column, new FrameLayout.LayoutParams(MATCH, MATCH));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout tcol = new LinearLayout(this);
        tcol.setOrientation(LinearLayout.VERTICAL);
        tcol.setPadding(Ui.dp(8), 0, 0, 0);
        TextView title = label("Docs", 22, t.text, true);
        subView = label("", 12, t.muted, false);
        tcol.addView(title);
        tcol.addView(subView);
        top.addView(tcol, new LinearLayout.LayoutParams(0, WRAP, 1f));
        top.addView(btn("search", v -> toggleSearch()));
        top.addView(btn("open", v -> pick()));
        top.addView(btn("more", v -> menu(v)));
        column.addView(top, new LinearLayout.LayoutParams(MATCH, WRAP));

        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setHint("Search documents");
        searchBox.setHintTextColor(t.muted);
        searchBox.setTextColor(t.text);
        searchBox.setTextSize(15);
        searchBox.setBackground(Ui.solid(t.field(), 16, t.panelBorder()));
        searchBox.setPadding(Ui.dp(16), Ui.dp(10), Ui.dp(16), Ui.dp(10));
        searchBox.setVisibility(View.GONE);
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) { query = s.toString().trim().toLowerCase(Locale.ROOT); applyFilter(); }
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(MATCH, WRAP);
        sp.setMargins(0, Ui.dp(6), 0, 0);
        column.addView(searchBox, sp);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        tabs = new LinearLayout(this);
        tabs.setPadding(0, Ui.dp(8), 0, Ui.dp(8));
        hs.addView(tabs, new FrameLayout.LayoutParams(WRAP, WRAP));
        column.addView(hs, new LinearLayout.LayoutParams(MATCH, WRAP));
        buildTabs();

        FrameLayout body = new FrameLayout(this);
        adapter = new Adapter();
        list = new ListView(this);
        list.setAdapter(adapter);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setSelector(new ColorDrawable(0));
        list.setVerticalScrollBarEnabled(false);
        list.setCacheColorHint(0);
        list.setClipToPadding(false);
        list.setPadding(0, 0, 0, Ui.dp(24));
        list.setOnItemClickListener((p, v, pos, id) -> open(shown.get(pos)));
        list.setOnItemLongClickListener((p, v, pos, id) -> { itemMenu(v, shown.get(pos)); return true; });
        body.addView(list, new FrameLayout.LayoutParams(MATCH, MATCH));
        emptyText = label("", 15, t.muted, false);
        emptyText.setGravity(Gravity.CENTER);
        emptyText.setPadding(Ui.dp(30), 0, Ui.dp(30), 0);
        emptyText.setVisibility(View.GONE);
        body.addView(emptyText, new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER));
        column.addView(body, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        setContentView(root);
        getWindow().setStatusBarColor(t.bg1);
        getWindow().setNavigationBarColor(t.bg2);
        WindowInsetsController wc = getWindow().getInsetsController();
        if (wc != null) {
            int light = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
            wc.setSystemBarsAppearance(t.dark ? 0 : light, light);
        }
    }

    private void buildTabs() {
        tabs.removeAllViews();
        for (int i = 0; i < CHIPS.length; i++) {
            final int ii = i;
            TextView tv = label(CHIPS[i], 14, i == chip ? Color.WHITE : Ui.t.text, i == chip);
            tv.setPadding(Ui.dp(16), Ui.dp(8), Ui.dp(16), Ui.dp(8));
            tv.setBackground(i == chip ? Ui.accent(18, 235) : Ui.panel(18));
            tv.setOnClickListener(v -> {
                chip = ii;
                prefs.edit().putInt("chip", chip).apply();
                buildTabs();
                applyFilter();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.rightMargin = Ui.dp(8);
            tabs.addView(tv, lp);
        }
    }

    private void showPermission() {
        column.setVisibility(View.GONE);
        Palette.Theme t = Ui.t;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(Ui.dp(32), Ui.dp(32), Ui.dp(32), Ui.dp(32));
        View pic = new View(this) {
            @Override protected void onDraw(Canvas c) { Glyphs.draw(c, "file", getWidth() / 2f, getHeight() / 2f, Ui.dp(84), Ui.t.a1); }
        };
        box.addView(pic, new LinearLayout.LayoutParams(Ui.dp(96), Ui.dp(96)));
        TextView title = label("Allow access to your files", 21, t.text, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, Ui.dp(20), 0, Ui.dp(10));
        box.addView(title);
        TextView body = label("To list every PDF, Word, slide and sheet file on your phone, Android needs “All files access” "
                + "switched on for Mellow Docs. Tap the button, turn it on and come back. "
                + "(You can still open single files from other apps without this.)", 15, t.muted, false);
        body.setGravity(Gravity.CENTER);
        box.addView(body);
        TextView b = label("Open settings", 16, Color.WHITE, true);
        b.setBackground(Ui.accent(22, 235));
        b.setPadding(Ui.dp(28), Ui.dp(12), Ui.dp(28), Ui.dp(12));
        b.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName())));
            } catch (ActivityNotFoundException e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
        });
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(WRAP, WRAP);
        bl.topMargin = Ui.dp(28);
        box.addView(b, bl);
        TextView alt = label("Open a file instead", 15, t.a1, true);
        alt.setPadding(Ui.dp(16), Ui.dp(16), Ui.dp(16), Ui.dp(8));
        alt.setOnClickListener(v -> pick());
        box.addView(alt);
        permView = box;
        root.addView(box, 1, new FrameLayout.LayoutParams(MATCH, MATCH));
    }

    // ---- search / menu ------------------------------------------------------------------------------
    private void toggleSearch() {
        if (searchBox.getVisibility() == View.VISIBLE) { closeSearch(); return; }
        searchBox.setVisibility(View.VISIBLE);
        searchBox.requestFocus();
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.showSoftInput(searchBox, 0);
    }

    private void closeSearch() {
        searchBox.setText("");
        searchBox.setVisibility(View.GONE);
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
    }

    private void menu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 1, 0, "Sort: newest first" + (sort == 0 ? "  ✓" : ""));
        m.getMenu().add(0, 2, 1, "Sort: name" + (sort == 1 ? "  ✓" : ""));
        m.getMenu().add(0, 3, 2, "Sort: size" + (sort == 2 ? "  ✓" : ""));
        m.getMenu().add(0, 4, 3, "Appearance");
        m.getMenu().add(0, 5, 4, "Rescan");
        m.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1: case 2: case 3:
                    sort = it.getItemId() - 1;
                    prefs.edit().putInt("sort", sort).apply();
                    applyFilter();
                    break;
                case 4: Look.appearanceDialog(this, prefs); break;
                default: scan();
            }
            return true;
        });
        m.show();
    }

    private void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try { startActivityForResult(i, REQ_PICK); } catch (ActivityNotFoundException e) { toast("No file picker available."); }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_PICK && res == RESULT_OK && data != null && data.getData() != null) {
            Intent i = new Intent(this, ReaderActivity.class);
            i.setData(data.getData());
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ---- scanning -----------------------------------------------------------------------------------
    private void scan() {
        roots.clear();
        primary = null;
        StorageManager sm = (StorageManager) getSystemService(Context.STORAGE_SERVICE);
        for (StorageVolume v : sm.getStorageVolumes()) {
            File d = v.getDirectory();
            if (d == null || !Environment.MEDIA_MOUNTED.equals(v.getState())) continue;
            roots.add(d);
            if (v.isPrimary()) primary = d;
        }
        if (primary == null) { primary = Environment.getExternalStorageDirectory(); if (!roots.contains(primary)) roots.add(0, primary); }
        final int gen = ++scanGen;
        scanner.execute(() -> {
            final List<Item> found = query();
            ui.post(() -> {
                if (gen != scanGen) return;
                all.clear();
                all.addAll(found);
                loaded = true;
                applyFilter();
            });
        });
    }

    private List<Item> query() {
        List<Item> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        StringBuilder sel = new StringBuilder();
        List<String> args = new ArrayList<>();
        for (String e : Kind.EXTS) {
            if (sel.length() > 0) sel.append(" OR ");
            sel.append(MediaStore.Files.FileColumns.DATA).append(" LIKE ?");
            args.add("%." + e);
        }
        try (Cursor c = getContentResolver().query(MediaStore.Files.getContentUri("external"),
                new String[]{MediaStore.Files.FileColumns.DATA},
                sel.toString(), args.toArray(new String[0]), null)) {
            if (c != null) {
                while (c.moveToNext()) {
                    String p = c.getString(0);
                    if (p == null || !seen.add(p)) continue;
                    addIfOk(out, new File(p));
                }
            }
        } catch (Throwable ignored) { }
        // files the media index may have missed (Downloads / Documents)
        for (File r : roots) {
            for (String d : new String[]{"Download", "Documents", "Books"}) {
                File[] fs = new File(r, d).listFiles();
                if (fs == null) continue;
                for (File f : fs) if (f.isFile() && seen.add(f.getPath())) addIfOk(out, f);
            }
        }
        return out;
    }

    private void addIfOk(List<Item> out, File f) {
        String n = f.getName();
        if (n.startsWith(".") || !Kind.viewable(n) || n.endsWith(".trashed")) return;
        String p = f.getPath();
        if (p.contains("/.") || p.contains("/Android/data/") || p.contains("/Android/obb/")) return;
        if (!f.isFile() || !f.canRead()) return;
        Item it = new Item();
        it.file = f;
        it.name = n;
        it.size = f.length();
        it.mtime = f.lastModified();
        it.group = Kind.group(n);
        out.add(it);
    }

    private void applyFilter() {
        shown.clear();
        List<String> rec = chip == 1 ? Recents.get(prefs) : null;
        for (Item it : all) {
            if (chip >= 2 && it.group != chip - 1) continue;
            if (rec != null && !rec.contains(it.file.getPath())) continue;
            if (!query.isEmpty() && !it.name.toLowerCase(Locale.ROOT).contains(query)) continue;
            shown.add(it);
        }
        if (rec != null) {
            final List<String> r = rec;
            Collections.sort(shown, (a, b) -> r.indexOf(a.file.getPath()) - r.indexOf(b.file.getPath()));
        } else if (sort == 1) {
            Collections.sort(shown, (a, b) -> FileOps.naturalCompare(a.name, b.name));
        } else if (sort == 2) {
            Collections.sort(shown, (a, b) -> Long.compare(b.size, a.size));
        } else {
            Collections.sort(shown, (a, b) -> Long.compare(b.mtime, a.mtime));
        }
        adapter.notifyDataSetChanged();
        subView.setText(loaded ? (shown.size() + (shown.size() == 1 ? " document" : " documents")) : "Looking…");
        if (loaded && shown.isEmpty()) {
            emptyText.setText(chip == 1 ? "Documents you open will show up here." : !query.isEmpty() ? "Nothing matches “" + query + "”." : "No documents found.\nUse “Open” at the top to pick a file by hand.");
            emptyText.setVisibility(View.VISIBLE);
        } else emptyText.setVisibility(View.GONE);
    }

    // ---- actions ------------------------------------------------------------------------------------
    private void open(Item it) {
        Intent i = new Intent(this, ReaderActivity.class);
        i.putExtra("path", it.file.getPath());
        startActivity(i);
    }

    private void itemMenu(View anchor, final Item it) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 1, 0, "Share");
        m.getMenu().add(0, 2, 1, "Open with…");
        m.getMenu().add(0, 3, 2, "Details");
        m.getMenu().add(0, 4, 3, "Move to trash");
        m.setOnMenuItemClickListener(x -> {
            switch (x.getItemId()) {
                case 1: {
                    Intent s = new Intent(Intent.ACTION_SEND);
                    s.setType(FileShareProvider.mimeOf(it.name));
                    s.putExtra(Intent.EXTRA_STREAM, FileShareProvider.uriFor(it.file));
                    s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(s, "Share"));
                    break;
                }
                case 2: {
                    Intent v = new Intent(Intent.ACTION_VIEW);
                    v.setDataAndType(FileShareProvider.uriFor(it.file), FileShareProvider.mimeOf(it.name));
                    v.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(Intent.createChooser(v, "Open with")); } catch (ActivityNotFoundException e) { toast("No other app can open this."); }
                    break;
                }
                case 3:
                    new AlertDialog.Builder(this).setTitle("Details").setMessage("Name: " + it.name + "\nSize: " + FileOps.humanSize(it.size)
                            + "\nModified: " + DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(new Date(it.mtime))
                            + "\nLocation: " + it.file.getParent()).setPositiveButton("Close", null).show();
                    break;
                default:
                    new AlertDialog.Builder(this).setTitle("Move to trash?").setMessage(it.name)
                            .setPositiveButton("Move", (d, w) -> {
                                try {
                                    Trash.moveToTrash(it.file, roots);
                                    Recents.remove(prefs, it.file.getPath());
                                    all.remove(it);
                                    applyFilter();
                                    toast("Moved to Mellow trash");
                                } catch (Exception e) { toast("Couldn’t move: " + e.getMessage()); }
                            }).setNegativeButton("Cancel", null).show();
            }
            return true;
        });
        m.show();
    }

    // ---- rows ---------------------------------------------------------------------------------------
    private static final int[] GROUP_KIND = {9, 1, 4, 6, 5, 9};
    private static final String[] GROUP_TAG = {"", "PDF", "DOC", "PPT", "XLS", "TXT"};

    private final class Row extends View {
        private Item item;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();

        Row(Context c) { super(c); }

        void bind(Item it) { item = it; invalidate(); }

        @Override protected void onMeasure(int w, int h) { setMeasuredDimension(MeasureSpec.getSize(w), Ui.dp(72)); }

        @Override protected void onDraw(Canvas c) {
            if (item == null) return;
            Palette.Theme t = Ui.t;
            float m = Ui.dp(4);
            r.set(Ui.dp(2), m, getWidth() - Ui.dp(2), getHeight() - m);
            p.setStyle(Paint.Style.FILL);
            if (isPressed()) { p.setColor(t.hover()); c.drawRoundRect(r, Ui.dp(18), Ui.dp(18), p); }
            float tile = Ui.dp(46), tx = Ui.dp(12), ty = (getHeight() - tile) / 2f;
            int kk = GROUP_KIND[item.group];
            p.setShader(new android.graphics.LinearGradient(tx, ty, tx + tile, ty + tile,
                    Palette.alpha(Palette.KIND_C1[kk], 235), Palette.alpha(Palette.KIND_C2[kk], 235), android.graphics.Shader.TileMode.CLAMP));
            r.set(tx, ty, tx + tile, ty + tile);
            c.drawRoundRect(r, Ui.dp(14), Ui.dp(14), p);
            p.setShader(null);
            String ext = FileOps.ext(item.name).toUpperCase(Locale.ROOT);
            if (ext.length() > 4) ext = ext.substring(0, 4);
            p.setColor(0xFFFFFFFF);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextSize(Ui.sp(ext.length() > 3 ? 10.5f : 12f));
            p.setTextAlign(Paint.Align.CENTER);
            c.drawText(ext, tx + tile / 2f, ty + tile / 2f - (p.descent() + p.ascent()) / 2f, p);
            float x = tx + tile + Ui.dp(14);
            p.setTextAlign(Paint.Align.LEFT);
            p.setColor(t.text);
            p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setTextSize(Ui.sp(15.5f));
            float avail = getWidth() - x - Ui.dp(14);
            c.drawText(android.text.TextUtils.ellipsize(item.name, new android.text.TextPaint(p), avail, android.text.TextUtils.TruncateAt.MIDDLE).toString(),
                    x, getHeight() / 2f - Ui.dp(3), p);
            p.setColor(t.muted);
            p.setTypeface(Typeface.DEFAULT);
            p.setTextSize(Ui.sp(12.5f));
            String folder = item.file.getParentFile() == null ? "" : item.file.getParentFile().getName();
            String sub = folder + "  ·  " + FileOps.humanSize(item.size) + "  ·  " + ago(item.mtime);
            c.drawText(android.text.TextUtils.ellipsize(sub, new android.text.TextPaint(p), avail, android.text.TextUtils.TruncateAt.END).toString(),
                    x, getHeight() / 2f + Ui.dp(17), p);
        }

        @Override public void setPressed(boolean pressed) { super.setPressed(pressed); invalidate(); }
    }

    private static String ago(long t) {
        long d = System.currentTimeMillis() - t;
        long min = d / 60000;
        if (min < 1) return "just now";
        if (min < 60) return min + " min ago";
        long h = min / 60;
        if (h < 24) return h + (h == 1 ? " hour ago" : " hours ago");
        long days = h / 24;
        if (days < 30) return days + (days == 1 ? " day ago" : " days ago");
        return DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(t));
    }

    private final class Adapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int i) { return shown.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View v, ViewGroup parent) {
            Row r = v instanceof Row ? (Row) v : new Row(parent.getContext());
            r.bind(shown.get(i));
            return r;
        }
    }
}
