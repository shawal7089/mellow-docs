package dev.mellow.docs;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

/**
 * Tiny, fast, forgiving XML pull parser (pure Java). Names are reported without their prefix
 * ("w:p" -> "p"); attributes can be asked for by full name ("r:embed") or just the local part ("embed").
 */
final class Xml {
    static final int EOF = 0, START = 1, END = 2, TEXT = 3;

    int type;
    String name = "";
    String prefix = "";
    String text = "";
    int depth;
    boolean html;   // lenient HTML mode: lower-case names, void tags auto-close, <script>/<style> skipped

    private final char[] s;
    private int pos;
    private boolean pendingEnd;
    private String[] an = new String[8], av = new String[8];
    private int ac;

    Xml(byte[] data) {
        this(decode(data));
    }

    Xml(String str) {
        s = str.toCharArray();
    }

    static String decode(byte[] b) {
        if (b.length >= 2 && ((b[0] & 255) == 0xFF && (b[1] & 255) == 0xFE)) return new String(b, 2, b.length - 2, StandardCharsets.UTF_16LE);
        if (b.length >= 2 && ((b[0] & 255) == 0xFE && (b[1] & 255) == 0xFF)) return new String(b, 2, b.length - 2, StandardCharsets.UTF_16BE);
        int off = (b.length >= 3 && (b[0] & 255) == 0xEF && (b[1] & 255) == 0xBB && (b[2] & 255) == 0xBF) ? 3 : 0;
        return new String(b, off, b.length - off, StandardCharsets.UTF_8);
    }

    String attr(String n) {
        for (int i = 0; i < ac; i++) if (an[i].equals(n)) return av[i];
        int c = n.indexOf(':');
        if (c >= 0) return null;
        for (int i = 0; i < ac; i++) {
            String f = an[i];
            int k = f.indexOf(':');
            if (k >= 0 && f.regionMatches(k + 1, n, 0, n.length()) && f.length() - k - 1 == n.length()) return av[i];
        }
        return null;
    }

    String attr(String n, String def) {
        String v = attr(n);
        return v == null ? def : v;
    }

    int attrInt(String n, int def) {
        String v = attr(n);
        if (v == null) return def;
        try { return Integer.parseInt(v.trim()); } catch (NumberFormatException e) {
            try { return (int) Math.round(Double.parseDouble(v.trim())); } catch (NumberFormatException e2) { return def; }
        }
    }

    long attrLong(String n, long def) {
        String v = attr(n);
        if (v == null) return def;
        try { return Long.parseLong(v.trim()); } catch (NumberFormatException e) { return def; }
    }

    double attrDouble(String n, double def) {
        String v = attr(n);
        if (v == null) return def;
        try { return Double.parseDouble(v.trim()); } catch (NumberFormatException e) { return def; }
    }

    /** True unless the attribute says "0" / "false" / "off" (used for toggles like bold). */
    boolean attrOn(String n) {
        String v = attr(n);
        return v == null || !(v.equals("0") || v.equals("false") || v.equals("off") || v.equals("none"));
    }

    boolean is(String n) { return type == START && name.equals(n); }

    /** Moves to the next event. */
    int next() {
        if (pendingEnd) {
            pendingEnd = false;
            type = END;
            return type;
        }
        if (type == END) depth--;
        while (true) {
            if (pos >= s.length) { type = EOF; return type; }
            char c = s[pos];
            if (c != '<') {
                int st = pos;
                while (pos < s.length && s[pos] != '<') pos++;
                text = unescape(st, pos);
                type = TEXT;
                if (depth <= 0 && !html) continue; // text outside the root
                return type;
            }
            if (pos + 1 >= s.length) { type = EOF; return type; }
            char d = s[pos + 1];
            if (d == '?') { pos = indexOf("?>", pos + 2); continue; }
            if (d == '!') {
                if (startsWith("<!--", pos)) { pos = indexOf("-->", pos + 4); continue; }
                if (startsWith("<![CDATA[", pos)) {
                    int e = find("]]>", pos + 9);
                    text = new String(s, pos + 9, e - pos - 9);
                    pos = Math.min(s.length, e + 3);
                    type = TEXT;
                    if (depth <= 0 && !html) continue;
                    return type;
                }
                // DOCTYPE (possibly with [ ... ])
                int br = 0;
                int p = pos + 2;
                while (p < s.length) {
                    char x = s[p];
                    if (x == '[') br++;
                    else if (x == ']') br--;
                    else if (x == '>' && br <= 0) break;
                    p++;
                }
                pos = Math.min(s.length, p + 1);
                continue;
            }
            if (d == '/') {
                int e = find(">", pos + 2);
                String full = new String(s, pos + 2, e - pos - 2).trim();
                setName(full);
                if (html) name = name.toLowerCase(java.util.Locale.ROOT);
                pos = Math.min(s.length, e + 1);
                type = END;
                return type;
            }
            // start tag
            int p = pos + 1;
            int ns = p;
            while (p < s.length && !isSpace(s[p]) && s[p] != '>' && s[p] != '/') p++;
            setName(new String(s, ns, p - ns));
            ac = 0;
            boolean empty = false;
            while (p < s.length) {
                while (p < s.length && isSpace(s[p])) p++;
                if (p >= s.length) break;
                char x = s[p];
                if (x == '>') { p++; break; }
                if (x == '/') { empty = true; p++; continue; }
                int as = p;
                while (p < s.length && s[p] != '=' && !isSpace(s[p]) && s[p] != '>' && s[p] != '/') p++;
                String an0 = new String(s, as, p - as);
                while (p < s.length && isSpace(s[p])) p++;
                String val = "";
                if (p < s.length && s[p] == '=') {
                    p++;
                    while (p < s.length && isSpace(s[p])) p++;
                    if (p < s.length && (s[p] == '"' || s[p] == '\'')) {
                        char q = s[p++];
                        int vs = p;
                        while (p < s.length && s[p] != q) p++;
                        val = unescape(vs, p);
                        p++;
                    } else {
                        int vs = p;
                        while (p < s.length && !isSpace(s[p]) && s[p] != '>') p++;
                        val = unescape(vs, p);
                    }
                }
                if (an0.isEmpty()) { p++; continue; }
                addAttr(an0, val);
            }
            pos = p;
            if (html) {
                name = name.toLowerCase(java.util.Locale.ROOT);
                if (isVoid(name)) empty = true;
                else if (!empty && (name.equals("script") || name.equals("style"))) {
                    int e = findIgnoreCase("</" + name, pos);
                    pos = e;
                }
            }
            depth++;
            type = START;
            pendingEnd = empty;
            return type;
        }
    }

    /** Skips the rest of the current element (call right after a START). */
    void skip() {
        if (type != START) return;
        int d = depth;
        while (next() != EOF) if (type == END && depth == d) return;
    }

    /** Collects the text of the current element, then leaves the parser on its END. */
    String textOf() {
        StringBuilder sb = new StringBuilder();
        if (type != START) return "";
        int d = depth;
        while (next() != EOF) {
            if (type == END && depth == d) break;
            if (type == TEXT) sb.append(text);
        }
        return sb.toString();
    }

    private static boolean isVoid(String n) {
        switch (n) {
            case "br": case "img": case "hr": case "meta": case "link": case "input": case "area": case "base": case "col":
            case "embed": case "param": case "source": case "track": case "wbr":
                return true;
            default: return false;
        }
    }

    private int findIgnoreCase(String t, int from) {
        outer:
        for (int i = from; i + t.length() <= s.length; i++) {
            for (int k = 0; k < t.length(); k++) if (Character.toLowerCase(s[i + k]) != t.charAt(k)) continue outer;
            return i;
        }
        return s.length;
    }

    private void setName(String full) {
        int k = full.indexOf(':');
        if (k >= 0) { prefix = full.substring(0, k); name = full.substring(k + 1); } else { prefix = ""; name = full; }
    }

    private void addAttr(String n, String v) {
        if (ac == an.length) {
            an = java.util.Arrays.copyOf(an, ac * 2);
            av = java.util.Arrays.copyOf(av, ac * 2);
        }
        an[ac] = n;
        av[ac] = v;
        ac++;
    }

    private static boolean isSpace(char c) { return c == ' ' || c == '\n' || c == '\r' || c == '\t'; }

    private boolean startsWith(String t, int at) { return at + t.length() <= s.length && new String(s, at, t.length()).equals(t); }

    private int find(String t, int from) {
        outer:
        for (int i = from; i + t.length() <= s.length; i++) {
            for (int k = 0; k < t.length(); k++) if (s[i + k] != t.charAt(k)) continue outer;
            return i;
        }
        return s.length;
    }

    private int indexOf(String t, int from) {
        int i = find(t, from);
        return Math.min(s.length, i + t.length());
    }

    private String unescape(int a, int b) {
        boolean amp = false;
        for (int i = a; i < b; i++) if (s[i] == '&') { amp = true; break; }
        if (!amp) return new String(s, a, b - a);
        StringBuilder sb = new StringBuilder(b - a);
        for (int i = a; i < b; i++) {
            char c = s[i];
            if (c != '&') { sb.append(c); continue; }
            int e = -1;
            for (int k = i + 1; k < b && k < i + 12; k++) if (s[k] == ';') { e = k; break; }
            if (e < 0) { sb.append(c); continue; }
            String ent = new String(s, i + 1, e - i - 1);
            String rep = entity(ent);
            if (rep == null) { sb.append(c); continue; }
            sb.append(rep);
            i = e;
        }
        return sb.toString();
    }

    private static String entity(String e) {
        switch (e) {
            case "amp": return "&";
            case "lt": return "<";
            case "gt": return ">";
            case "quot": return "\"";
            case "apos": return "'";
            case "nbsp": return " ";
            case "mdash": return "—";
            case "ndash": return "–";
            case "hellip": return "…";
            case "lsquo": return "‘";
            case "rsquo": return "’";
            case "ldquo": return "“";
            case "rdquo": return "”";
            case "copy": return "©";
            case "reg": return "®";
            case "trade": return "™";
            case "bull": return "•";
            case "middot": return "·";
            case "laquo": return "«";
            case "raquo": return "»";
            default: break;
        }
        if (e.startsWith("#")) {
            try {
                int cp = e.startsWith("#x") || e.startsWith("#X") ? Integer.parseInt(e.substring(2), 16) : Integer.parseInt(e.substring(1));
                return new String(Character.toChars(cp));
            } catch (Exception ex) { return null; }
        }
        return null;
    }
}
