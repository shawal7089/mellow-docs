package dev.mellow.docs;

import java.util.Locale;

/** What a file is, decided from its extension. Pure Java. */
final class Kind {
    private Kind() {}

    static final int PDF = 1, DOC = 2, SLIDES = 3, SHEET = 4, TEXT = 5, LEGACY = 6, NONE = 0;

    static int of(String name) {
        int i = name.lastIndexOf('.');
        String e = i < 0 ? "" : name.substring(i + 1).toLowerCase(Locale.ROOT);
        switch (e) {
            case "pdf": return PDF;
            case "docx": case "docm": case "dotx": case "dotm": case "odt": case "ott": case "epub": case "rtf":
            case "html": case "htm": case "xhtml": return DOC;
            case "pptx": case "pptm": case "ppsx": case "potx": case "odp": case "otp": return SLIDES;
            case "xlsx": case "xlsm": case "xltx": case "ods": case "ots": case "csv": case "tsv": return SHEET;
            case "txt": case "md": case "markdown": case "log": case "json": case "xml": case "yml": case "yaml":
            case "ini": case "conf": case "cfg": case "tex": case "srt": case "toml": return TEXT;
            case "doc": case "dot": case "ppt": case "pps": case "xls": case "xlt": return LEGACY;
            default: return NONE;
        }
    }

    static boolean viewable(String name) { int k = of(name); return k != NONE; }

    /** Sub-group used by the library chips: 0 all, 1 pdf, 2 word, 3 slides, 4 sheets, 5 text. */
    static int group(String name) {
        switch (of(name)) {
            case PDF: return 1;
            case DOC: return 2;
            case SLIDES: return 3;
            case SHEET: return 4;
            case TEXT: return 5;
            case LEGACY: {
                String e = FileOps.ext(name);
                return e.startsWith("d") ? 2 : e.startsWith("p") ? 3 : 4;
            }
            default: return 0;
        }
    }

    static String ext(String name) { return FileOps.ext(name); }

    static final String[] EXTS = {"pdf", "docx", "docm", "odt", "rtf", "epub", "html", "htm", "pptx", "ppsx", "odp",
            "xlsx", "xlsm", "ods", "csv", "tsv", "txt", "md", "markdown", "log", "json", "xml", "yml", "yaml",
            "doc", "ppt", "xls"};
}
