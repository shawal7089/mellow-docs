# Mellow Docs
Fast, soft, glassy document reader for Android 11+. Opens PDF, Word (.docx/.odt/.rtf/.epub/.html), PowerPoint/Impress
(.pptx/.odp), Excel/Calc (.xlsx/.ods/.csv) and text/markdown. Optional "All files access" lists everything on the phone;
without it, it still opens files handed over by other apps. Shares trash with Mellow (file manager).
