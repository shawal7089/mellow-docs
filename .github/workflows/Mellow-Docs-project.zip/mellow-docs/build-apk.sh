#!/usr/bin/env bash
# Builds Mellow-Docs.apk locally. Needs: JDK 17 and the Android SDK (platform 34, build-tools 34.0.0).
set -e
cd "$(dirname "$0")"
if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
  for d in "$HOME/Android/Sdk" /opt/android-sdk /opt/android-sdk-linux; do
    [ -d "$d" ] && export ANDROID_HOME="$d" && break
  done
fi
[ -n "$ANDROID_HOME" ] || { echo "Android SDK not found. Install 'android-sdk-cmdline-tools-latest' (AUR) or set ANDROID_HOME."; exit 1; }
echo "sdk.dir=$ANDROID_HOME" > local.properties
./gradlew --no-daemon assembleRelease
cp app/build/outputs/apk/release/app-release.apk Mellow-Docs.apk
echo "Done: $(pwd)/Mellow-Docs.apk"
